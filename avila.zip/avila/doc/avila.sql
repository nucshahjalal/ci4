
CREATE TABLE `abouts` (
  `id` int(11) NOT NULL,
  `title` varchar(255) DEFAULT NULL,
  `description` text,
  `image` varchar(255) DEFAULT NULL,
  `video` varchar(255) DEFAULT NULL,
  `status` tinyint(1) NOT NULL,
  `created_by` int(11) NOT NULL,
  `modified_by` int(11) NOT NULL,
  `created_at` datetime NOT NULL,
  `modified_at` datetime NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Dumping data for table `abouts`
--

INSERT INTO `abouts` (`id`, `title`, `description`, `image`, `video`, `status`, `created_by`, `modified_by`, `created_at`, `modified_at`) VALUES
(5, 'About Structure Housing & Development Ltd', '<p><b><i>Structure Housing & Development Ltd.</i></b>(<b>SHDL</b>) is a fast growing real estate company.</p><p>SHDL was established in 2009 as a real estate firm. Since that time the firm has steadily consolidated its expertise in developing projects and has gained a high reputation in successfully completing its assignments. Starting with a handful of staff over five years ago, currently the firm has over 100 professionals and staff. Moreover a skilled and well trained work force of about 500 workers are currently employed at various projects of <b>SHDL</b>.</p><p><br></p><p><b>SHDL </b>is member of Real Estate and Housing Association of Bangladesh(<b>REHAB</b>). <b>SHDL </b>takes pride in the development of Residential Apartments, Shopping Centers and Commercial Buildings.</p><p><br></p><p>At <b>SHDL</b>, all construction materials and equipment are procured with great care so as to ensure highest possible standard. SHDL is committed to maintain a very high standard in quality control and workmanship. Use of high performance materials and high-tech equipment is a daily routine for shdl family.</p><p><br></p><p><b>Disclaimer:</b> All the project information of this website is subject to change any time on management decision without notice. We strongly recommended you to read agreement paper carefully. The website department is separate from our legal and marketing department. The information may not carry for evidence in any way.</p><p></p>', 'about-1633774824-shdl.jpg', '<iframe width=\"730\" height=\"400\" src=\"https://www.youtube.com/embed/os6YdEXMURY\" title=\"YouTube video player\" frameborder=\"0\" allow=\"accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture\" allowfullscreen></iframe>', 1, 1, 1, '2021-09-13 10:44:26', '2021-10-09 05:20:24');

-- --------------------------------------------------------

--
-- Table structure for table `contacts`
--

CREATE TABLE `contacts` (
  `id` int(11) NOT NULL,
  `name` varchar(255) DEFAULT NULL,
  `email` varchar(50) DEFAULT NULL,
  `phone` varchar(50) DEFAULT NULL,
  `subject` varchar(50) DEFAULT NULL,
  `message` varchar(255) DEFAULT NULL,
  `status` tinyint(1) NOT NULL,
  `created_by` int(11) NOT NULL,
  `modified_by` int(11) NOT NULL,
  `created_at` datetime NOT NULL,
  `modified_at` datetime NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Dumping data for table `contacts`
--

INSERT INTO `contacts` (`id`, `name`, `email`, `phone`, `subject`, `message`, `status`, `created_by`, `modified_by`, `created_at`, `modified_at`) VALUES
(4, 'dsfsd', 'superadmin@gsms.com', '12345678', 'Test', 'In MySQL “DELETE FROM TABLE” returns 0 affected rows. The database class has a small hack that allows it to return the correct number of affected rows. By default this hack is enabled but it can be turned off in the database driver file.', 1, 1, 1, '2021-09-15 10:51:03', '2021-09-19 06:35:26');

-- --------------------------------------------------------

--
-- Table structure for table `facilities`
--

CREATE TABLE `facilities` (
  `id` int(11) NOT NULL,
  `title` varchar(150) NOT NULL,
  `image` varchar(150) NOT NULL,
  `status` tinyint(1) NOT NULL,
  `created_by` int(11) NOT NULL,
  `modified_by` int(11) NOT NULL,
  `created_at` datetime NOT NULL,
  `modified_at` datetime NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Dumping data for table `facilities`
--

INSERT INTO `facilities` (`id`, `title`, `image`, `status`, `created_by`, `modified_by`, `created_at`, `modified_at`) VALUES
(7, 'Body Fitness Center & Studio', 'facility-1632238307-shdl.jpg', 1, 1, 1, '2021-09-21 10:26:02', '2021-09-21 10:31:47'),
(6, 'Air Conditioning', 'facility-1632237557-shdl.jpg', 1, 1, 1, '2021-09-21 10:19:17', '2021-09-21 10:19:17'),
(8, 'Swimming Pool', 'facility-1632238482-shdl.jpg', 1, 1, 1, '2021-09-21 10:34:42', '2021-09-21 10:34:42'),
(9, 'Sky Lounge and Roof Terrace with BBQs', 'facility-1632238630-shdl.jpg', 1, 1, 1, '2021-09-21 10:37:10', '2021-09-21 10:37:10'),
(10, '24-Hour Doorman & Concierge Services', 'facility-1632238822-shdl.jpg', 1, 1, 1, '2021-09-21 10:40:22', '2021-09-21 10:40:22'),
(11, 'Children’s Playroom', 'facility-1632239408-shdl.jpg', 1, 1, 1, '2021-09-21 10:50:08', '2021-09-21 10:50:08');

-- --------------------------------------------------------


--
-- Table structure for table `galleries`
--

CREATE TABLE `galleries` (
  `id` int(11) NOT NULL,
  `title` varchar(255) DEFAULT NULL,
  `note` text,
  `status` tinyint(1) NOT NULL,
  `created_by` int(11) NOT NULL,
  `modified_by` int(11) NOT NULL,
  `created_at` datetime NOT NULL,
  `modified_at` datetime NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Dumping data for table `galleries`
--

INSERT INTO `galleries` (`id`, `title`, `note`, `status`, `created_by`, `modified_by`, `created_at`, `modified_at`) VALUES
(17, 'SHDL Monoroma Garden', 'Disclaimer: All the project information of this website is subject to change any time on management decision without notice. We strongly recommended you to read agreement paper carefully. The website department is separate from our legal and marketing department. The information may not carry for evidence in any way.', 1, 1, 1, '2021-09-22 05:16:15', '2021-09-22 05:16:15'),
(18, 'SHDL Munshigong New Market & Hiron Kutir Apartment.', 'Disclaimer: All the project information of this website is subject to change any time on management decision without notice. We strongly recommended you to read agreement paper carefully. The website department is separate from our legal and marketing department. The information may not carry for evidence in any way.', 1, 1, 1, '2021-09-22 05:18:01', '2021-09-22 05:18:01'),
(19, 'SHDL Sheikh Villa.', 'Disclaimer: All the project information of this website is subject to change any time on management decision without notice. We strongly recommended you to read agreement paper carefully. The website department is separate from our legal and marketing department. The information may not carry for evidence in any way.', 1, 1, 1, '2021-09-22 05:22:45', '2021-09-22 05:22:45');

-- --------------------------------------------------------

--
-- Table structure for table `gallery_images`
--

CREATE TABLE `gallery_images` (
  `id` int(11) NOT NULL,
  `gallery_id` int(11) NOT NULL,
  `image` varchar(255) DEFAULT NULL,
  `caption` varchar(255) DEFAULT NULL,
  `status` tinyint(1) NOT NULL,
  `created_by` int(11) NOT NULL,
  `modified_by` int(11) NOT NULL,
  `created_at` datetime NOT NULL,
  `modified_at` datetime NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;


--
-- Table structure for table `heading`
--

CREATE TABLE `heading` (
  `id` int(11) NOT NULL,
  `news_title` varchar(255) NOT NULL,
  `news_note` text NOT NULL,
  `gallery_title` varchar(255) NOT NULL,
  `gallery_note` text NOT NULL,
  `project_title` varchar(255) NOT NULL,
  `project_note` text NOT NULL,
  `progress_title` varchar(255) NOT NULL,
  `progress_note` text NOT NULL,
  `complete_title` varchar(255) NOT NULL,
  `complete_note` text NOT NULL,
  `ongoing_title` varchar(255) NOT NULL,
  `ongoing_note` text NOT NULL,
  `upcoming_title` varchar(255) NOT NULL,
  `upcoming_note` text NOT NULL,
  `facility_title` varchar(255) DEFAULT NULL,
  `facility_note` text,
  `contact_title` varchar(255) DEFAULT NULL,
  `contact_note` text,
  `status` tinyint(1) NOT NULL,
  `created_by` int(11) NOT NULL,
  `modified_by` int(11) NOT NULL,
  `created_at` datetime NOT NULL,
  `modified_at` datetime NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Dumping data for table `heading`
--

INSERT INTO `heading` (`id`, `news_title`, `news_note`, `gallery_title`, `gallery_note`, `project_title`, `project_note`, `progress_title`, `progress_note`, `complete_title`, `complete_note`, `ongoing_title`, `ongoing_note`, `upcoming_title`, `upcoming_note`, `facility_title`, `facility_note`, `contact_title`, `contact_note`, `status`, `created_by`, `modified_by`, `created_at`, `modified_at`) VALUES
(3, 'Latest News', 'Housing industry news, home building and construction, and housing market coverage. ... Asia-Pacifics real estate boom sees buyers bidding up prices. \r\n', 'SHDl Projects Gallery', 'The most efficient photo gallery for real estate purposes should include more than a basic image slider. In order to provide the best user experience, a real estate photo gallery must offer relevant information and easy and convenient navigation via a thumbnail gallery.', 'Our Featured Project', 'All the project information of this website is subject to change any time on management decision without notice. We strongly recommended you to read agreement paper carefully', 'Looking for Best Home Ever!', 'To promote development, standardization, mechanization and large scale field application of innovative and emerging building materials and technologies in the construction sector.', 'Our Completed Projects ', 'All the project information of this website is subject to change any time on management decision without notice. We strongly recommended you to read agreement paper carefully. The website department is separate from our legal and marketing department. The information may not carry for evidence in any way.', 'Our Ongoing Projects', 'All the project information of this website is subject to change any time on management decision without notice. We strongly recommended you to read agreement paper carefully. The website department is separate from our legal and marketing department. The information may not carry for evidence in any way.', 'Our Upcoming Projects', 'All the project information of this website is subject to change any time on management decision without notice. We strongly recommended you to read agreement paper carefully. The website department is separate from our legal and marketing department. The information may not carry for evidence in any way.', 'Facilites And Amenities', 'An amenity is a feature of a property that makes it more valuable to potential buyers or tenants. Amenities are commonly used in the real estate industry and can be found in property listings.', 'Contact up for more Info', '',  1, 1, 1, '2021-09-13 12:49:02', '2021-09-22 01:43:53');

-- --------------------------------------------------------

--
-- Table structure for table `news`
--

CREATE TABLE `news` (
  `id` int(11) NOT NULL,
  `title` varchar(255) DEFAULT NULL,
  `initial_part` text,
  `rest_part` text,
  `image` varchar(255) DEFAULT NULL,
  `status` tinyint(1) NOT NULL,
  `created_by` int(11) NOT NULL,
  `modified_by` int(11) NOT NULL,
  `created_at` datetime NOT NULL,
  `modified_at` datetime NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Dumping data for table `news`
--

INSERT INTO `news` (`id`, `title`, `initial_part`, `rest_part`, `image`, `status`, `created_by`, `modified_by`, `created_at`, `modified_at`) VALUES
(12, 'SHDLBD Family ‘Contributes to Everyone’s work Together', '<p>At this trying time for the nation, SHDLBD Family empathizes with the hardship of the struggling underprivileged people of our city. We appreciate the humanitarian endeavor of ‘Shobai Mile Shobar Dhaka’ under the caring leadership of respected Mayor of DNCC Mr. Atiqul Islam and the dedicated volunteers of BD Clean team.</p>', '<p>SHDLBD&nbsp; is a proud inhabitant of Dhaka North, having its head-office at SHDLBD HOUSE – one of the oldest and most esteemed corporate buildings in Banani. To extend support to this commendable food distribution program among the disadvantaged community of North Dhaka, SHDLBD&nbsp; Family made a humble contribution of Taka Five Lac to .</p><p>We hope this helps the program to reach more people in dire need of food.</p><p>As a Bangladeshi organization, SHDLBD&nbsp; promises to play a socially responsible,</p><p>ethical &amp; cooperative role to help the Government and Bangladeshi citizens to fight this battle and survive in this global crisis.</p><p>Together, we aspire to survive and overcome this acute crisis at the minimum damage to our population.</p>', 'news-1632242456-shdl.jpg', 1, 1, 1, '2021-09-21 11:40:56', '2021-09-21 11:40:56'),
(11, 'Agreement Signing Ceremony Between SHDLBD', '<p>A contract was signed on 23rd August 2020 between ADC (Aviation Dhaka Consortium) &amp; SHDLBD (Associated Builders Corporation)</p><p>Limited for construction of main passenger terminal of Terminal-3 Building (right wing) under the expansion project of</p>', '<p>The contract was signed by Mr. KJ Kang, Deputy Project Manager on behalf of ADC and Engr. Nashid Islam, Director on behalf of SHDLBD Ltd.</p><p>Top officials of both the companies were present in the signing ceremony.</p><p><br></p><p>SHDLBD is proud and delighted to be a part of this very important &amp; prestigious project that would have an enormous impact on our</p><p>national infrastructure and our image to the international travellers, investors and delegates.</p>', 'news-1632241292-shdl.jpg', 1, 1, 1, '2021-09-21 11:21:32', '2021-09-21 11:21:32'),
(13, 'Successful Handover of SHDLBD Uttara Project!', 'SHDLBD Properties brings the SHDLBD Group philosophy of innovation, sustainability, and excellence to the real estate industry. Each SHDLBD Properties development combines a 14–year legacy of excellence and trust with a commitment to cutting-edge design and technology.', '<p>SHDLBD Group is highly delighted to announce the successful completion &amp; handover of \"SHDLBD Uttara Project” which is a G+7 storied, luxurious #Single_Unit apartment complex situated on a Lake facing iconic location at House 37 | Road 02 | Sector 05 | Uttara, Dhaka-1230.</p><p><br></p><p>✔️ Apartment Size: 1759 Sq. Ft</p><p><br></p><p>Apartment features and amenities at \"SHDLBD Uttara\" are as follows: ✔️ 03 Beds, ✔️ 03 Baths (02 Attached), ✔️ 03 Veranda , ✔️ Dining, ✔️ Family Living, ✔️ Kitchen with veranda, ✔️ Maid’s Bed &amp; Toilet.</p><p><br></p><p>The Ceremony has held on May 27, 2021, evening and took place at the Community Hall premise of the project.</p><p><br></p><p>All the honorable clients and landowners were present &amp; taken over their respective property from SHDLBD GROUP.</p><p><br></p><p>High officials of Head office, Engineering, Customer Care and Marketing and Sales Dept. of the Group, were also present at this colorful event.</p><p><br></p><p>SHDLBD GROUP wishing a healthy, safe and peaceful living to all its owners at SHDLBD Uttara.</p>', 'news-1632243050-shdl.jpg', 1, 1, 1, '2021-09-21 11:50:50', '2021-09-21 11:50:50');

-- --------------------------------------------------------


--
-- Table structure for table `settings`
--

CREATE TABLE `settings` (
  `id` int(11) NOT NULL,
  `email` varchar(50) DEFAULT NULL,
  `mobile` varchar(50) DEFAULT NULL,
  `phone` varchar(50) DEFAULT NULL,
  `skype` varchar(100) DEFAULT NULL,
  `fax` varchar(100) DEFAULT NULL,
  `name` varchar(100) DEFAULT NULL,
  `address` varchar(250) DEFAULT NULL,
  `opening_day` varchar(255) DEFAULT NULL,
  `opening_time` varchar(255) DEFAULT NULL,
  `close_day` varchar(255) DEFAULT NULL,
  `currency` varchar(10) DEFAULT NULL,
  `facebook` varchar(255) DEFAULT NULL,
  `twitter` varchar(255) DEFAULT NULL,
  `linked_in` varchar(255) DEFAULT NULL,
  `youtube` varchar(255) DEFAULT NULL,
  `pinterest` varchar(255) DEFAULT NULL,
  `instagram` varchar(255) DEFAULT NULL,
  `key_note` varchar(255) DEFAULT NULL,
  `copy_right` varchar(255) DEFAULT NULL,
  `google_map` text,
  `status` tinyint(1) NOT NULL,
  `created_by` int(11) NOT NULL,
  `modified_by` int(11) NOT NULL,
  `created_at` datetime NOT NULL,
  `modified_at` datetime NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Dumping data for table `settings`
--

INSERT INTO `settings` (`id`, `email`, `mobile`, `phone`, `skype`, `fax`, `name`, `address`, `opening_day`, `opening_time`, `close_day`, `currency`, `facebook`, `twitter`, `linked_in`, `youtube`, `pinterest`, `instagram`, `key_note`, `copy_right`, `google_map`, `status`, `created_by`, `modified_by`, `created_at`, `modified_at`) VALUES
(15, 'info@avila.com', '88-01926-682993', '8715605, 8715605', 'dfsd', '8715604', 'Structure Housing & Development Ltd.', 'House #281/A, Road #19/C. New DOHS Moakhali, Dhaka-1206', 'Saturday  - Thursday', '10:00 am - 5:00 pm', 'Friday', 'Tk', 'https://www.facebook.com/profile.php?id=100077025701306&sk=about_overview', 'https://twitter.com/', 'https://www.linkedin.com/', 'https://www.youtube.com/', 'https://www.pinterest.com/', 'https://www.instagram.com/', 'Structure Housing & Development Ltd.(SHDL) is a fast growing real estate company. SHDL was established in 2009 as a real estate firm. Since that time the firm has steadily consolidated its expertise in developing projects and has gained a high reputation ', '© 2021 Structure Housing & Development Limited , All Rights Reserved.', '<iframe src=\"https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3650.9610756588063!2d90.39071081481602!3d23.784400384572713!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x3755c7403a7d0111%3A0xe5edec76d2ec392b!2s281%20Rd%20No%2019%2FC%2C%20Dhaka%201206!5e0!3m2!1sen!2sbd!4v1632249430326!5m2!1sen!2sbd\" width=\"100%\" height=\"600\" style=\"border:0;\" allowfullscreen=\"\" loading=\"lazy\"></iframe>', 1, 0, 1, '0000-00-00 00:00:00', '2022-01-10 00:33:58');

-- --------------------------------------------------------

--
-- Table structure for table `sliders`
--

CREATE TABLE `sliders` (
  `id` int(11) NOT NULL,
  `title` varchar(255) DEFAULT NULL,
  `image` varchar(255) DEFAULT NULL,
  `status` tinyint(1) NOT NULL,
  `created_by` int(11) NOT NULL,
  `modified_by` int(11) NOT NULL,
  `created_at` datetime NOT NULL,
  `modified_at` datetime NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;


--
-- Table structure for table `testimonials`
--

CREATE TABLE `testimonials` (
  `id` int(11) NOT NULL,
  `name` varchar(100) NOT NULL,
  `designation` varchar(150) NOT NULL,
  `rating` int(2) NOT NULL,
  `testimonial` text NOT NULL,
  `image` varchar(150) NOT NULL,
  `status` tinyint(1) NOT NULL,
  `created_by` int(11) NOT NULL,
  `modified_by` int(11) NOT NULL,
  `created_at` datetime NOT NULL,
  `modified_at` datetime NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Dumping data for table `testimonials`
--

INSERT INTO `testimonials` (`id`, `name`, `designation`, `rating`, `testimonial`, `image`, `status`, `created_by`, `modified_by`, `created_at`, `modified_at`) VALUES
(12, 'Hasan Zahid', 'Chief Operating Officer (COO) ', 5, 'In all of my years, I have rarely come across a company as professional as SHDLBD. SHDLBD is truly a trustworthy name in the real estate sector of Bangladesh.', 'testimonial-1632250900-shdl.jpg', 1, 1, 1, '2021-09-21 14:01:40', '2021-09-22 04:03:39'),
(13, 'Niloy Sarker', 'Executive', 5, 'My wife & I have moved 6 times in the last 25 years. Obviously, we\'ve dealt with many realtors both on the buying and selling side. I have to say that David is by far the BEST realtor we\'ve ever worked with, his professionalism, personality, attention to detail, responsiveness and his ability to close the deal was Outstanding!!! If you are buying or selling a home, do yourselves a favor and hire David Marsden!!\r\n\r\n', 'testimonial-1632262020-shdl.jpg', 1, 1, 1, '2021-09-21 17:07:00', '2021-09-22 04:03:04'),
(14, 'Riham Rey', 'Chief Executive Officer (CEO) ', 5, 'David is an outstanding agent to work with. He is a skilled listener and negotiator, with very in-depth knowledge of the local markets. My husband and I listed two properties with him at the same time and while he sold one within a week, one took five months to sell. At no point in those five months did his dedication to selling the property waiver. He was just as aggressive and excited about selling the second property as he was the first. Without doubt, we would seek him out immediately for any upcoming real estate transaction in the future.', 'testimonial-1632262266-shdl.jpg', 1, 1, 1, '2021-09-21 17:11:06', '2021-09-22 04:02:44');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int(11) NOT NULL,
  `user_type` varchar(100) NOT NULL COMMENT 'admin, editor',
  `is_default` tinyint(1) NOT NULL DEFAULT '0',
  `name` varchar(100) NOT NULL,
  `email` varchar(50) NOT NULL,
  `mobile` varchar(50) DEFAULT NULL,
  `address` varchar(255) DEFAULT NULL,
  `password` varchar(100) NOT NULL,
  `temp_password` varchar(100) DEFAULT NULL,
  `last_logged_in` datetime NOT NULL,
  `image` varchar(100) DEFAULT NULL,
  `status` tinyint(1) NOT NULL,
  `created_by` int(11) NOT NULL,
  `modified_by` int(11) NOT NULL,
  `created_at` datetime NOT NULL,
  `modified_at` datetime NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `user_type`, `is_default`, `name`, `email`, `mobile`, `address`, `password`, `temp_password`, `last_logged_in`, `image`, `status`, `created_by`, `modified_by`, `created_at`, `modified_at`) VALUES
(1, '1', 1, 'Admin', 'admin@admin.com', '123456534535', 'Dhaka', 'e10adc3949ba59abbe56e057f20f883e', 'MTIzNDU2', '2022-02-22 21:01:01', 'user-1631988392-shdl.png', 1, 1, 1, '2021-09-11 16:08:10', '2021-09-11 16:08:10'),
(3, '2', 0, 'Shah Jalal', 'emp@gmail.com', '12345611', 'Dhaka ED', 'e10adc3949ba59abbe56e057f20f883e', NULL, '0000-00-00 00:00:00', 'user-1632109102-shdl.jpg', 0, 0, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00');




--
-- Table structure for table `projects`
--

CREATE TABLE `projects` (
  `id` int(11) NOT NULL,
  `project_status` varchar(100) NOT NULL COMMENT 'complete, ongoing, upcoming',
  `project_type` varchar(100) NOT NULL COMMENT 'residential, commercial',
  `is_featured` tinyint(1) DEFAULT '0',
  `name` varchar(100) DEFAULT NULL,
  `brochure` varchar(100) DEFAULT NULL,
  `latitude` varchar(100) DEFAULT NULL,
  `longitude` varchar(100) DEFAULT NULL,
  `address` varchar(255) DEFAULT NULL,
  `location` varchar(255) DEFAULT NULL,  
  `land_amount` varchar(100) DEFAULT NULL,
  `approval_no` varchar(100) DEFAULT NULL,
  `approval_date` varchar(100) DEFAULT NULL,
  `front_view` varchar(255) DEFAULT NULL,
  `no_of_building` int(5) DEFAULT NULL,
  `total_floor` varchar(100) DEFAULT NULL,
  `total_flat` int(5) DEFAULT NULL,
  `total_sale` int(5) DEFAULT NULL,
  `total_available` int(5) DEFAULT NULL,
  `flat_sft` varchar(100) DEFAULT NULL,
  `flat_bed` varchar(100) DEFAULT NULL,
  `flat_bath` varchar(100) DEFAULT NULL,
  `flat_baranda` varchar(100) DEFAULT NULL,
  `flat_bachine` varchar(100) DEFAULT NULL,
  `flat_window` varchar(100) DEFAULT NULL,
  `flat_dyning` varchar(100) DEFAULT NULL,
  `flat_drawing` varchar(100) DEFAULT NULL,
  `flat_kitchen` varchar(100) DEFAULT NULL,
  `flat_store_room` varchar(100) DEFAULT NULL,
  `image` varchar(100) DEFAULT NULL,
  `video` varchar(100) DEFAULT NULL,
  `note` text,
  `status` tinyint(1) NOT NULL,
  `created_by` int(11) NOT NULL,
  `modified_by` int(11) NOT NULL,
  `created_at` datetime NOT NULL,
  `modified_at` datetime NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;



CREATE TABLE `project_images` (
  `id` int(11) NOT NULL,
  `project_id` int(11) NOT NULL,
  `image` varchar(150) DEFAULT NULL,
  `caption` varchar(100) DEFAULT NULL,
  `status` tinyint(1) NOT NULL,
  `created_by` int(11) NOT NULL,
  `modified_by` int(11) NOT NULL,
  `created_at` datetime NOT NULL,
  `modified_at` datetime NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;


--
-- Table structure for table `floor_plan_images`
--

CREATE TABLE `floor_plan_images` (
  `id` int(11) NOT NULL,
  `project_id` int(11) NOT NULL,
  `image` varchar(150) DEFAULT NULL,
  `caption` varchar(100) DEFAULT NULL,
  `status` tinyint(1) NOT NULL,
  `created_by` int(11) NOT NULL,
  `modified_by` int(11) NOT NULL,
  `created_at` datetime NOT NULL,
  `modified_at` datetime NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Indexes for dumped tables
--

--
-- Indexes for table `abouts`
--
ALTER TABLE `abouts`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `contacts`
--
ALTER TABLE `contacts`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `facilities`
--
ALTER TABLE `facilities`
  ADD PRIMARY KEY (`id`);


--
-- Indexes for table `floor_plan_images`
--
ALTER TABLE `floor_plan_images`
  ADD PRIMARY KEY (`id`),
  ADD KEY `project_plan_id_fk` (`project_id`);

--
-- Indexes for table `galleries`
--
ALTER TABLE `galleries`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `gallery_images`
--
ALTER TABLE `gallery_images`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `heading`
--
ALTER TABLE `heading`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `news`
--
ALTER TABLE `news`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `projects`
--
ALTER TABLE `projects`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `project_images`
--
ALTER TABLE `project_images`
  ADD PRIMARY KEY (`id`),
  ADD KEY `project_id_fk` (`project_id`);

--
-- Indexes for table `settings`
--
ALTER TABLE `settings`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `sliders`
--
ALTER TABLE `sliders`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `testimonials`
--
ALTER TABLE `testimonials`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `abouts`
--
ALTER TABLE `abouts`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `contacts`
--
ALTER TABLE `contacts`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT for table `facilities`
--
ALTER TABLE `facilities`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12;


--
-- AUTO_INCREMENT for table `floor_plan_images`
--
ALTER TABLE `floor_plan_images`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;

--
-- AUTO_INCREMENT for table `galleries`
--
ALTER TABLE `galleries`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=20;

--
-- AUTO_INCREMENT for table `gallery_images`
--
ALTER TABLE `gallery_images`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=39;

--
-- AUTO_INCREMENT for table `heading`
--
ALTER TABLE `heading`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `news`
--
ALTER TABLE `news`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=14;

--
-- AUTO_INCREMENT for table `projects`
--
ALTER TABLE `projects`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=25;

--
-- AUTO_INCREMENT for table `project_images`
--
ALTER TABLE `project_images`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=15;

--
-- AUTO_INCREMENT for table `settings`
--
ALTER TABLE `settings`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=32;

--
-- AUTO_INCREMENT for table `sliders`
--
ALTER TABLE `sliders`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=18;

--
-- AUTO_INCREMENT for table `testimonials`
--
ALTER TABLE `testimonials`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=15;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;
COMMIT;