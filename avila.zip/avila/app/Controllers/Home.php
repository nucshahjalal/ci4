<?php

namespace App\Controllers;
use Models\ContactModel;
class Home extends BaseController {

    protected $session;
    public $title_for_layout = '';
    public $avila = '';
    public $setting = array();    
    public $db = '';
    public $validator = '';
    public $data  = [];

    public function __construct()
    {      
        helper('form');  
        helper('util');  
        $this->db = \Config\Database::connect();
        $this->setting = $this->db->table('settings')->where(['status' => 1])->get()->getRow();         
        $this->data['setting'] = $this->setting; 
        
        if($this->setting){
            $this->avila = $this->setting->name;
        }else{
            $this->avila = 'Structure Housing Design & Development Ltd'; 
        }
        $this->data['title_for_layout'] = $this->avila;
        $this->data['heading'] = $this->db->table('heading')->where(['status' => 1])->get()->getRow();
    } 
    
    public function index() {
        
        $this->data['sliders'] = $this->db->table('sliders')->where(['status' => 1])->orderBy('id','desc')->get()->getResult();
        $this->data['news'] = $this->db->table('news')->where(['status' => 1])->orderBy('id','desc')->get()->getResult();
        $this->data['facilities'] = $this->db->table('facilities')->where(['status' => 1])->orderBy('id','desc')->get()->getResult();
        $this->data['testimonials'] = $this->db->table('testimonials')->where(['status' => 1])->orderBy('id','desc')->get()->getResult(); 
        $this->data['projects'] = $this->db->table('projects')->where(['status' => 1, 'is_featured'=>1])->orderBy('id','desc')->get()->getResult();
       
        return view('front/index', $this->data);
    }
    
    public function completed( $id = null) {
    
        if(!$id){            
            $this->data['project'] = $this->db->table('projects')->where(['status' => 1, 'project_status'=>'completed'])->orderBy('id','desc')->get()->getRow();
        }else{            
            $this->data['project'] = $this->db->table('projects')->where(['status' => 1, 'id'=>$id])->orderBy('id','desc')->get()->getRow();
            $id = $this->data['project']->id;
        }
        
        if(empty($this->data['project'])){
            return $this->response->redirect(site_url());
        }
        
        $this->data['projects'] = $this->db->table('projects')->where(['status' => 1, 'project_status'=>'completed'])->orderBy('id','desc')->get()->getResult();
        $this->data['images'] = $this->db->table('project_images')->where(['status' => 1, 'project_id'=>$id])->orderBy('id','desc')->get()->getResult();
        $this->data['floorplans'] = $this->db->table('floor_plan_images')->where(['status' => 1, 'project_id'=>$id])->orderBy('id','desc')->get()->getResult();
        
        $this->data['project_title'] = $this->data['heading']->complete_title;
        $this->data['project_note'] = $this->data['heading']->complete_note;
        $this->data['project_url'] = 'completed';
        
        return view('front/project', $this->data);
    }
    
    public function ongoing( $id = null) {
        
        if(!$id){            
            $this->data['project'] = $this->db->table('projects')->where(['status' => 1, 'project_status'=>'ongoing'])->orderBy('id','desc')->get()->getRow();
        }else{            
            $this->data['project'] = $this->db->table('projects')->where(['status' => 1, 'id'=>$id])->orderBy('id','desc')->get()->getRow();
            $id = $this->data['project']->id;
        }
        
        if(empty($this->data['project'])){
            return $this->response->redirect(site_url());
        }
        
        $this->data['projects'] = $this->db->table('projects')->where(['status' => 1, 'project_status'=>'ongoing'])->orderBy('id','desc')->get()->getResult();
        $this->data['images'] = $this->db->table('project_images')->where(['status' => 1, 'project_id'=>$id])->orderBy('id','desc')->get()->getResult();
        $this->data['floorplans'] = $this->db->table('floor_plan_images')->where(['status' => 1, 'project_id'=>$id])->orderBy('id','desc')->get()->getResult();
        
        $this->data['project_title'] = $this->data['heading']->ongoing_title;
        $this->data['project_note'] = $this->data['heading']->ongoing_note;
        $this->data['project_url'] = 'ongoing';
        
        
        return view('front/project', $this->data);
    }
    
    public function upcoming( $id = null) {
               
        if(!$id){            
            $this->data['project'] = $this->db->table('projects')->where(['status' => 1, 'project_status'=>'upcoming'])->orderBy('id','desc')->get()->getRow();
        }else{            
            $this->data['project'] = $this->db->table('projects')->where(['status' => 1, 'id'=>$id])->orderBy('id','desc')->get()->getRow();
            $id = $this->data['project']->id;
        }
        
        if(empty($this->data['project'])){
            return $this->response->redirect(site_url());
        }
        
        $this->data['projects'] = $this->db->table('projects')->where(['status' => 1, 'project_status'=>'upcoming'])->orderBy('id','desc')->get()->getResult();
        $this->data['images'] = $this->db->table('project_images')->where(['status' => 1, 'project_id'=>$id])->orderBy('id','desc')->get()->getResult();
        $this->data['floorplans'] = $this->db->table('floor_plan_images')->where(['status' => 1, 'project_id'=>$id])->orderBy('id','desc')->get()->getResult();
        
        $this->data['project_title'] = $this->data['heading']->upcoming_title;
        $this->data['project_note'] = $this->data['heading']->upcoming_note;
        $this->data['project_url'] = 'upcoming';
        
        return view('front/project', $this->data);
    }

    
    public function news() {
        
        $this->data['news'] = $this->db->table('news')->where(['status' => 1])->orderBy('id','desc')->get()->getResult();
        return view('front/news', $this->data);
        
    }

    public function news_detail($id) {        
        
        if(!$id){  
             return $this->response->redirect(site_url());
        }
         
        $this->data['single'] = $this->db->table('news')->where(['status' => 1, 'id'=>$id])->get()->getRow();
      
        $this->data['news'] = $this->db->table('news')->where(['status' => 1])->orderBy('id','desc')->get()->getResult();
        return view('front/news_detail', $this->data);
    }

    public function gallery() {
        
        $this->data['galleries'] = $this->db->table('galleries')->where(['status' => 1])->orderBy('id','desc')->get()->getResult();
        return view('front/gallery', $this->data);
    }

    public function about() {
        
        $this->data['about'] = $this->db->table('abouts')->where(['status' => 1])->get()->getRow();
        return view('front/about', $this->data);
    }
    
    public function contact() {
        
        return view('front/contact', $this->data);
    }
    
    
    public function contactstore() {
        
        if($_POST){
            
        }
        
        return view('front/contact', $this->data);
    }

}
