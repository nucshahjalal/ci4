<?php

namespace App\Controllers;

use CodeIgniter\HTTP\RequestInterface;
use CodeIgniter\HTTP\ResponseInterface;
use Psr\Log\LoggerInterface;

class AvilaController extends BaseController {

    protected $session;
    public $title_for_layout = '';
    public $avila = '';
    public $setting = array();
    public $db = '';
    public $validator = '';
    public $data = [];

    public function initController(RequestInterface $request, ResponseInterface $response, LoggerInterface $logger) {


        // Do Not Edit This Line
        parent::initController($request, $response, $logger);

        $this->db = \Config\Database::connect();
        $this->session = \Config\Services::session();
        $session = session();
        $session->start();
        helper('form');
        helper('url');
        helper('util');

        $this->validator = \Config\Services::validation();
        $this->data['validator'] = $this->validator;
        if (!$this->session->get('id')) {
            $response->redirect(base_url('admin')); // or use $this->response->redirect(base_url('admin'));
        }



        // Get all schools
        $this->setting = $this->db->table('settings')->where(['status' => 1])->get()->getRow();
        $this->data['setting'] = $this->setting;

        if ($this->setting) {
            $this->avila = $this->setting->name;
        } else {
            $this->avila = 'Structure Housing Design & Development Ltd';
        }

        $this->data['title_for_layout'] = $this->avila;
    }

    // its working as constructor
    public function __construct() {
        
    }

}