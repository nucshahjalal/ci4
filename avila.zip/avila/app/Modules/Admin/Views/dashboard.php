<?php echo $this->extend("layouts/master"); ?>
<?php echo $this->section("content"); ?>

<h1 class="text-center" style="padding-top: 200px;">Welcome to AVILABD.com Dashboard</h1>

<?php echo $this->endSection(); ?>