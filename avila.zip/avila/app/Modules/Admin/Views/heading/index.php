<?php echo $this->extend("layouts/master"); ?>
<?php echo $this->section("content"); ?>

<div class="row">
    <div class="col-md-12 col-sm-12 col-xs-12">
        <div class="x_panel">
            <div class="x_title">
                <h3 class="head-title"><i class="fa fa-gears"></i><small> Heading</small></h3>
                <ul class="nav navbar-right panel_toolbox">
                    <li><a class="collapse-link"><i class="fa fa-chevron-up"></i></a></li>                    
                </ul>
                <div class="clearfix"></div>
            </div>
            
            <div class="x_content quick-link">
                <?php  echo $this->include($path. '/quick-link-setting'); ?>               
            </div>
            
            <div class="x_content">
                <div class="" data-example-id="togglable-tabs">
                    
                    <ul  class="nav nav-tabs bordered">
                        <li class="active"><a href="#tab_heading"   role="tab" data-toggle="tab" aria-expanded="true"><i class="fa fa-gear"></i> Heading</a> </li>
                    </ul>
                    <br/>
                    
                    <div class="tab-content">                     
                        <div  class="tab-pane fade in active" id="tab_heading">
                            <div class="x_content"> 
                                
                                <?php 
                                    $attributes = ['class' => 'form-horizontal form-label-left', 'id' => 'heading', 'name'=>'heading'];
                                    $action = 'admin/heading/add';
                                    echo form_open_multipart(site_url($action), $attributes);
                                ?>                                
                                
                                <div class="item form-group">
                                    <label class="control-label col-md-3 col-sm-3 col-xs-12" for="news_title">News Title <span class="required">*</span></label>
                                    <div class="col-md-6 col-sm-6 col-xs-12">
                                        <input  class="form-control col-md-7 col-xs-12"  name="news_title"  id="news_title" required="required" value="<?php echo isset($heading->news_title) ?  $heading->news_title : ''; ?>" placeholder="News Title" type="text">
                                        <div class="help-block"><?php if($validator->getError('news_title')) { echo  $validator->getError('news_title'); } ?></div>
                                    </div>
                                </div> 
                                
                                <div class="item form-group">
                                    <label class="control-label col-md-3 col-sm-3 col-xs-12" for="news_note">News Note </label>
                                    <div class="col-md-6 col-sm-6 col-xs-12">
                                        <textarea  class="form-control" name="news_note" id="news_note" placeholder="News Note"><?php echo isset($heading->news_note) ?  $heading->news_note : ''; ?></textarea>
                                        <div class="help-block"><?php if($validator->getError('news_note')) { echo  $validator->getError('news_note'); } ?></div>
                                    </div>
                                </div>
                                
                                <div class="item form-group">
                                    <label class="control-label col-md-3 col-sm-3 col-xs-12" for="gallery_title">Gallery Title <span class="required">*</span></label>
                                    <div class="col-md-6 col-sm-6 col-xs-12">
                                        <input  class="form-control col-md-7 col-xs-12"  name="gallery_title"  id="gallery_title" required="required"  value="<?php echo isset($heading->gallery_title) ?  $heading->gallery_title : ''; ?>" placeholder="Gallery Title"  type="text">
                                        <div class="help-block"><?php if($validator->getError('gallery_title')) { echo  $validator->getError('gallery_title'); } ?></div>
                                    </div>
                                </div> 
                                
                                <div class="item form-group">
                                    <label class="control-label col-md-3 col-sm-3 col-xs-12" for="gallery_note">Gallery Note </label>
                                    <div class="col-md-6 col-sm-6 col-xs-12">
                                        <textarea  class="form-control" name="gallery_note" id="gallery_note" placeholder="Gallery Note"><?php echo isset($heading->gallery_note) ?  $heading->gallery_note : ''; ?></textarea>
                                        <div class="help-block"><?php if($validator->getError('gallery_note')) { echo  $validator->getError('gallery_note'); } ?></div>
                                    </div>
                                </div>
                                
                                <div class="item form-group">
                                    <label class="control-label col-md-3 col-sm-3 col-xs-12" for="project_title">Project Title <span class="required">*</span></label>
                                    <div class="col-md-6 col-sm-6 col-xs-12">
                                        <input  class="form-control col-md-7 col-xs-12"  name="project_title"  id="project_title"  required="required" value="<?php echo isset($heading->project_title) ?  $heading->project_title : ''; ?>" placeholder="Project Title" type="text">
                                        <div class="help-block"><?php if($validator->getError('project_title')) { echo  $validator->getError('project_title'); } ?></div>
                                    </div>
                                </div> 
                                
                                <div class="item form-group">
                                    <label class="control-label col-md-3 col-sm-3 col-xs-12" for="project_note">Project Note </label>
                                    <div class="col-md-6 col-sm-6 col-xs-12">
                                        <textarea  class="form-control" name="project_note" id="project_note" placeholder="Project Note"><?php echo isset($heading->project_note) ?  $heading->project_note : ''; ?></textarea>
                                        <div class="help-block"><?php if($validator->getError('project_note')) { echo  $validator->getError('project_note'); } ?></div>
                                    </div>
                                </div>
                                
                                <div class="item form-group">
                                    <label class="control-label col-md-3 col-sm-3 col-xs-12" for="progress_title">Progress Title <span class="required">*</span></label>
                                    <div class="col-md-6 col-sm-6 col-xs-12">
                                        <input  class="form-control col-md-7 col-xs-12"  name="progress_title"  id="progress_title"  required="required" value="<?php echo isset($heading->progress_title) ?  $heading->progress_title : ''; ?>" placeholder="Progress Title" type="text">
                                        <div class="help-block"><?php if($validator->getError('progress_title')) { echo  $validator->getError('progress_title'); } ?></div>
                                    </div>
                                </div> 
                                
                                <div class="item form-group">
                                    <label class="control-label col-md-3 col-sm-3 col-xs-12" for="progress_note">Progress Note </label>
                                    <div class="col-md-6 col-sm-6 col-xs-12">
                                        <textarea  class="form-control" name="progress_note" id="progress_note" placeholder="Progress Note"><?php echo isset($heading->progress_note) ?  $heading->progress_note : ''; ?></textarea>
                                       <div class="help-block"><?php if($validator->getError('progress_note')) { echo  $validator->getError('progress_note'); } ?></div>
                                    </div>
                                </div>
                                
                                <div class="item form-group">
                                    <label class="control-label col-md-3 col-sm-3 col-xs-12" for="complete_title">Complete Project Title <span class="required">*</span></label>
                                    <div class="col-md-6 col-sm-6 col-xs-12">
                                        <input  class="form-control col-md-7 col-xs-12"  name="complete_title"  id="complete_title"  required="required" value="<?php echo isset($heading->complete_title) ?  $heading->complete_title : ''; ?>" placeholder="Complete Title" type="text">
                                       <div class="help-block"><?php if($validator->getError('complete_title')) { echo  $validator->getError('complete_title'); } ?></div>
                                    </div>
                                </div> 
                                
                                <div class="item form-group">
                                    <label class="control-label col-md-3 col-sm-3 col-xs-12" for="complete_note">Complete Project Note </label>
                                    <div class="col-md-6 col-sm-6 col-xs-12">
                                        <textarea  class="form-control" name="complete_note" id="complete_note" placeholder="Complete Note"><?php echo isset($heading->complete_note) ?  $heading->complete_note : ''; ?></textarea>
                                        <div class="help-block"><?php if($validator->getError('complete_note')) { echo  $validator->getError('complete_note'); } ?></div>
                                    </div>
                                </div>
                                
                                <div class="item form-group">
                                    <label class="control-label col-md-3 col-sm-3 col-xs-12" for="ongoing_title">Ongoing Project Title <span class="required">*</span></label>
                                    <div class="col-md-6 col-sm-6 col-xs-12">
                                        <input  class="form-control col-md-7 col-xs-12"  name="ongoing_title"  id="ongoing_title"  required="required" value="<?php echo isset($heading->ongoing_title) ?  $heading->ongoing_title : ''; ?>" placeholder="Ongoing Title" type="text">
                                        <div class="help-block"><?php if($validator->getError('ongoing_title')) { echo  $validator->getError('ongoing_title'); } ?></div>
                                    </div>
                                </div> 
                                
                                <div class="item form-group">
                                    <label class="control-label col-md-3 col-sm-3 col-xs-12" for="ongoing_note">Ongoing Project Note </label>
                                    <div class="col-md-6 col-sm-6 col-xs-12">
                                        <textarea  class="form-control" name="ongoing_note" id="ongoing_note" placeholder="Ongoing Note"><?php echo isset($heading->ongoing_note) ?  $heading->ongoing_note : ''; ?></textarea>
                                        <div class="help-block"><?php if($validator->getError('ongoing_note')) { echo  $validator->getError('ongoing_note'); } ?></div>
                                    </div>
                                </div>
                                
                                <div class="item form-group">
                                    <label class="control-label col-md-3 col-sm-3 col-xs-12" for="upcoming_title">Upcoming Project Title <span class="required">*</span></label>
                                    <div class="col-md-6 col-sm-6 col-xs-12">
                                        <input  class="form-control col-md-7 col-xs-12"  name="upcoming_title"  id="upcoming_title"  required="required" value="<?php echo isset($heading->upcoming_title) ?  $heading->upcoming_title : ''; ?>" placeholder="Upcoming Title" type="text">
                                        <div class="help-block"><?php if($validator->getError('upcoming_title')) { echo  $validator->getError('upcoming_title'); } ?></div>
                                    </div>
                                </div> 
                                
                                <div class="item form-group">
                                    <label class="control-label col-md-3 col-sm-3 col-xs-12" for="upcoming_note">Upcoming Project Note </label>
                                    <div class="col-md-6 col-sm-6 col-xs-12">
                                        <textarea  class="form-control" name="upcoming_note" id="upcoming_note" placeholder="Upcoming Note"><?php echo isset($heading->upcoming_note) ?  $heading->upcoming_note : ''; ?></textarea>
                                        <div class="help-block"><?php if($validator->getError('upcoming_note')) { echo  $validator->getError('upcoming_note'); } ?></div>
                                    </div>
                                </div>
                                
                                <div class="item form-group">
                                    <label class="control-label col-md-3 col-sm-3 col-xs-12" for="facility_title">Facility Title <span class="required">*</span></label>
                                    <div class="col-md-6 col-sm-6 col-xs-12">
                                        <input  class="form-control col-md-7 col-xs-12"  name="facility_title"  id="facility_title"  required="required" value="<?php echo isset($heading->facility_title) ?  $heading->facility_title : ''; ?>" placeholder="Facility Title" type="text">
                                        <div class="help-block"><?php if($validator->getError('facility_title')) { echo  $validator->getError('facility_title'); } ?></div>
                                    </div>
                                </div> 
                                
                                <div class="item form-group">
                                    <label class="control-label col-md-3 col-sm-3 col-xs-12" for="facility_note">Facility Note </label>
                                    <div class="col-md-6 col-sm-6 col-xs-12">
                                        <textarea  class="form-control" name="facility_note" id="facility_note" placeholder="Facility Note"><?php echo isset($heading->facility_note) ?  $heading->facility_note : ''; ?></textarea>
                                        <div class="help-block"><?php if($validator->getError('facility_note')) { echo  $validator->getError('facility_note'); } ?></div>
                                    </div>
                                </div>
                                
                                <div class="item form-group">
                                    <label class="control-label col-md-3 col-sm-3 col-xs-12" for="contact_title">Contact Title <span class="required">*</span></label>
                                    <div class="col-md-6 col-sm-6 col-xs-12">
                                        <input  class="form-control col-md-7 col-xs-12"  name="contact_title"  id="contact_title"  required="required" value="<?php echo isset($heading->contact_title) ?  $heading->contact_title : ''; ?>" placeholder="Contact Title" type="text">
                                        <div class="help-block"><?php if($validator->getError('contact_title')) { echo  $validator->getError('contact_title'); } ?></div>
                                    </div>
                                </div> 
                                
                                <div class="item form-group">
                                    <label class="control-label col-md-3 col-sm-3 col-xs-12" for="contact_note">Contact Note </label>
                                    <div class="col-md-6 col-sm-6 col-xs-12">
                                        <textarea  class="form-control" name="contact_note" id="contact_note" placeholder="Contact Note"><?php echo isset($heading->contact_note) ?  $heading->contact_note : ''; ?></textarea>
                                        <div class="help-block"><?php if($validator->getError('contact_note')) { echo  $validator->getError('contact_note'); } ?></div>
                                    </div>
                                </div>
                                                                 
                                <div class="ln_solid"></div>
                                <div class="form-group">
                                    <div class="col-md-6 col-md-offset-3">
                                        <input type="hidden" value="<?php echo isset($heading) ? $heading->id : ''; ?>" name="id" />
                                        <a href="<?php echo site_url('admin/heading'); ?>" class="btn btn-primary">Cancel</a>
                                        <button id="send" type="submit" class="btn btn-success">Submit</button>
                                    </div>
                                </div>
                                <?php echo form_close(); ?>                                                            
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<script type="text/javascript">
    
    $("#heading").validate();  
    
</script>

<?php echo $this->endSection(); ?>