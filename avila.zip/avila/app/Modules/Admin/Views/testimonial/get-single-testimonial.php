<table class="table table-striped table-bordered dt-responsive nowrap" cellspacing="0" width="100%">
    <tbody>
        <tr>
            <th width="25%">Client Name </th>
            <td> <?php echo $testimonial->name; ?></td> 
        </tr>
          
        <tr>
            <th>Designation </th>
            <td> <?php echo $testimonial->designation; ?></td> 
        </tr>
        
        <tr>
            <th>Rating </th>
            <td> <?php echo $testimonial->rating; ?></td> 
        </tr>
        
        <tr>
            <th>Testimonial </th>
            <td> <?php echo $testimonial->testimonial; ?></td> 
        </tr>
        
        <tr>
            <th>Image </th>
            <td colspan="3">
                <?php if($testimonial->image){ ?>
                    <img src="<?php echo base_url(UPLOAD_PATH); ?>/testimonial/<?php echo $testimonial->image; ?>" alt="" width="100" />
                <?php } ?>
            </td> 
        </tr>
        <tr>
            <th>Status </th>
            <td> <?php echo $testimonial->status ==1? 'Active' : 'Inactive'; ?></td> 
        </tr>
        
    </tbody>
</table>
