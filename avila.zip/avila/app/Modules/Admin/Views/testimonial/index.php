<?php echo $this->extend("layouts/master"); ?>
<?php echo $this->section("content"); ?>

<div class="row">
    <div class="col-md-12 col-sm-12 col-xs-12">
        <div class="x_panel">
            <div class="x_title">
                <h3 class="head-title"><i class="fa fa-male"></i><small> Manage Testimonials</small></h3>
                <ul class="nav navbar-right panel_toolbox">
                    <li><a class="collapse-link"><i class="fa fa-chevron-up"></i></a></li>                    
                </ul>
                <div class="clearfix"></div>
            </div>
            <div class="x_content">
                <div class="" data-example-id="togglable-tabs">
                    
                    <ul  class="nav nav-tabs bordered">
                        <li class="<?php if(isset($list)){ echo 'active'; }?>"><a href="#tab_testimonial_list"   role="tab" data-toggle="tab" aria-expanded="true"><i class="fa fa-list-ol"></i> List</a> </li>
                        <li  class="<?php if(isset($add)){ echo 'active'; }?>"><a href="#tab_add_testimonial"  role="tab"  data-toggle="tab" aria-expanded="false"><i class="fa fa-plus-square-o"></i> Add </a> </li>                          
                        <?php if(isset($edit)){ ?>
                            <li  class="active"><a href="#tab_edit_testimonial"  role="tab"  data-toggle="tab" aria-expanded="false"><i class="fa fa-pencil-square-o"></i> Edit</a> </li>                          
                        <?php } ?>                
                    </ul>
                    <br/>
                    
                    <div class="tab-content">
                        <div  class="tab-pane fade in <?php if(isset($list)){ echo 'active'; }?>" id="tab_testimonial_list" >
                            <div class="x_content">
                            <table id="datatable-responsive" class="table table-striped table-bordered dt-responsive nowrap" cellspacing="0" width="100%">
                                <thead>
                                    <tr>
                                        <th>#Sl</th>
                                        <th>Client Name</th>
                                        <th>Designation</th>
                                        <th>Rating</th>
                                        <th>Image/Photo</th>
                                        <th>Status</th>
                                        <th>Action</th>                                            
                                    </tr>
                                </thead>
                                <tbody>   
                                    <?php $count = 1; if(isset($testimonials) && !empty($testimonials)){ ?>
                                        <?php foreach($testimonials as $obj){ ?>
                                        <tr>
                                            <td><?php echo $count++; ?></td>
                                            <td><?php echo $obj->name; ?></td>
                                            <td><?php echo $obj->designation; ?></td>
                                            <td><?php echo $obj->rating; ?></td>
                                            <td>
                                                <?php if($obj->image){ ?>
                                                <img src="<?php echo base_url(UPLOAD_PATH); ?>/testimonial/<?php echo $obj->image; ?>" alt="" width="60" /><br/><br/>
                                                <?php } ?>
                                            </td>
                                            <td><?php echo $obj->status == 1? 'Active' : 'Inactive'; ?></td>
                                            <td>
                                                 <a  onclick="get_testimonial_modal(<?php echo $obj->id; ?>);"data-toggle="modal" data-target=".bs-testimonial-modal-lg"  class="btn btn-success btn-xs"><i class="fa fa-eye"></i> View </a>
                                                <a href="<?php echo site_url('admin/testimonial/edit/'.$obj->id); ?>" class="btn btn-info btn-xs"><i class="fa fa-pencil-square-o"></i> Edit </a>
                                                <a href="<?php echo site_url('admin/testimonial/delete/'.$obj->id); ?>" onclick="javascript: return confirm('Are you sure you want to delete this testimonial?');" class="btn btn-danger btn-xs"><i class="fa fa-trash-o"></i> Delete </a>
                                            </td>
                                        </tr>
                                        <?php } ?>
                                    <?php } ?>
                                </tbody>
                            </table>
                            </div>
                        </div>

                        <div  class="tab-pane fade in <?php if(isset($add)){ echo 'active'; }?>" id="tab_add_testimonial">
                            <div class="x_content"> 

                                <?php 
                                    $attributes = ['class' => 'form-horizontal form-label-left', 'id' => 'add', 'name'=>'add'];
                                    echo form_open_multipart(site_url('admin/testimonial/add'), $attributes);
                                ?>
                                
                                <div class="item form-group">
                                    <label class="control-label col-md-3 col-sm-3 col-xs-12" for="name">Client Name <span class="required">*</span></label>
                                    <div class="col-md-6 col-sm-6 col-xs-12">
                                        <input  class="form-control col-md-7 col-xs-12"  name="name"  id="name" value="<?php echo isset($post['name']) ?  $post['name'] : ''; ?>" required="required" placeholder="Name" type="text">
                                        <div class="help-block"><?php if($validator->getError('name')) { echo  $validator->getError('name'); } ?></div>
                                    </div>
                                </div>
                                
                                <div class="item form-group">
                                    <label class="control-label col-md-3 col-sm-3 col-xs-12" for="designation">Designation </label>
                                    <div class="col-md-6 col-sm-6 col-xs-12">
                                        <input  class="form-control col-md-7 col-xs-12"  name="designation"  id="designation"  value="<?php echo isset($post['designation']) ?  $post['designation'] : ''; ?>" placeholder="Designation" type="text">
                                        <div class="help-block"><?php if($validator->getError('designation')) { echo  $validator->getError('designation'); } ?></div>
                                    </div>
                                </div>
                                
                                <div class="item form-group">
                                    <label class="control-label col-md-3 col-sm-3 col-xs-12" for="rating">Rating <span class="required">*</span></label>
                                    <div class="col-md-6 col-sm-6 col-xs-12">
                                        <select  class="form-control col-md-7 col-xs-12"  name="rating"  id="rating" required="required">
                                            <option value="">--Select rating--</option>
                                            <option value="1">1</option>
                                            <option value="2">2</option>
                                            <option value="3">3</option>
                                            <option value="4">4</option>
                                            <option value="5">5</option>
                                        </select>
                                        <div class="help-block"><?php if($validator->getError('rating')) { echo  $validator->getError('rating'); } ?></div>
                                    </div>
                                </div>
                                
                                <div class="form-group">
                                   <label class="control-label col-md-3 col-sm-3 col-xs-12">Image/Photo <span class="required">*</span></label>
                                   <div class="col-md-6 col-sm-6 col-xs-12">                                      
                                        <div class="btn btn-default btn-file">
                                            <i class="fa fa-paperclip"></i> Upload
                                            <input type="file" name="image" >
                                        </div>
                                       <div class="help-block" style="color:#646362;">Image Dimension: W: 150px, H: 150px</div>
                                        <div class="help-block"><?php if($validator->getError('image')) { echo  $validator->getError('image'); } ?></div>
                                    </div>
                                </div>
                                
                                <div class="item form-group">
                                    <label class="control-label col-md-3 col-sm-3 col-xs-12" for="testimonial">Testimonial <span class="required">*</span></label>
                                    <div class="col-md-6 col-sm-6 col-xs-12">
                                        <textarea  class="form-control" name="testimonial" id="testimonial" required="required" placeholder="Testimonial"><?php echo isset($post['testimonial']) ?  $post['testimonial'] : ''; ?></textarea>
                                        <div class="help-block"><?php if($validator->getError('testimonial')) { echo  $validator->getError('testimonial'); } ?></div>
                                    </div>
                                </div> 
                              
                                <div class="ln_solid"></div>
                                <div class="form-group">
                                    <div class="col-md-6 col-md-offset-3">
                                        <a href="<?php echo site_url('admin/testimonial'); ?>" class="btn btn-primary">Cancel</a>
                                        <button id="send" type="submit" class="btn btn-success">Submit</button>
                                    </div>
                                </div>
                                <?php echo form_close(); ?>
                                                            
                            </div>
                        </div>  

                        <?php if(isset($edit)){ ?>
                        <div class="tab-pane fade in active" id="tab_edit_testimonial">
                            <div class="x_content"> 

                                <?php 
                                    $attributes = ['class' => 'form-horizontal form-label-left', 'id' => 'edit', 'name'=>'edit'];
                                    echo form_open_multipart(site_url('admin/testimonial/edit/'.$testimonial->id), $attributes);
                                ?>
                                
                                <div class="item form-group">
                                    <label class="control-label col-md-3 col-sm-3 col-xs-12" for="name">Client Name <span class="required">*</span></label>
                                    <div class="col-md-6 col-sm-6 col-xs-12">
                                        <input  class="form-control col-md-7 col-xs-12"  name="name"  id="name" required="required" value="<?php echo isset($testimonial->name) ?  $testimonial->name : ''; ?>" placeholder="Name" type="text">
                                        <div class="help-block"><?php if($validator->getError('name')) { echo  $validator->getError('name'); } ?></div>
                                    </div>
                                </div>      
                                
                                <div class="item form-group">
                                    <label class="control-label col-md-3 col-sm-3 col-xs-12" for="designation">Designation </label>
                                    <div class="col-md-6 col-sm-6 col-xs-12">
                                        <input  class="form-control col-md-7 col-xs-12"  name="designation"  id="designation"  value="<?php echo isset($testimonial->designation) ?  $testimonial->designation : ''; ?>" placeholder="Designation" type="text">
                                        <div class="help-block"><?php if($validator->getError('designation')) { echo  $validator->getError('designation'); } ?></div>
                                    </div>
                                </div>
                                
                                <div class="item form-group">
                                    <label class="control-label col-md-3 col-sm-3 col-xs-12" for="rating">Rating <span class="required">*</span></label>
                                    <div class="col-md-6 col-sm-6 col-xs-12">
                                        <select  class="form-control col-md-7 col-xs-12"  name="rating"  id="rating" required="required">
                                            <option value="">--Select rating--</option>
                                            <option value="1" <?php if(isset($testimonial) && $testimonial->rating == 1){ echo 'selected="selected"'; } ?>>1</option>
                                            <option value="2" <?php if(isset($testimonial) && $testimonial->rating == 2){ echo 'selected="selected"'; } ?>>2</option>
                                            <option value="3" <?php if(isset($testimonial) && $testimonial->rating == 3){ echo 'selected="selected"'; } ?>>3</option>
                                            <option value="4" <?php if(isset($testimonial) && $testimonial->rating == 4){ echo 'selected="selected"'; } ?>>4</option>
                                            <option value="5" <?php if(isset($testimonial) && $testimonial->rating == 5){ echo 'selected="selected"'; } ?>>5</option>
                                        </select>
                                        <div class="help-block"><?php if($validator->getError('rating')) { echo  $validator->getError('rating'); } ?></div>
                                    </div>
                                </div>
                                
                                <div class="form-group">
                                   <label class="control-label col-md-3 col-sm-3 col-xs-12">Image/ Photo</label>
                                   <div class="col-md-6 col-sm-6 col-xs-12"> 
                                        <?php if(isset($testimonial) && $testimonial->image){ ?>
                                            <img src="<?php echo base_url(UPLOAD_PATH); ?>/testimonial/<?php echo $testimonial->image; ?>" alt="" width="80" /><br/><br/>
                                             <input name="image_prev" value="<?php echo isset($testimonial) ? $testimonial->image : ''; ?>"  type="hidden">
                                        <?php } ?>
                                        <div class="btn btn-default btn-file">
                                            <i class="fa fa-paperclip"></i> Upload
                                            <input type="file" name="image" >
                                        </div>
                                        <div class="help-block" style="color:#646362;">Image Dimension: W: 150px, H: 150px</div>     
                                        <div class="help-block"><?php if($validator->getError('image')) { echo  $validator->getError('image'); } ?></div>
                                    </div>
                                </div> 
                                
                                <div class="item form-group">
                                    <label class="control-label col-md-3 col-sm-3 col-xs-12" for="testimonial">Testimonial <span class="required">*</span></label>
                                    <div class="col-md-6 col-sm-6 col-xs-12">
                                        <textarea  class="form-control" name="testimonial" id="testimonial" required="required" placeholder="Testimonial"><?php echo isset($testimonial->testimonial) ?  $testimonial->testimonial : ''; ?></textarea>
                                       <div class="help-block"><?php if($validator->getError('testimonial')) { echo  $validator->getError('testimonial'); } ?></div>
                                    </div>
                                </div>                                 
                                
                                <div class="item form-group">
                                    <label class="control-label col-md-3 col-sm-3 col-xs-12" for="status">Status </label>
                                    <div class="col-md-6 col-sm-6 col-xs-12">
                                        <select  class="form-control col-md-7 col-xs-12"  name="status"  id="status">
                                            <option value="">--Select status-- </option>
                                            <option value="1" <?php if(isset($testimonial) && $testimonial->status == 1){ echo 'selected="selected"'; } ?>>Active</option>
                                            <option value="0" <?php if(isset($testimonial) && $testimonial->status == 0){ echo 'selected="selected"'; } ?>>In Active</option>
                                        </select>
                                        <div class="help-block"><?php if($validator->getError('status')) { echo  $validator->getError('status'); } ?></div>
                                    </div>
                                </div>
                                                                                                                            
                                <div class="ln_solid"></div>
                                <div class="form-group">
                                    <div class="col-md-6 col-md-offset-3">
                                        <input type="hidden" value="<?php echo isset($testimonial) ? $testimonial->id : ''; ?>" name="id" />
                                        <a href="<?php echo site_url('admin/testimonial'); ?>" class="btn btn-primary">Cancel</a>
                                        <button id="send" type="submit" class="btn btn-success">Update</button>
                                    </div>
                                </div>
                                <?php echo form_close(); ?>
                            </div>
                        </div>  
                        <?php } ?>
                        
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<div class="modal fade bs-testimonial-modal-lg" tabindex="-1" role="dialog" aria-hidden="true">
    <div class="modal-dialog modal-lg">
      <div class="modal-content">
        <div class="modal-header">
          <button type="button" class="close" data-dismiss="modal"><span aria-hidden="true">×</span></button>
          <h4 class="modal-title">Testimonial Details</h4>
        </div>
        <div class="modal-body fn_testimonial_data">            
        </div>       
      </div>
    </div>
</div>

<script type="text/javascript">
      
    function get_testimonial_modal(testi_id){
       // alert('tet');
        $('.fn_testimonial_data').html('<p style="padding: 20px;"><p style="padding: 20px;text-align:center;"><img src="<?php echo base_url(IMG_URL); ?>/loader.gif" /></p>');
        $.ajax({       
          type   : "POST",
          url    : "<?php echo base_url('admin/testimonial/view'); ?>",
          data   : {testi_id : testi_id},  
          success: function(response){                                                   
             if(response)
             {
                $('.fn_testimonial_data').html(response);
             }
          }
       });
    }
    
</script>

<!-- datatable with buttons -->
 <script type="text/javascript">
     
        $(document).ready(function() {
          $('#datatable-responsive').DataTable( {
              dom: 'Bfrtip',
              iDisplayLength: 15,
              buttons: [
                  'copyHtml5',
                  'excelHtml5',
                  'csvHtml5',
                  'pdfHtml5',
                  'pageLength'
              ],
              search: true
          });
        });
        
        $('#add').validate();
        $('#edit').validate();
        
</script>

<?php echo $this->endSection(); ?>