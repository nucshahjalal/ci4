<strong>Quick Menu : </strong>

<a href="<?php echo site_url('admin/project'); ?>"> Project</a>
| <a href="<?php echo site_url('admin/projectimage'); ?>"> Project Image</a>
| <a href="<?php echo site_url('admin/floorplan'); ?>"> Floor Plan</a>
