<?php echo $this->extend("layouts/master"); ?>
<?php echo $this->section("content"); ?>

<div class="row">
    <div class="col-md-12 col-sm-12 col-xs-12">
        <div class="x_panel">
            <div class="x_title">
                <h3 class="head-title"><i class="fa fa-sliders"></i><small> Manage Slider</small></h3>
                <ul class="nav navbar-right panel_toolbox">
                    <li><a class="collapse-link"><i class="fa fa-chevron-up"></i></a></li>                    
                </ul>
                <div class="clearfix"></div>
            </div>
            <div class="x_content">
                <div class="" data-example-id="togglable-tabs">
                    
                    <ul  class="nav nav-tabs bordered">
                        <li class="<?php if(isset($list)){ echo 'active'; }?>"><a href="#tab_slider_list"   role="tab" data-toggle="tab" aria-expanded="true"><i class="fa fa-list-ol"></i> List</a> </li>
                        <li  class="<?php if(isset($add)){ echo 'active'; }?>"><a href="#tab_add_slider"  role="tab"  data-toggle="tab" aria-expanded="false"><i class="fa fa-plus-square-o"></i> Add</a> </li>                          
                        <?php if(isset($edit)){ ?>
                            <li  class="active"><a href="#tab_edit_slider"  role="tab"  data-toggle="tab" aria-expanded="false"><i class="fa fa-pencil-square-o"></i> Edit</a> </li>                          
                        <?php } ?>                
                    </ul>
                    <br/>
                    
                    <div class="tab-content">
                        <div  class="tab-pane fade in <?php if(isset($list)){ echo 'active'; }?>" id="tab_slider_list" >
                            <div class="x_content">
                            <table id="datatable-responsive" class="table table-striped table-bordered dt-responsive nowrap" cellspacing="0" width="100%">
                                <thead>
                                    <tr>
                                        <th>#Sl</th>
                                        <th>Slider Title/ Caption</th>
                                        <th>Image</th>
                                        <th>Status</th>                                       
                                        <th>Action</th>                                            
                                    </tr>
                                </thead>
                                <tbody>   
                                    <?php $count = 1; if(isset($sliders) && !empty($sliders)){ ?>
                                        <?php foreach($sliders as $obj){ ?>
                                        <tr>
                                            <td><?php echo $count++; ?></td>
                                            <td><?php echo $obj->title; ?></td>
                                            <td>
                                            <?php if($obj->image){ ?>
                                            <img src="<?php echo base_url(UPLOAD_PATH); ?>/slider/<?php echo $obj->image; ?>" alt="" width="60" /><br/><br/>
                                            <?php } ?>
                                            </td>
                                            <td><?php echo $obj->status == 1? 'Active' : 'Inactive'; ?></td>
                                            <td>
                                                <a href="<?php echo site_url('admin/slider/edit/'.$obj->id); ?>" class="btn btn-info btn-xs"><i class="fa fa-pencil-square-o"></i> Edit </a>
                                                <a href="<?php echo site_url('admin/slider/delete/'.$obj->id); ?>" onclick="javascript: return confirm('Are you sure you want to delete this slider?');" class="btn btn-danger btn-xs"><i class="fa fa-trash-o"></i> Delete </a>
                                            </td>
                                        </tr>
                                        <?php } ?>
                                    <?php } ?>
                                </tbody>
                            </table>
                            </div>
                        </div>

                        <div  class="tab-pane fade in <?php if(isset($add)){ echo 'active'; }?>" id="tab_add_slider">
                            <div class="x_content"> 

                                <?php 
                                    $attributes = ['class' => 'form-horizontal form-label-left', 'id' => 'add', 'name'=>'add'];
                                    echo form_open_multipart(site_url('admin/slider/add'), $attributes);
                                ?>
                                
                                <div class="item form-group">
                                    <label class="control-label col-md-3 col-sm-3 col-xs-12" for="title">Slider Title/ Caption <span class="required">*</span></label>
                                    <div class="col-md-6 col-sm-6 col-xs-12">
                                        <input  class="form-control col-md-7 col-xs-12"  name="title"  id="title" value="<?php echo isset($post['title']) ?  $post['title'] : ''; ?>" required="required" placeholder="Title" type="text">
                                        <div class="help-block"><?php if($validator->getError('title')) { echo  $validator->getError('title'); } ?></div>
                                    </div>
                                </div> 
                              
                               <div class="form-group">
                                   <label class="control-label col-md-3 col-sm-3 col-xs-12">Image <span class="required">*</span></label>
                                   <div class="col-md-6 col-sm-6 col-xs-12">                                      
                                        <div class="btn btn-default btn-file">
                                            <i class="fa fa-paperclip"></i> Upload
                                            <input type="file" name="image" required="required">
                                        </div>
                                       <div class="help-block" style="color:#646362;">Image Dimension: W: 1920px, H: 900px</div> 
                                       <div class="help-block"><?php if($validator->getError('image')) { echo  $validator->getError('image'); } ?></div>
                                    </div>
                                </div>                                        
                               
                                    
                                <div class="ln_solid"></div>
                                <div class="form-group">
                                    <div class="col-md-6 col-md-offset-3">
                                        <a href="<?php echo site_url('admin/slider'); ?>" class="btn btn-primary">Cancel</a>
                                        <button id="send" type="submit" class="btn btn-success">Submit</button>
                                    </div>
                                </div>
                                <?php echo form_close(); ?>
                                                            
                            </div>
                        </div>  

                        <?php if(isset($edit)){ ?>
                        <div class="tab-pane fade in active" id="tab_edit_slider">
                            <div class="x_content"> 
                                
                                <?php 
                                    $attributes = ['class' => 'form-horizontal form-label-left', 'id' => 'edit', 'name'=>'edit'];
                                    echo form_open_multipart(site_url('admin/slider/edit/'.$slider->id), $attributes);
                                ?> 
                                
                                <div class="item form-group">
                                    <label class="control-label col-md-3 col-sm-3 col-xs-12" for="title">Slider Title/ Caption <span class="required">*</span></label>
                                    <div class="col-md-6 col-sm-6 col-xs-12">
                                        <input  class="form-control col-md-7 col-xs-12"  name="title"  id="title" value="<?php echo isset($slider->title) ?  $slider->title : ''; ?>" required="required" placeholder="Title" type="text">
                                        <div class="help-block"><?php if($validator->getError('title')) { echo  $validator->getError('title'); } ?></div>
                                    </div>
                                </div>                               
                                
                                <div class="form-group">
                                   <label class="control-label col-md-3 col-sm-3 col-xs-12">Image <span class="required">*</span></label>
                                   <div class="col-md-6 col-sm-6 col-xs-12"> 
                                        <?php if(isset($slider) && $slider->image != ''){ ?>
                                            <img src="<?php echo base_url(UPLOAD_PATH); ?>/slider/<?php echo $slider->image; ?>" alt="" width="100" /><br/><br/>
                                             <input name="image_prev" value="<?php echo isset($slider) ? $slider->image : ''; ?>"  type="hidden">
                                        <?php } ?>
                                        <div class="btn btn-default btn-file">
                                            <i class="fa fa-paperclip"></i> Upload
                                            <input type="file" name="image" >
                                        </div>
                                        <div class="help-block" style="color:#646362;">Image Dimension: W: 1920px, H: 900px</div>      
                                        <div class="help-block"><?php if($validator->getError('image')) { echo  $validator->getError('image'); } ?></div>
                                    </div>
                                </div>      
                                 
                                <div class="item form-group">
                                    <label class="control-label col-md-3 col-sm-3 col-xs-12" for="status">Status </label>
                                    <div class="col-md-6 col-sm-6 col-xs-12">
                                        <select  class="form-control col-md-7 col-xs-12"  name="status"  id="status">
                                            <option value="">--Select status-- </option>
                                            <option value="1" <?php if(isset($slider) && $slider->status == 1){ echo 'selected="selected"'; } ?>>Active</option>
                                            <option value="0" <?php if(isset($slider) && $slider->status == 0){ echo 'selected="selected"'; } ?>>In Active</option>
                                        </select>
                                        <div class="help-block"><?php if($validator->getError('status')) { echo  $validator->getError('status'); } ?></div>
                                    </div>
                                </div>
                                
                                <div class="ln_solid"></div>
                                <div class="form-group">
                                    <div class="col-md-6 col-md-offset-3">
                                        <input type="hidden" value="<?php echo isset($slider) ? $slider->id : $id; ?>" name="id" />
                                        <a href="<?php echo site_url('admin/slider'); ?>" class="btn btn-primary">Cancel</a>
                                        <button id="send" type="submit" class="btn btn-success">Update</button>
                                    </div>
                                </div>
                                <?php echo form_close(); ?>
                            </div>
                        </div>  
                        <?php } ?>
                        
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<!-- datatable with buttons -->
 <script type="text/javascript">
     
        $(document).ready(function() {
          $('#datatable-responsive').DataTable( {
              dom: 'Bfrtip',
              iDisplayLength: 15,
              buttons: [
                  'copyHtml5',
                  'excelHtml5',
                  'csvHtml5',
                  'pdfHtml5',
                  'pageLength'
              ],
              search: true
          });
        });
        
         $('#add').validate();
        $('#edit').validate();
        
</script>

<?php echo $this->endSection(); ?>