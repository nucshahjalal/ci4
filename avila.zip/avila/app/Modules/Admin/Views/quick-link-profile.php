<strong>Quick Menu : </strong>

<a href="<?php echo site_url('admin/profile'); ?>"> My Profile</a>
| <a href="<?php echo site_url('admin/profile/password'); ?>"> Reset Password</a>
| <a href="<?php echo site_url('admin/logout'); ?>"> Logout</a>
