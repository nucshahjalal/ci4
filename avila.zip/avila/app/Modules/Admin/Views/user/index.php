<?php echo $this->extend("layouts/master"); ?>
<?php echo $this->section("content"); ?>

<div class="row">
    <div class="col-md-12 col-sm-12 col-xs-12">
        <div class="x_panel">
            <div class="x_title">
                <h3 class="head-title"><i class="fa fa-users"></i><small> Manage Users</small></h3>
                <ul class="nav navbar-right panel_toolbox">
                    <li><a class="collapse-link"><i class="fa fa-chevron-up"></i></a></li>                    
                </ul>
                <div class="clearfix"></div>
            </div>
            <div class="x_content">
                <div class="" data-example-id="togglable-tabs">
                    
                    <ul  class="nav nav-tabs bordered">
                        <li class="<?php if(isset($list)){ echo 'active'; }?>"><a href="#tab_user_list"   role="tab" data-toggle="tab" aria-expanded="true"><i class="fa fa-list-ol"></i> User List</a> </li>
                        <li  class="<?php if(isset($add)){ echo 'active'; }?>"><a href="#tab_add_user"  role="tab"  data-toggle="tab" aria-expanded="false"><i class="fa fa-plus-square-o"></i> Add User</a> </li>                          
                        <?php if(isset($edit)){ ?>
                            <li  class="active"><a href="#tab_edit_user"  role="tab"  data-toggle="tab" aria-expanded="false"><i class="fa fa-pencil-square-o"></i> Edit User</a> </li>                          
                        <?php } ?>                
                    </ul>
                    <br/>
                    
                    <div class="tab-content">
                        <div  class="tab-pane fade in <?php if(isset($list)){ echo 'active'; }?>" id="tab_user_list" >
                            <div class="x_content">
                            <table id="datatable-responsive" class="table table-striped table-bordered dt-responsive nowrap" cellspacing="0" width="100%">
                                <thead>
                                    <tr>
                                        <th>#Sl</th>
                                        <th>Photo</th>
                                        <th>Name</th>
                                        <th>Email</th>
                                        <th>Mobile</th>
                                        <th>User Type</th>
                                        <th>Address</th>
                                        <th>Last Logged In</th>
                                        <th>Action</th>                                            
                                    </tr>
                                </thead>
                                <tbody>   
                                    <?php $count = 1; if(isset($users) && !empty($users)){ ?>
                                        <?php foreach($users as $obj){ ?>
                                        <tr>
                                            <td><?php echo $count++; ?></td>
                                            <td>
                                                <?php if($obj->image){ ?>
                                                    <img src="<?php echo base_url(UPLOAD_PATH); ?>/user/<?php echo $obj->image; ?>" alt="" width="80" />
                                                <?php }else{ ?>
                                                    <img src="<?php echo base_url(IMG_URL); ?>/default.jpg" alt="" width="80" /><br/><br/>
                                                <?php } ?>
                                            </td>
                                            <td><?php echo $obj->name; ?></td>
                                            <td><?php echo $obj->email; ?></td>
                                            <td><?php echo $obj->mobile; ?></td>
                                            <td><?php echo $obj->user_type == 1? 'Admin' : 'Employee'; ?></td>
                                            <td><?php echo $obj->address; ?></td>
                                            <td><?php echo $obj->last_logged_in; ?></td>
                                            <td>
                                                <a href="<?php echo site_url('admin/user/edit/'.$obj->id); ?>" class="btn btn-info btn-xs"><i class="fa fa-pencil-square-o"></i> Edit </a>
                                                <?php if(!$obj->is_default ){ ?>
                                                 <a href="<?php echo site_url('admin/user/delete/'.$obj->id); ?>" onclick="javascript: return confirm('Are you sure you want to delete this user?');" class="btn btn-danger btn-xs"><i class="fa fa-trash-o"></i> Delete </a>
                                                <?php } ?>
                                            </td>
                                        </tr>
                                        <?php } ?>
                                    <?php } ?>
                                </tbody>
                            </table>
                            </div>
                        </div>

                        <div  class="tab-pane fade in <?php if(isset($add)){ echo 'active'; }?>" id="tab_add_user">
                            <div class="x_content">
                                
                               <?php 
                                $attributes = ['class' => 'form-horizontal form-label-left', 'id' => 'add', 'name'=>'add'];
                                echo form_open_multipart(site_url('admin/user/add'), $attributes);
                               ?>
                                
                                <div class="item form-group">
                                    <label class="control-label col-md-3 col-sm-3 col-xs-12" for="name">Name <span class="required">*</span></label>
                                    <div class="col-md-6 col-sm-6 col-xs-12">
                                        <input  class="form-control col-md-7 col-xs-12"  name="name"  id="name" value="<?php echo isset($post['name']) ?  $post['name'] : ''; ?>" placeholder="Name" required="required"  type="text" autocomplete="off">
                                        <div class="help-block"><?php if($validator->getError('name')) { echo  $validator->getError('name'); } ?></div>
                                    </div>
                                </div> 
                              
                                <div class="item form-group">
                                    <label class="control-label col-md-3 col-sm-3 col-xs-12" for="user_type">User Type <span class="required">*</span>
                                    </label>
                                    <div class="col-md-6 col-sm-6 col-xs-12">
                                        <select  class="form-control col-md-7 col-xs-12"  name="user_type"  id="user_type" required="required">
                                            <?php $user_types = get_user_type(); ?>
                                            <option value="">--Select user--</option>
                                            <?php foreach($user_types as $key=>$value){ ?>
                                                <option value="<?php echo $key; ?>" <?php echo isset($post['user_type']) && $post['user_type'] == $key ?  'selected="selected"' : ''; ?>><?php echo $value; ?></option>
                                            <?php } ?>
                                        </select>
                                        <div class="help-block"><?php if($validator->getError('user_type')) { echo  $validator->getError('user_type'); } ?></div>
                                    </div>
                                </div>
                                
                                <div class="item form-group">
                                    <label class="control-label col-md-3 col-sm-3 col-xs-12" for="email">Email <span class="required">*</span></label>
                                    <div class="col-md-6 col-sm-6 col-xs-12">
                                        <input  class="form-control col-md-7 col-xs-12"  name="email"  id="email" value="<?php echo isset($post['email']) ?  $post['email'] : ''; ?>" placeholder="Email" required="required" type="email" autocomplete="off">
                                        <div class="help-block"><?php if($validator->getError('email')) { echo  $validator->getError('email'); } ?></div>
                                    </div>
                                </div>
                                
                                <div class="item form-group">
                                    <label class="control-label col-md-3 col-sm-3 col-xs-12" for="password">Password <span class="required">*</span></label>
                                    <div class="col-md-6 col-sm-6 col-xs-12">
                                        <input  class="form-control col-md-7 col-xs-12"  name="password"  id="password" value="<?php echo isset($post['password']) ?  $post['password'] : ''; ?>" placeholder="Password" required="required" type="password" autocomplete="off">
                                        <div class="help-block"><?php if($validator->getError('password')) { echo  $validator->getError('password'); } ?></div>
                                    </div>
                                </div>
                                
                                <div class="item form-group">
                                    <label class="control-label col-md-3 col-sm-3 col-xs-12" for="mobile">Mobile <span class="required">*</span></label>
                                    <div class="col-md-6 col-sm-6 col-xs-12">
                                        <input  class="form-control col-md-7 col-xs-12"  name="mobile"  id="mobile" value="<?php echo isset($post['mobile']) ?  $post['mobile'] : ''; ?>" placeholder="Mobile" required="required" type="text" autocomplete="off">
                                        <div class="help-block"><?php if($validator->getError('mobile')) { echo  $validator->getError('mobile'); } ?></div>
                                    </div>
                                </div>
                                
                                <div class="item form-group">
                                    <label class="control-label col-md-3 col-sm-3 col-xs-12" for="address">Address</label>
                                    <div class="col-md-6 col-sm-6 col-xs-12">
                                        <input  class="form-control col-md-7 col-xs-12"  name="address"  id="address" value="<?php echo isset($post['address']) ?  $post['address'] : ''; ?>" placeholder="Address" type="text" autocomplete="off">
                                        <div class="help-block"><?php if($validator->getError('address')) { echo  $validator->getError('address'); } ?></div>
                                    </div>
                                </div>
                                
                                <div class="form-group">
                                   <label class="control-label col-md-3 col-sm-3 col-xs-12">Photo </label>
                                   <div class="col-md-6 col-sm-6 col-xs-12">                                      
                                        <div class="btn btn-default btn-file">
                                            <i class="fa fa-paperclip"></i> Upload
                                            <input type="file" name="image" >
                                        </div>
                                        <div class="help-block"><?php if($validator->getError('image')) { echo  $validator->getError('image'); } ?></div>
                                    </div>
                                </div>   
                                    
                                <div class="ln_solid"></div>
                                <div class="form-group">
                                    <div class="col-md-6 col-md-offset-3">
                                        <a href="<?php echo site_url('admin/user'); ?>" class="btn btn-primary">Cancel</a>
                                        <button id="send" type="submit" class="btn btn-success">Submit</button>
                                    </div>
                                </div>
                                <?php echo form_close(); ?>
                                                            
                            </div>
                        </div>  

                        <?php if(isset($edit)){ ?>
                        <div class="tab-pane fade in active" id="tab_edit_user">
                            <div class="x_content"> 
                                
                                <?php 
                                    $attributes = ['class' => 'form-horizontal form-label-left', 'id' => 'edit', 'name'=>'edit'];
                                    echo form_open_multipart(site_url('admin/user/edit/'.$user->id), $attributes);
                                ?>
                                
                                <div class="item form-group">
                                    <label class="control-label col-md-3 col-sm-3 col-xs-12" for="name">Name <span class="required">*</span></label>
                                    <div class="col-md-6 col-sm-6 col-xs-12">
                                        <input  class="form-control col-md-7 col-xs-12"  name="name"  id="name" value="<?php echo isset($user->name) ?  $user->name : ''; ?>" placeholder="Name" required="required" type="text">
                                        <div class="help-block"><?php if($validator->getError('name')) { echo  $validator->getError('name'); } ?></div>
                                    </div>
                                </div>                                
                                                            
                                <div class="item form-group">
                                    <label class="control-label col-md-3 col-sm-3 col-xs-12" for="user_type">User Type <span class="required">*</span></label>
                                    <div class="col-md-6 col-sm-6 col-xs-12">
                                        <select  class="form-control col-md-7 col-xs-12"  name="user_type"  id="user_type" required="required">
                                            <?php $user_types = get_user_type(); ?>
                                            <option value="">--Select user--</option>
                                            <?php foreach($user_types as $key=>$value){ ?>
                                                <option value="<?php echo $key; ?>" <?php if($user->user_type == $key){ echo 'selected="selected"'; } ?>><?php echo $value; ?></option>
                                            <?php } ?>
                                        </select>
                                        <div class="help-block"><?php if($validator->getError('user_type')) { echo  $validator->getError('user_type'); } ?></div>
                                    </div>
                                </div>
                                
                                <div class="item form-group">
                                    <label class="control-label col-md-3 col-sm-3 col-xs-12" for="email">Email <span class="required">*</span></label>
                                    <div class="col-md-6 col-sm-6 col-xs-12">
                                        <input  class="form-control col-md-7 col-xs-12"  name="email"  id="email" readonly="readonly" value="<?php echo isset($user->email) ?  $user->email : ''; ?>" placeholder="Email" required="required" type="email">
                                        <div class="help-block"><?php if($validator->getError('email')) { echo  $validator->getError('email'); } ?></div>
                                    </div>
                                </div>
                                
                                <div class="item form-group">
                                    <label class="control-label col-md-3 col-sm-3 col-xs-12" for="password">Password</label>
                                    <div class="col-md-6 col-sm-6 col-xs-12">
                                        <input  class="form-control col-md-7 col-xs-12"  name="password"  id="password" value="" placeholder="Password" type="text">
                                        <div class="help-block"><?php if($validator->getError('password')) { echo  $validator->getError('password'); } ?></div>
                                    </div>
                                </div>
                                
                                <div class="item form-group">
                                    <label class="control-label col-md-3 col-sm-3 col-xs-12" for="mobile">Mobile <span class="required">*</span></label>
                                    <div class="col-md-6 col-sm-6 col-xs-12">
                                        <input  class="form-control col-md-7 col-xs-12"  name="mobile"  id="mobile" value="<?php echo isset($user->mobile) ?  $user->mobile : ''; ?>" placeholder="Mobile" required="required" type="text">
                                        <div class="help-block"><?php if($validator->getError('mobile')) { echo  $validator->getError('mobile'); } ?></div>
                                    </div>
                                </div>
                                
                                <div class="item form-group">
                                    <label class="control-label col-md-3 col-sm-3 col-xs-12" for="address">Address</label>
                                    <div class="col-md-6 col-sm-6 col-xs-12">
                                        <input  class="form-control col-md-7 col-xs-12"  name="address"  id="address" value="<?php echo isset($user->address) ?  $user->address : ''; ?>" placeholder="Address" type="text">
                                        <div class="help-block"><?php if($validator->getError('address')) { echo  $validator->getError('address'); } ?></div>
                                    </div>
                                </div>
                                
                                <div class="form-group">
                                   <label class="control-label col-md-3 col-sm-3 col-xs-12">Photo </label>
                                   <div class="col-md-6 col-sm-6 col-xs-12"> 
                                        <?php if(isset($user) && $user->image != ''){ ?>
                                             <img src="<?php echo base_url(UPLOAD_PATH); ?>/user/<?php echo $user->image; ?>" alt="" width="150" /><br/><br/>
                                             <input name="image_prev" value="<?php echo isset($user) ? $user->image : ''; ?>"  type="hidden">
                                        <?php } ?>
                                        <div class="btn btn-default btn-file">
                                            <i class="fa fa-paperclip"></i> Upload
                                            <input type="file" name="image" >
                                        </div>
                                        <div class="help-block"><?php if($validator->getError('image')) { echo  $validator->getError('image'); } ?></div>
                                    </div>
                                </div>  
                                                                                             
                                <div class="ln_solid"></div>
                                <div class="form-group">
                                    <div class="col-md-6 col-md-offset-3">
                                        <input type="hidden" value="<?php echo isset($user) ? $user->id : ''; ?>" name="id" />
                                        <a href="<?php echo site_url('admin/user'); ?>" class="btn btn-primary">Cancel</a>
                                        <button id="send" type="submit" class="btn btn-success">Update</button>
                                    </div>
                                </div>
                                <?php echo form_close(); ?>
                            </div>
                        </div>  
                        <?php } ?>
                        
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<!-- datatable with buttons -->
 <script type="text/javascript">
     
    $(document).ready(function() {
      $('#datatable-responsive').DataTable( {
          dom: 'Bfrtip',
          iDisplayLength: 15,
          buttons: [
              'copyHtml5',
              'excelHtml5',
              'csvHtml5',
              'pdfHtml5',
              'pageLength'
          ],
          search: true
      });
    });

    $("#add").validate();     
    $("#edit").validate(); 
    
</script>

<?php echo $this->endSection(); ?>