<table class="table table-striped table-bordered dt-responsive nowrap" cellspacing="0" width="100%">
    <tbody>
        <tr>
            <th width="25%">News Title </th>
            <td> <?php echo $newses->title; ?></td> 
        </tr>
          
        <tr>
            <th>Initial Part </th>
            <td> <?php echo $newses->initial_part; ?></td> 
        </tr>
        
        <tr>
            <th>Rest Part </th>
            <td> <?php echo $newses->rest_part; ?></td> 
        </tr>
        <tr>
            <th>Image </th>
            <td colspan="3">
                <?php if($newses->image){ ?>
                    <img src="<?php echo base_url(UPLOAD_PATH); ?>/news/<?php echo $newses->image; ?>" alt="" width="200" />
                <?php } ?>
            </td>  
        </tr>
         <tr>
            <th>Status </th>
            <td> <?php echo $newses->status ==1? 'Active' : 'Inactive'; ?></td> 
        </tr>
        
    </tbody>
</table>
