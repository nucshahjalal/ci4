<?php echo $this->extend("layouts/master"); ?>
<?php echo $this->section("content"); ?>

<div class="row">
    <div class="col-md-12 col-sm-12 col-xs-12">
        <div class="x_panel">
            <div class="x_title">
                <h3 class="head-title"><i class="fa fa-file-o"></i><small> Manage News</small></h3>
                <ul class="nav navbar-right panel_toolbox">
                    <li><a class="collapse-link"><i class="fa fa-chevron-up"></i></a></li>                    
                </ul>
                <div class="clearfix"></div>
            </div>
            <div class="x_content">
                <div class="" data-example-id="togglable-tabs">
                    
                    <ul  class="nav nav-tabs bordered">
                        <li class="<?php if(isset($list)){ echo 'active'; }?>"><a href="#tab_news_list"   role="tab" data-toggle="tab" aria-expanded="true"><i class="fa fa-list-ol"></i> List</a> </li>
                        <li  class="<?php if(isset($add)){ echo 'active'; }?>"><a href="#tab_add_news"  role="tab"  data-toggle="tab" aria-expanded="false"><i class="fa fa-plus-square-o"></i> Add </a> </li>                          
                        <?php if(isset($edit)){ ?>
                            <li  class="active"><a href="#tab_edit_news"  role="tab"  data-toggle="tab" aria-expanded="false"><i class="fa fa-pencil-square-o"></i> Edit </a> </li>                          
                        <?php } ?>                
                    </ul>
                    <br/>
                    
                    <div class="tab-content">
                        <div  class="tab-pane fade in <?php if(isset($list)){ echo 'active'; }?>" id="tab_news_list" >
                            <div class="x_content">
                            <table id="datatable-responsive" class="table table-striped table-bordered dt-responsive nowrap" cellspacing="0" width="100%">
                                <thead>
                                    <tr>
                                        <th>#Sl</th>
                                        <th>News Title</th>
                                        <th>Image</th>
                                        <th>Status</th>                                       
                                        <th>Action</th>                                            
                                    </tr>
                                </thead>
                                <tbody>   
                                    <?php $count = 1; if(isset($newses) && !empty($newses)){ ?>
                                        <?php foreach($newses as $obj){ ?>
                                        <tr>
                                            <td><?php echo $count++; ?></td>
                                            <td><?php echo $obj->title; ?></td>
                                            <td>
                                            <?php if($obj->image){ ?>
                                            <img src="<?php echo base_url(UPLOAD_PATH); ?>/news/<?php echo $obj->image; ?>" alt="" width="60" /><br/><br/>
                                            <?php } ?>
                                            </td>
                                            <td><?php echo $obj->status == 1? 'Active' : 'Inactive'; ?></td>
                                            <td>
                                                <a  onclick="get_news_modal(<?php echo $obj->id; ?>);"  data-toggle="modal" data-target=".bs-news-modal-lg"  class="btn btn-success btn-xs"><i class="fa fa-eye"></i> View </a>
                                                <a href="<?php echo site_url('admin/news/edit/'.$obj->id); ?>" class="btn btn-info btn-xs"><i class="fa fa-pencil-square-o"></i> Edit </a>
                                                <a href="<?php echo site_url('admin/news/delete/'.$obj->id); ?>" onclick="javascript: return confirm('Are you sure you want to delete this news?');" class="btn btn-danger btn-xs"><i class="fa fa-trash-o"></i> Delete </a>
                                            </td>
                                        </tr>
                                        <?php } ?>
                                    <?php } ?>
                                </tbody>
                            </table>
                            </div>
                        </div>

                        <div  class="tab-pane fade in <?php if(isset($add)){ echo 'active'; }?>" id="tab_add_news">
                            <div class="x_content"> 
                                
                                <?php 
                                    $attributes = ['class' => 'form-horizontal form-label-left', 'id' => 'add', 'name'=>'add'];
                                    echo form_open_multipart(site_url('admin/news/add'), $attributes);
                                ?>
                                
                                <div class="item form-group">
                                    <label class="control-label col-md-3 col-sm-3 col-xs-12" for="title">News Title <span class="required">*</span></label>
                                    <div class="col-md-6 col-sm-6 col-xs-12">
                                        <input  class="form-control col-md-7 col-xs-12"  name="title"  id="title"   value="<?php echo isset($post['title']) ?  $post['title'] : ''; ?>" required="required" placeholder="Title" type="text">
                                        <div class="help-block"><?php if($validator->getError('title')) { echo  $validator->getError('title'); } ?></div>
                                    </div>
                                </div>
                                
                                <div class="item form-group">
                                    <label class="control-label col-md-3 col-sm-3 col-xs-12" for="initial_part">Initial Part <span class="required">*</span></label>
                                    <div class="col-md-6 col-sm-6 col-xs-12">
                                        <textarea  class="form-control" name="initial_part" id="add_initial_part" required="required"  placeholder="Initial Part"><?php echo isset($post['initial_part']) ?  $post['initial_part'] : ''; ?></textarea>
                                        <div class="help-block"><?php if($validator->getError('initial_part')) { echo  $validator->getError('initial_part'); } ?></div>
                                    </div>
                                </div> 
                              
                                <div class="item form-group">
                                    <label class="control-label col-md-3 col-sm-3 col-xs-12" for="rest_part">Rest Part</label>
                                    <div class="col-md-6 col-sm-6 col-xs-12">
                                        <textarea  class="form-control" name="rest_part" id="add_rest_part"  placeholder="Rest Part"><?php echo isset($post['rest_part']) ?  $post['rest_part'] : ''; ?></textarea>
                                        <div class="help-block"><?php if($validator->getError('rest_part')) { echo  $validator->getError('rest_part'); } ?></div>
                                    </div>
                                </div>
                                
                               <div class="form-group">
                                   <label class="control-label col-md-3 col-sm-3 col-xs-12">Image</label>
                                   <div class="col-md-6 col-sm-6 col-xs-12">                                      
                                        <div class="btn btn-default btn-file">
                                            <i class="fa fa-paperclip"></i> Upload
                                            <input type="file" name="image" >
                                        </div>
                                       <div class="help-block" style="color:#646362;">Image Dimension: W: 1100px, H: 750px</div> 
                                        <div class="help-block"><?php if($validator->getError('image')) { echo  $validator->getError('image'); } ?></div>
                                    </div>
                                </div>                                
                               
                                <div class="ln_solid"></div>
                                <div class="form-group">
                                    <div class="col-md-6 col-md-offset-3">
                                        <a href="<?php echo site_url('admin/news'); ?>" class="btn btn-primary">Cancel</a>
                                        <button id="send" type="submit" class="btn btn-success">Submit</button>
                                    </div>
                                </div>
                                <?php echo form_close(); ?>
                                                            
                            </div>
                        </div>  

                        <?php if(isset($edit)){ ?>
                        <div class="tab-pane fade in active" id="tab_edit_news">
                            <div class="x_content"> 
                            
                                <?php 
                                    $attributes = ['class' => 'form-horizontal form-label-left', 'id' => 'edit', 'name'=>'edit'];
                                    echo form_open_multipart(site_url('admin/news/edit/'.$news->id), $attributes);
                                ?> 
                                
                                <div class="item form-group">
                                    <label class="control-label col-md-3 col-sm-3 col-xs-12" for="title">News Title <span class="required">*</span></label>
                                    <div class="col-md-6 col-sm-6 col-xs-12">
                                        <input  class="form-control col-md-7 col-xs-12"  name="title"  id="title" value="<?php echo isset($news->title) ?  $news->title : ''; ?>" required="required" placeholder="Title" type="text">
                                        <div class="help-block"><?php if($validator->getError('title')) { echo  $validator->getError('title'); } ?></div>
                                    </div>
                                </div>      
                                
                                <div class="item form-group">
                                    <label class="control-label col-md-3 col-sm-3 col-xs-12" for="initial_part">Initial Part <span class="required">*</span></label>
                                    <div class="col-md-6 col-sm-6 col-xs-12">
                                        <textarea  class="form-control" name="initial_part" id="edit_initial_part" required="required" placeholder="Initial Part"><?php echo isset($news->initial_part) ?  $news->initial_part : ''; ?></textarea>
                                        <div class="help-block"><?php if($validator->getError('initial_part')) { echo  $validator->getError('initial_part'); } ?></div>
                                    </div>
                                </div> 
                                
                                <div class="item form-group">
                                    <label class="control-label col-md-3 col-sm-3 col-xs-12" for="rest_part">Rest Part</label>
                                    <div class="col-md-6 col-sm-6 col-xs-12">
                                        <textarea  class="form-control" name="rest_part" id="edit_rest_part"  placeholder="Rest Part"><?php echo isset($news->rest_part) ?  $news->rest_part : ''; ?></textarea>
                                        <div class="help-block"><?php if($validator->getError('rest_part')) { echo  $validator->getError('rest_part'); } ?></div>
                                    </div>
                                </div> 
                                
                                 <div class="form-group">
                                   <label class="control-label col-md-3 col-sm-3 col-xs-12">Image</label>
                                   <div class="col-md-6 col-sm-6 col-xs-12"> 
                                        <?php if(isset($news) && $news->image != ''){ ?>
                                            <img src="<?php echo base_url(UPLOAD_PATH); ?>/news/<?php echo $news->image; ?>" alt="" width="150" /><br/><br/>
                                             <input name="image_prev" value="<?php echo isset($news) ? $news->image : ''; ?>"  type="hidden">
                                        <?php } ?>
                                        <div class="btn btn-default btn-file">
                                            <i class="fa fa-paperclip"></i> Upload
                                            <input type="file" name="image" >
                                        </div>
                                        <div class="help-block" style="color:#646362;">Image Dimension: W: 1100px, H: 750px</div>     
                                        <div class="help-block"><?php if($validator->getError('image')) { echo  $validator->getError('image'); } ?></div>
                                    </div>
                                </div>  
                                
                                <div class="item form-group">
                                    <label class="control-label col-md-3 col-sm-3 col-xs-12" for="status">Status </label>
                                    <div class="col-md-6 col-sm-6 col-xs-12">
                                        <select  class="form-control col-md-7 col-xs-12"  name="status"  id="status">
                                            <option value="">--Select status-- </option>
                                            <option value="1" <?php if(isset($news) && $news->status == 1){ echo 'selected="selected"'; } ?>>Active</option>
                                            <option value="0" <?php if(isset($news) && $news->status == 0){ echo 'selected="selected"'; } ?>>In Active</option>
                                        </select>
                                        <div class="help-block"><?php if($validator->getError('status')) { echo  $validator->getError('status'); } ?></div>
                                    </div>
                                </div>
                                
                                <div class="ln_solid"></div>
                                <div class="form-group">
                                    <div class="col-md-6 col-md-offset-3">
                                        <input type="hidden" value="<?php echo isset($news) ? $news->id : ''; ?>" name="id" />
                                        <a href="<?php echo site_url('admin/news'); ?>" class="btn btn-primary">Cancel</a>
                                        <button id="send" type="submit" class="btn btn-success">Update</button>
                                    </div>
                                </div>
                                <?php echo form_close(); ?>
                            </div>
                        </div>  
                        <?php } ?>
                        
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<div class="modal fade bs-news-modal-lg" tabindex="-1" role="dialog" aria-hidden="true">
    <div class="modal-dialog modal-lg">
      <div class="modal-content">
        <div class="modal-header">
          <button type="button" class="close" data-dismiss="modal"><span aria-hidden="true">×</span></button>
          <h4 class="modal-title">News Details</h4>
        </div>
        <div class="modal-body fn_news_data">            
        </div>       
      </div>
    </div>
</div>


<script type="text/javascript">
      
    function get_news_modal(news_id){
        $('.fn_news_data').html('<p style="padding: 20px;"><p style="padding: 20px;text-align:center;"><img src="<?php echo base_url(IMG_URL); ?>/loader.gif" /></p>');
        $.ajax({       
          type   : "POST",
          url    : "<?php echo base_url('admin/news/view'); ?>",
          data   : {news_id : news_id},  
          success: function(response){                                                   
             if(response)
             {
                $('.fn_news_data').html(response);
             }
          }
       });
    }
    
</script>

<link href="<?php echo base_url(VENDOR_URL); ?>/editor/jquery-te-1.4.0.css" rel="stylesheet">
<script type="text/javascript" src="<?php echo base_url(VENDOR_URL); ?>/editor/jquery-te-1.4.0.min.js"></script>

<!-- datatable with buttons -->
 <script type="text/javascript">
     
     $('#add_initial_part').jqte();
     $('#edit_initial_part').jqte();
     $('#add_rest_part').jqte();
     $('#edit_rest_part').jqte();
     
        $(document).ready(function() {
            
          $('#datatable-responsive').DataTable( {
              dom: 'Bfrtip',
              iDisplayLength: 15,
              buttons: [
                  'copyHtml5',
                  'excelHtml5',
                  'csvHtml5',
                  'pdfHtml5',
                  'pageLength'
              ],
              search: true
          });
        });
        
        $('#add').validate();
        $('#edit').validate();
        
</script>

<?php echo $this->endSection(); ?>