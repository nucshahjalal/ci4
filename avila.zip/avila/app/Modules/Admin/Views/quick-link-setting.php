<strong>Quick Menu : </strong>

<a href="<?php echo site_url('admin/setting'); ?>"> General Setting</a>
| <a href="<?php echo site_url('admin/about'); ?>"> About Avila</a>
| <a href="<?php echo site_url('admin/heading'); ?>"> Heading</a>
