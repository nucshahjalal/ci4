<?php echo $this->extend("layouts/master"); ?>
<?php echo $this->section("content"); ?>

<div class="row">
    <div class="col-md-12 col-sm-12 col-xs-12">
        <div class="x_panel">
            <div class="x_title">
                <h3 class="head-title"><i class="fa fa-gears"></i><small> About Avila </small></h3>
                <ul class="nav navbar-right panel_toolbox">
                    <li><a class="collapse-link"><i class="fa fa-chevron-up"></i></a></li>                    
                </ul>
                <div class="clearfix"></div>
            </div>
            
            <div class="x_content quick-link">
                <?php  echo $this->include($path. '/quick-link-setting'); ?>               
            </div>
            
            <div class="x_content">
                <div class="" data-example-id="togglable-tabs">
                    
                    <ul  class="nav nav-tabs bordered">
                        <li class="active"><a href="#tab_about_home"   role="tab" data-toggle="tab" aria-expanded="true"><i class="fa fa-gear"></i> About Avila Home</a> </li>
                    </ul>
                    <br/>
                    
                    <div class="tab-content">                     

                        <div  class="tab-pane fade in active" id="tab_about_home">
                            <div class="x_content"> 
                                
                                <?php 
                                    $attributes = ['class' => 'form-horizontal form-label-left', 'id' => 'about', 'name'=>'about'];
                                    $action = 'admin/about/add';
                                    echo form_open_multipart(site_url($action), $attributes);
                                ?>
                                 
                                <div class="item form-group">
                                    <label class="control-label col-md-3 col-sm-3 col-xs-12" for="title">About us Title <span class="required">*</span></label>
                                    <div class="col-md-6 col-sm-6 col-xs-12">
                                        <input  class="form-control col-md-7 col-xs-12"  name="title"  id="title" value="<?php echo isset($about->title) ?  $about->title : ''; ?>" required="required" placeholder="Title"  type="text">
                                   <div class="help-block"><?php if($validator->getError('title')) { echo  $validator->getError('title'); } ?></div>
                                    </div>
                                </div>   
                                
                                <div class="item form-group">
                                    <label class="control-label col-md-3 col-sm-3 col-xs-12" for="description">About Us Description <span class="required">*</span></label>
                                    <div class="col-md-6 col-sm-6 col-xs-12">
                                        <textarea  class="form-control" name="description" id="description"  required="required" placeholder="Description"><?php echo isset($about->description) ?  $about->description : ''; ?></textarea>
                                       <div class="help-block"><?php if($validator->getError('description')) { echo  $validator->getError('description'); } ?></div>
                                    </div>
                                </div>
                                
                                <div class="item form-group">
                                    <label class="control-label col-md-3 col-sm-3 col-xs-12" for="video">Video Embed Code</label>
                                    <div class="col-md-6 col-sm-6 col-xs-12">
                                        <textarea  class="form-control" name="video" id="video" placeholder="Video"><?php echo isset($about->video) ?  $about->video : ''; ?></textarea>
                                        <div class="help-block"><?php if($validator->getError('video')) { echo  $validator->getError('video'); } ?></div>
                                    </div>
                                </div>   
                            
                                <div class="form-group">
                                   <label class="control-label col-md-3 col-sm-3 col-xs-12">About Us Image</label>
                                   <div class="col-md-6 col-sm-6 col-xs-12">
                                       <?php if(isset($about) && $about->image){ ?>
                                            <img src="<?php echo base_url(UPLOAD_PATH); ?>/about/<?php echo $about->image; ?>" alt="" width="350" /><br/><br/>
                                             <input name="image_prev" value="<?php echo isset($about) ? $about->image : ''; ?>"  type="hidden">
                                        <?php } ?>
                                        <div class="btn btn-default btn-file">
                                            <i class="fa fa-paperclip"></i> Upload
                                            <input type="file" name="image" id="image">
                                        </div>
                                             <div class="help-block" style="color:#646362;">Image Dimension: W: 750px, H: 800px</div>     
                                        <div class="help-block"><?php if($validator->getError('image')) { echo  $validator->getError('image'); } ?></div>
                                    </div>
                                </div>
                           
                                    
                                <div class="ln_solid"></div>
                                <div class="form-group">
                                    <div class="col-md-6 col-md-offset-3">
                                        <input type="hidden" value="<?php echo isset($about) ? $about->id : ''; ?>" name="id" />
                                        <a href="<?php echo site_url('admin/about'); ?>" class="btn btn-primary">Cancel</a>
                                        <button id="send" type="submit" class="btn btn-success">Submit</button>
                                    </div>
                                </div>
                                <?php echo form_close(); ?>
                                                            
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<link href="<?php echo base_url(VENDOR_URL); ?>/editor/jquery-te-1.4.0.css" rel="stylesheet">
<script type="text/javascript" src="<?php echo base_url(VENDOR_URL); ?>/editor/jquery-te-1.4.0.min.js"></script>
 
<script type="text/javascript">
    
    $('#description').jqte();
    $("#about").validate();  
    
</script>

<?php echo $this->endSection(); ?>