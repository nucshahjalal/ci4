<?php echo $this->extend("layouts/master"); ?>
<?php echo $this->section("content"); ?>

<div class="row">
    <div class="col-md-12 col-sm-12 col-xs-12">
        <div class="x_panel">
            <div class="x_title">
                <h3 class="head-title"><i class="fa fa-gears"></i><small> General Setting</small></h3>
                <ul class="nav navbar-right panel_toolbox">
                    <li><a class="collapse-link"><i class="fa fa-chevron-up"></i></a></li>                    
                </ul>
                <div class="clearfix"></div>
            </div>
            
            <div class="x_content quick-link">
                <?php  echo $this->include($path. '/quick-link-setting'); ?>               
            </div>
            
            <div class="x_content">
                <div class="" data-example-id="togglable-tabs">
                    
                    <ul  class="nav nav-tabs bordered">
                        <li class="active"><a href="#tab_setting"   role="tab" data-toggle="tab" aria-expanded="true"><i class="fa fa-gear"></i> General Setting</a> </li>
                    </ul>
                    <br/>
                    
                    <div class="tab-content">                     
                        <div  class="tab-pane fade in active" id="tab_setting">
                            <div class="x_content"> 
                                
                                <?php 
                                    $attributes = ['class' => 'form-horizontal form-label-left', 'id' => 'setting', 'name'=>'setting'];
                                    $action = 'admin/setting/add';
                                    echo form_open_multipart(site_url($action), $attributes);
                                ?> 
                                 
                                <div class="item form-group">
                                    <label class="control-label col-md-3 col-sm-3 col-xs-12" for="name">Company Name <span class="required">*</span></label>
                                    <div class="col-md-6 col-sm-6 col-xs-12">
                                        <input  class="form-control col-md-7 col-xs-12"  name="name"  id="name" value="<?php echo isset($setting->name) ?  $setting->name : ''; ?>" required="required" placeholder="Company Name" type="text">
                                        <div class="help-block"><?php if($validator->getError('name')) { echo  $validator->getError('name'); } ?></div>
                                    </div>
                                </div>   
                           
                                <div class="item form-group">
                                    <label class="control-label col-md-3 col-sm-3 col-xs-12" for="email">Email <span class="required">*</span></label>
                                    <div class="col-md-6 col-sm-6 col-xs-12">
                                        <input  class="form-control col-md-7 col-xs-12"  name="email"  id="email" value="<?php echo isset($setting->email) ?  $setting->email : ''; ?>" required="required" placeholder="Email"  type="email">
                                        <div class="help-block"><?php if($validator->getError('email')) { echo  $validator->getError('email'); } ?></div>
                                    </div>
                                </div>   
                           
                                <div class="item form-group">
                                    <label class="control-label col-md-3 col-sm-3 col-xs-12" for="mobile">Mobile <span class="required">*</span></label>
                                    <div class="col-md-6 col-sm-6 col-xs-12">
                                        <input  class="form-control col-md-7 col-xs-12"  name="mobile"  id="mobile" value="<?php echo isset($setting->mobile) ?  $setting->mobile : ''; ?>" required="required" placeholder="Mobile"  type="text">
                                        <div class="help-block"><?php if($validator->getError('mobile')) { echo  $validator->getError('mobile'); } ?></div>
                                    </div>
                                </div> 
                                
                                <div class="item form-group">
                                    <label class="control-label col-md-3 col-sm-3 col-xs-12" for="phone">Phone </label>
                                    <div class="col-md-6 col-sm-6 col-xs-12">
                                        <input  class="form-control col-md-7 col-xs-12"  name="phone"  id="phone" value="<?php echo isset($setting->phone) ?  $setting->phone : ''; ?>" placeholder="Phone"  type="text">
                                        <div class="help-block"><?php if($validator->getError('phone')) { echo  $validator->getError('phone'); } ?></div>
                                    </div>
                                </div>   
                           
                                <div class="item form-group">
                                    <label class="control-label col-md-3 col-sm-3 col-xs-12" for="fax">Fax</label>
                                    <div class="col-md-6 col-sm-6 col-xs-12">
                                        <input  class="form-control col-md-7 col-xs-12"  name="fax"  id="fax" value="<?php echo isset($setting->fax) ?  $setting->fax : ''; ?>" placeholder="Fax"  type="text">
                                        <div class="help-block"><?php if($validator->getError('fax')) { echo  $validator->getError('fax'); } ?></div>
                                    </div>
                                </div>   
                                
                                <div class="item form-group">
                                    <label class="control-label col-md-3 col-sm-3 col-xs-12" for="skype">Skype</label>
                                    <div class="col-md-6 col-sm-6 col-xs-12">
                                        <input  class="form-control col-md-7 col-xs-12"  name="skype"  id="skype" value="<?php echo isset($setting->skype) ?  $setting->skype : ''; ?>" placeholder="skype"  type="text">
                                        <div class="help-block"><?php if($validator->getError('skype')) { echo  $validator->getError('skype'); } ?></div>
                                    </div>
                                </div>
                                
                                <div class="item form-group">
                                    <label class="control-label col-md-3 col-sm-3 col-xs-12" for="address">Address <span class="required">*</span></label>
                                    <div class="col-md-6 col-sm-6 col-xs-12">
                                        <input  class="form-control col-md-7 col-xs-12"  name="address"  id="address" required="required" value="<?php echo isset($setting->address) ?  $setting->address : ''; ?>" placeholder="Address"  type="text">
                                        <div class="help-block"><?php if($validator->getError('address')) { echo  $validator->getError('address'); } ?></div>
                                    </div>
                                </div>   
                                
                                <div class="item form-group">
                                    <label class="control-label col-md-3 col-sm-3 col-xs-12" for="currency">Currency</label>
                                    <div class="col-md-6 col-sm-6 col-xs-12">
                                        <input  class="form-control col-md-7 col-xs-12"  name="currency"  id="currency" value="<?php echo isset($setting->currency) ?  $setting->currency : ''; ?>" placeholder="Currency"  type="text">
                                        <div class="help-block"><?php if($validator->getError('currency')) { echo  $validator->getError('currency'); } ?></div>
                                    </div>
                                </div>   
                                
                                <div class="item form-group">
                                    <label class="control-label col-md-3 col-sm-3 col-xs-12" for="opening_day">Opening Day <span class="required">*</span></label>
                                    <div class="col-md-6 col-sm-6 col-xs-12">
                                        <input  class="form-control col-md-7 col-xs-12"  name="opening_day"  id="opening_day" required="required" value="<?php echo isset($setting->opening_day) ?  $setting->opening_day : ''; ?>" placeholder="Opening day"  type="text">
                                        <div class="help-block"><?php if($validator->getError('opening_day')) { echo  $validator->getError('opening_day'); } ?></div>
                                    </div>
                                </div>
                                
                                <div class="item form-group">
                                    <label class="control-label col-md-3 col-sm-3 col-xs-12" for="opening_time">Opening Time</label>
                                    <div class="col-md-6 col-sm-6 col-xs-12">
                                        <input  class="form-control col-md-7 col-xs-12"  name="opening_time"  id="opening_time" value="<?php echo isset($setting->opening_time) ?  $setting->opening_time : ''; ?>" placeholder="Opening time"  type="text">
                                        <div class="help-block"><?php if($validator->getError('opening_time')) { echo  $validator->getError('opening_time'); } ?></div>
                                    </div>
                                </div>
                                
                                <div class="item form-group">
                                    <label class="control-label col-md-3 col-sm-3 col-xs-12" for="close_day">Close day</label>
                                    <div class="col-md-6 col-sm-6 col-xs-12">
                                        <input  class="form-control col-md-7 col-xs-12"  name="close_day"  id="close_day" value="<?php echo isset($setting->close_day) ?  $setting->close_day : ''; ?>" placeholder="Close day"  type="text">
                                        <div class="help-block"><?php if($validator->getError('close_day')) { echo  $validator->getError('close_day'); } ?></div>
                                    </div>
                                </div>
                                
                                <div class="item form-group">
                                    <label class="control-label col-md-3 col-sm-3 col-xs-12" for="facebook">Facebook URL</label>
                                    <div class="col-md-6 col-sm-6 col-xs-12">
                                        <input  class="form-control col-md-7 col-xs-12"  name="facebook"  id="facebook" value="<?php echo isset($setting->facebook) ?  $setting->facebook : ''; ?>" placeholder="Facebook"  type="text">
                                        <div class="help-block"><?php if($validator->getError('facebook')) { echo  $validator->getError('facebook'); } ?></div>
                                    </div>
                                </div> 
                                
                                <div class="item form-group">
                                    <label class="control-label col-md-3 col-sm-3 col-xs-12" for="twitter">Twitter URL</label>
                                    <div class="col-md-6 col-sm-6 col-xs-12">
                                        <input  class="form-control col-md-7 col-xs-12"  name="twitter"  id="twitter" value="<?php echo isset($setting->twitter) ?  $setting->twitter : ''; ?>" placeholder="Twitter"  type="text">
                                        <div class="help-block"><?php if($validator->getError('twitter')) { echo  $validator->getError('twitter'); } ?></div>
                                    </div>
                                </div> 
                                
                                <div class="item form-group">
                                    <label class="control-label col-md-3 col-sm-3 col-xs-12" for="linked_in">Linked In URL</label>
                                    <div class="col-md-6 col-sm-6 col-xs-12">
                                        <input  class="form-control col-md-7 col-xs-12"  name="linked_in"  id="linked_in" value="<?php echo isset($setting->linked_in) ?  $setting->linked_in : ''; ?>" placeholder="Linked In"  type="text">
                                        <div class="help-block"><?php if($validator->getError('linked_in')) { echo  $validator->getError('linked_in'); } ?></div>
                                    </div>
                                </div>   
                           
                                <div class="item form-group">
                                    <label class="control-label col-md-3 col-sm-3 col-xs-12" for="youtube">Youtube URL </label>
                                    <div class="col-md-6 col-sm-6 col-xs-12">
                                        <input  class="form-control col-md-7 col-xs-12"  name="youtube"  id="youtube" value="<?php echo isset($setting->youtube) ?  $setting->youtube : ''; ?>" placeholder="Youtube"  type="text">
                                        <div class="help-block"><?php if($validator->getError('youtube')) { echo  $validator->getError('youtube'); } ?></div>
                                    </div>
                                </div>   
                           
                                <div class="item form-group">
                                    <label class="control-label col-md-3 col-sm-3 col-xs-12" for="pinterest">Pinterest URL </label>
                                    <div class="col-md-6 col-sm-6 col-xs-12">
                                        <input  class="form-control col-md-7 col-xs-12"  name="pinterest"  id="pinterest" value="<?php echo isset($setting->pinterest) ?  $setting->pinterest : ''; ?>" placeholder="Pinterest"  type="text">
                                        <div class="help-block"><?php if($validator->getError('pinterest')) { echo  $validator->getError('pinterest'); } ?></div>
                                    </div>
                                </div>   
                           
                                <div class="item form-group">
                                    <label class="control-label col-md-3 col-sm-3 col-xs-12" for="instagram">Instagram URL </label>
                                    <div class="col-md-6 col-sm-6 col-xs-12">
                                        <input  class="form-control col-md-7 col-xs-12"  name="instagram"  id="instagram" value="<?php echo isset($setting->instagram) ?  $setting->instagram : ''; ?>" placeholder="Instagram"  type="text">
                                        <div class="help-block"><?php if($validator->getError('instagram')) { echo  $validator->getError('instagram'); } ?></div>
                                    </div>
                                </div> 
                                
                                <div class="item form-group">
                                    <label class="control-label col-md-3 col-sm-3 col-xs-12" for="copy_right">Copy Right <span class="required">*</span></label>
                                    <div class="col-md-6 col-sm-6 col-xs-12">
                                        <input  class="form-control col-md-7 col-xs-12"  name="copy_right"  id="copy_right" required="required" value="<?php echo isset($setting->copy_right) ?  $setting->copy_right : ''; ?>" placeholder="Copy right" type="text">
                                        <div class="help-block"><?php if($validator->getError('copy_right')) { echo  $validator->getError('copy_right'); } ?></div>
                                    </div>
                                </div> 
                                
                                <div class="item form-group">
                                    <label class="control-label col-md-3 col-sm-3 col-xs-12" for="google_map">Google Map</label>
                                    <div class="col-md-6 col-sm-6 col-xs-12">
                                        <textarea  class="form-control" name="google_map" id="google_map" placeholder="Google Map"><?php echo isset($setting->google_map) ?  $setting->google_map : ''; ?></textarea>
                                        <div class="help-block"><?php if($validator->getError('google_map')) { echo  $validator->getError('google_map'); } ?></div>
                                    </div>
                                </div>
                                
                                <div class="item form-group">
                                    <label class="control-label col-md-3 col-sm-3 col-xs-12" for="key_note">Note</label>
                                    <div class="col-md-6 col-sm-6 col-xs-12">
                                        <textarea  class="form-control" name="key_note" id="key_note" placeholder="key_note"><?php echo isset($setting->key_note) ?  $setting->key_note : ''; ?></textarea>
                                        <div class="help-block"><?php if($validator->getError('key_note')) { echo  $validator->getError('key_note'); } ?></div>
                                    </div>
                                </div>
                               
                                    
                                <div class="ln_solid"></div>
                                <div class="form-group">
                                    <div class="col-md-6 col-md-offset-3">
                                        <input type="hidden" value="<?php echo isset($setting) ? $setting->id : ''; ?>" name="id" />
                                        <a href="<?php echo site_url('admin/setting'); ?>" class="btn btn-primary">Cancel</a>
                                        <button id="send" type="submit" class="btn btn-success">Submit</button>
                                    </div>
                                </div>
                                <?php echo form_close(); ?>
                                                            
                            </div>
                        </div>  
                        
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<script type="text/javascript">
    $("#setting").validate();  
</script>

<?php echo $this->endSection(); ?>