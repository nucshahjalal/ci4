<?php echo $this->extend("layouts/master"); ?>
<?php echo $this->section("content"); ?>

<div class="row">
    <div class="col-md-12 col-sm-12 col-xs-12">
        <div class="x_panel">
            <div class="x_title">
                <h3 class="head-title"><i class="fa fa-envelope"></i> <small> Manage Contacts</small></h3>
                <ul class="nav navbar-right panel_toolbox">
                    <li><a class="collapse-link"><i class="fa fa-chevron-up"></i></a></li>                    
                </ul>
                <div class="clearfix"></div>
            </div>
            <div class="x_content">
                <div class="" data-example-id="togglable-tabs">
                    
                    <ul  class="nav nav-tabs bordered">
                        <li class="<?php if(isset($list)){ echo 'active'; }?>"><a href="#tab_contact_list"   role="tab" data-toggle="tab" aria-expanded="true"><i class="fa fa-list-ol"></i> List</a> </li>
                        <li  class="<?php if(isset($add)){ echo 'active'; }?>"><a href="#tab_add_contact"  role="tab"  data-toggle="tab" aria-expanded="false"><i class="fa fa-plus-square-o"></i> Add </a> </li>                          
                        <?php if(isset($edit)){ ?>
                            <li  class="active"><a href="#tab_edit_contact"  role="tab"  data-toggle="tab" aria-expanded="false"><i class="fa fa-pencil-square-o"></i> Edit </a> </li>                          
                        <?php } ?>                
                    </ul>
                    <br/>
                    
                    <div class="tab-content">
                        <div  class="tab-pane fade in <?php if(isset($list)){ echo 'active'; }?>" id="tab_contact_list" >
                            <div class="x_content">
                            <table id="datatable-responsive" class="table table-striped table-bordered dt-responsive nowrap" cellspacing="0" width="100%">
                                <thead>
                                    <tr>
                                        <th>#Sl</th>
                                        <th>Name</th>
                                        <th>Email</th>
                                        <th>Phone</th>
                                        <th>Action</th>                                            
                                    </tr>
                                </thead>
                                <tbody>   
                                    <?php $count = 1; if(isset($contacts) && !empty($contacts)){ ?>
                                        <?php foreach($contacts as $obj){ ?>
                                        <tr>
                                            <td><?php echo $count++; ?></td>
                                            <td><?php echo $obj->name; ?></td>
                                            <td><?php echo $obj->email; ?></td>
                                            <td><?php echo $obj->phone; ?></td>
                                            <td>
                                                
                                                <a  onclick="get_contact_modal(<?php echo $obj->id; ?>);"data-toggle="modal" data-target=".bs-contact-modal-lg"  class="btn btn-success btn-xs"><i class="fa fa-eye"></i> View </a>
                                                <a href="<?php echo site_url('admin/contact/edit/'.$obj->id); ?>" class="btn btn-info btn-xs"><i class="fa fa-pencil-square-o"></i> Edit </a>
                                                <a href="<?php echo site_url('admin/contact/delete/'.$obj->id); ?>" onclick="javascript: return confirm('Are you sure you want to delete this contact?');" class="btn btn-danger btn-xs"><i class="fa fa-trash-o"></i> Delete </a>
                                         </td>
                                        </tr>
                                        <?php } ?>
                                    <?php } ?>
                                </tbody>
                            </table>
                            </div>
                        </div>

                        <div  class="tab-pane fade in <?php if(isset($add)){ echo 'active'; }?>" id="tab_add_contact">
                            <div class="x_content"> 
                                
                                <?php 
                                    $attributes = ['class' => 'form-horizontal form-label-left', 'id' => 'add', 'name'=>'add'];
                                    echo form_open(site_url('admin/contact/add'), $attributes);
                                ?>
                                
                                <div class="item form-group">
                                    <label class="control-label col-md-3 col-sm-3 col-xs-12" for="name">Name <span class="required">*</span></label>
                                    <div class="col-md-6 col-sm-6 col-xs-12">
                                        <input  class="form-control col-md-7 col-xs-12"  name="name"  id="name"   value="<?php echo isset($post['name']) ?  $post['name'] : ''; ?>" required="required" placeholder="Name" type="text">
                                        <div class="help-block"><?php if($validator->getError('name')) { echo  $validator->getError('name'); } ?></div>
                                    </div>
                                </div>
                                
                                <div class="item form-group">
                                    <label class="control-label col-md-3 col-sm-3 col-xs-12" for="email">Email <span class="required">*</span></label>
                                    <div class="col-md-6 col-sm-6 col-xs-12">
                                        <input  class="form-control col-md-7 col-xs-12"  name="email"  id="title"  value="<?php echo isset($post['email']) ?  $post['email'] : ''; ?>" required="required" placeholder="Email" type="email">
                                        <div class="help-block"><?php if($validator->getError('email')) { echo  $validator->getError('email'); } ?></div>
                                    </div>
                                </div>
                                
                                <div class="item form-group">
                                    <label class="control-label col-md-3 col-sm-3 col-xs-12" for="phone">Phone </label>
                                    <div class="col-md-6 col-sm-6 col-xs-12">
                                        <input  class="form-control col-md-7 col-xs-12"  name="phone"  id="phone"   value="<?php echo isset($post['phone']) ?  $post['phone'] : ''; ?>" placeholder="Phone" type="number">
                                        <div class="help-block"><?php if($validator->getError('phone')) { echo  $validator->getError('phone'); } ?></div>
                                    </div>
                                </div>
                                
                                <div class="item form-group">
                                    <label class="control-label col-md-3 col-sm-3 col-xs-12" for="subject">Subject <span class="required">*</span></label>
                                    <div class="col-md-6 col-sm-6 col-xs-12">
                                        <input  class="form-control col-md-7 col-xs-12"  name="subject"  id="subject" value="<?php echo isset($post['subject']) ?  $post['subject'] : ''; ?>" required="required" placeholder="Subject" type="text">
                                        <div class="help-block"><?php if($validator->getError('subject')) { echo  $validator->getError('subject'); } ?></div>
                                    </div>
                                </div>
                                
                                <div class="item form-group">
                                    <label class="control-label col-md-3 col-sm-3 col-xs-12" for="message">Message</label>
                                    <div class="col-md-6 col-sm-6 col-xs-12">
                                        <textarea  class="form-control" name="message" id="message"  placeholder="message"><?php echo isset($post['message']) ?  $post['message'] : ''; ?></textarea>
                                        <div class="help-block"><?php if($validator->getError('message')) { echo  $validator->getError('message'); } ?></div>
                                    </div>
                                </div> 
                                    
                                <div class="ln_solid"></div>
                                <div class="form-group">
                                    <div class="col-md-6 col-md-offset-3">
                                        <a href="<?php echo site_url('admin/contact'); ?>" class="btn btn-primary">Cancel</a>
                                        <button id="send" type="submit" class="btn btn-success">Submit</button>
                                    </div>
                                </div>
                                <?php echo form_close(); ?>
                                                            
                            </div>
                        </div>  

                        <?php if(isset($edit)){ ?>
                        <div class="tab-pane fade in active" id="tab_edit_contact">
                            <div class="x_content"> 
                                <?php 
                                    $attributes = ['class' => 'form-horizontal form-label-left', 'id' => 'edit', 'name'=>'edit'];
                                    echo form_open(site_url('admin/contact/edit/'.$contact->id), $attributes);
                                ?>   
                                
                                <div class="item form-group">
                                    <label class="control-label col-md-3 col-sm-3 col-xs-12" for="name">Name <span class="required">*</span></label>
                                    <div class="col-md-6 col-sm-6 col-xs-12">
                                        <input  class="form-control col-md-7 col-xs-12"  name="name"  id="name" value="<?php echo isset($contact->name) ?  $contact->name : ''; ?>" required="required" placeholder="Name" type="text">
                                    <div class="help-block"><?php if($validator->getError('name')) { echo  $validator->getError('name'); } ?></div>
                                    </div>
                                </div> 
                                
                                 <div class="item form-group">
                                     <label class="control-label col-md-3 col-sm-3 col-xs-12" for="email">Email <span class="required">*</span></label>
                                    <div class="col-md-6 col-sm-6 col-xs-12">
                                        <input  class="form-control col-md-7 col-xs-12"  name="email"  id="email" value="<?php echo isset($contact->email) ?  $contact->email : ''; ?>" required="required" placeholder="Email" type="email">
                                    <div class="help-block"><?php if($validator->getError('email')) { echo  $validator->getError('email'); } ?></div>
                                    </div>
                                </div>  
                                
                                <div class="item form-group">
                                    <label class="control-label col-md-3 col-sm-3 col-xs-12" for="phone">Phone </label>
                                    <div class="col-md-6 col-sm-6 col-xs-12">
                                        <input  class="form-control col-md-7 col-xs-12"  name="phone"  id="phone" value="<?php echo isset($contact->phone) ?  $contact->phone : ''; ?>" placeholder="Phone" type="number">
                                    <div class="help-block"><?php if($validator->getError('phone')) { echo  $validator->getError('phone'); } ?></div>
                                    </div>
                                </div>  
                                
                                 <div class="item form-group">
                                    <label class="control-label col-md-3 col-sm-3 col-xs-12" for="subject">Subject <span class="required">*</span></label>
                                    <div class="col-md-6 col-sm-6 col-xs-12">
                                        <input  class="form-control col-md-7 col-xs-12"  name="subject"  id="title" value="<?php echo isset($contact->subject) ?  $contact->subject : ''; ?>" required="required" placeholder="Subject" type="text">
                                    <div class="help-block"><?php if($validator->getError('subject')) { echo  $validator->getError('subject'); } ?></div>
                                    </div>
                                </div>  
                               
                                <div class="item form-group">
                                    <label class="control-label col-md-3 col-sm-3 col-xs-12" for="message">Message</label>
                                    <div class="col-md-6 col-sm-6 col-xs-12">
                                        <textarea  class="form-control" name="message" id="message"  placeholder="Message"><?php echo isset($contact->message) ?  $contact->message : ''; ?></textarea>
                                    <div class="help-block"><?php if($validator->getError('message')) { echo  $validator->getError('message'); } ?></div>
                                    </div>
                                </div> 
                                 
                                <div class="item form-group">
                                    <label class="control-label col-md-3 col-sm-3 col-xs-12" for="status">Status </label>
                                    <div class="col-md-6 col-sm-6 col-xs-12">
                                        <select  class="form-control col-md-7 col-xs-12"  name="status"  id="status">
                                            <option value="">--Select status-- </option>
                                            <option value="1" <?php if(isset($contact) && $contact->status == 1){ echo 'selected="selected"'; } ?>>Active</option>
                                            <option value="0" <?php if(isset($contact) && $contact->status == 0){ echo 'selected="selected"'; } ?>>In Active</option>
                                        </select>
                                        <div class="help-block"><?php if($validator->getError('status')) { echo  $validator->getError('status'); } ?></div>
                                    </div>
                                </div>
                                
                                <div class="ln_solid"></div>
                                <div class="form-group">
                                    <div class="col-md-6 col-md-offset-3">
                                        <input type="hidden" value="<?php echo isset($contact) ? $contact->id : $id; ?>" name="id" />
                                        <a href="<?php echo site_url('admin/contact'); ?>" class="btn btn-primary">Cancel</a>
                                        <button id="send" type="submit" class="btn btn-success">Update</button>
                                    </div>
                                </div>
                                <?php echo form_close(); ?>
                            </div>
                        </div>  
                        <?php } ?>                        
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<div class="modal fade bs-contact-modal-lg" tabindex="-1" role="dialog" aria-hidden="true">
    <div class="modal-dialog modal-lg">
      <div class="modal-content">
        <div class="modal-header">
          <button type="button" class="close" data-dismiss="modal"><span aria-hidden="true">×</span></button>
          <h4 class="modal-title">Contact Details</h4>
        </div>
        <div class="modal-body fn_contact_data">            
        </div>       
      </div>
    </div>
</div>

<script type="text/javascript">
      
    function get_contact_modal(contact_id){
        
        $('.fn_contact_data').html('<p style="padding: 20px;"><p style="padding: 20px;text-align:center;"><img src="<?php echo base_url(IMG_URL); ?>/loader.gif" /></p>');
        $.ajax({       
          type   : "POST",
          url    : "<?php echo base_url('admin/contact/view'); ?>",
          data   : {contact_id : contact_id},  
          success: function(response){                                                   
             if(response)
             {
                $('.fn_contact_data').html(response);
             }
          }
       });
    }
    
</script>
   
<!-- datatable with buttons -->
 <script type="text/javascript">
     
        $(document).ready(function() {
          $('#datatable-responsive').DataTable( {
              dom: 'Bfrtip',
              iDisplayLength: 15,
              buttons: [
                  'copyHtml5',
                  'excelHtml5',
                  'csvHtml5',
                  'pdfHtml5',
                  'pageLength'
              ],
              search: true
          });
        });
        
        $('#add').validate();
        $('#edit').validate();
        
</script>

<?php echo $this->endSection(); ?>