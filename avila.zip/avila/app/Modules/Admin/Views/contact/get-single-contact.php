<table class="table table-striped table-bordered dt-responsive nowrap" cellspacing="0" width="100%">
    <tbody>
        <tr>
            <th width="25%">Name </th>
            <td> <?php echo $contact->name; ?></td> 
        </tr>
          
        <tr>
            <th>Email </th>
            <td> <?php echo $contact->email; ?></td> 
        </tr>
        
        <tr>
            <th>Phone </th>
            <td> <?php echo $contact->phone; ?></td> 
        </tr>
        
        <tr>
            <th>Subject </th>
            <td> <?php echo $contact->subject; ?></td> 
        </tr>        
        <tr>
            <th>Message </th>
            <td> <?php echo $contact->message; ?></td>
        </tr>       
    </tbody>
</table>
