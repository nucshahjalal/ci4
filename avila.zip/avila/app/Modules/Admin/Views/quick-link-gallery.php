<strong>Quick Menu : </strong>

<a href="<?php echo site_url('admin/gallery'); ?>"> Galleries</a>
| <a href="<?php echo site_url('admin/image'); ?>"> Gallery Image</a>
