<?php echo $this->extend("layouts/master"); ?>
<?php echo $this->section("content"); ?>

<div class="row">
    <div class="col-md-12 col-sm-12 col-xs-12">
        <div class="x_panel">
            <div class="x_title">
                <h3 class="head-title"><i class="fa fa-home"> </i> <small> Manage Project</small></h3>
                <ul class="nav navbar-right panel_toolbox">
                    <li><a class="collapse-link"><i class="fa fa-chevron-up"></i></a></li>                    
                </ul>
                <div class="clearfix"></div>
            </div>
            
            <div class="x_content quick-link">
                <?php  echo $this->include($path. '/quick-link-project'); ?>               
            </div>
            
            <div class="x_content">
                <div class="" data-example-id="togglable-tabs">
                    
                    <ul  class="nav nav-tabs bordered">
                        <li class="<?php if(isset($list)){ echo 'active'; }?>"><a href="#tab_project_list"   role="tab" data-toggle="tab" aria-expanded="true"><i class="fa fa-list-ol"></i> List</a> </li>
                        <li  class="<?php if(isset($add)){ echo 'active'; }?>"><a href="#tab_add_project"  role="tab"  data-toggle="tab" aria-expanded="false"><i class="fa fa-plus-square-o"></i> Add </a> </li>                          
                        <?php if(isset($edit)){ ?>
                            <li  class="active"><a href="#tab_edit_project"  role="tab"  data-toggle="tab" aria-expanded="false"><i class="fa fa-pencil-square-o"></i> Edit </a> </li>                          
                        <?php } ?> 
                    </ul>
                    <br/>
                    
                    <div class="tab-content">
                        <div  class="tab-pane fade in <?php if(isset($list)){ echo 'active'; }?>" id="tab_project_list" >
                            <div class="x_content">
                            <table id="datatable-responsive" class="table table-striped table-bordered dt-responsive nowrap" cellspacing="0" width="100%">
                                <thead>
                                    <tr>
                                        <th>#Sl</th>
                                        <th>Name</th>
                                        <th>Address</th>
                                        <th>Project Status</th>
                                        <th>Is Feature?</th>
                                        <th>Project Image</th>
                                        <th>Status</th>
                                        <th>Action</th>                                            
                                    </tr>
                                </thead>
                                <tbody>   
                                    <?php $count = 1; if(isset($projects) && !empty($projects)){ ?>
                                        <?php foreach($projects as $obj){ ?>
                                        <tr>
                                            <td><?php echo $count++; ?></td>
                                            <td><?php echo $obj->name; ?></td>
                                            <td><?php echo $obj->address; ?></td>
                                            <td><?php echo ucfirst($obj->project_status); ?></td>
                                            <td><?php echo $obj->is_featured == 1? 'Yes' : 'No'; ?></td>
                                            <td>
                                            <?php if($obj->image){ ?>
                                                <img src="<?php echo base_url(UPLOAD_PATH); ?>/project/<?php echo $obj->image; ?>" alt="" height="150" width="150" /><br/><br/>
                                            <?php } ?>
                                            </td>
                                            <td><?php echo $obj->status == 1? 'Active' : 'Inactive'; ?></td>
                                            <td>
                                                <a  onclick="get_project_modal(<?php echo $obj->id; ?>);"  data-toggle="modal" data-target=".bs-project-modal-lg"  class="btn btn-success btn-xs"><i class="fa fa-eye"></i> View </a>
                                                <a href="<?php echo site_url('admin/project/edit/'.$obj->id); ?>" class="btn btn-info btn-xs"><i class="fa fa-pencil-square-o"></i> Edit </a>
                                                <a href="<?php echo site_url('admin/project/delete/'.$obj->id); ?>" onclick="javascript: return confirm('Are you sure you want to delete this project ?');" class="btn btn-danger btn-xs"><i class="fa fa-trash-o"></i> Delete </a>
                                         </td>
                                        </tr>
                                        <?php } ?>
                                    <?php } ?>
                                </tbody>
                            </table>
                            </div>
                        </div>

                        <div  class="tab-pane fade in <?php if(isset($add)){ echo 'active'; }?>" id="tab_add_project">
                            <div class="x_content"> 
                                
                               <?php 
                                    $attributes = ['class' => 'form-horizontal form-label-left', 'id' => 'add', 'name'=>'add'];
                                    echo form_open_multipart(site_url('admin/project/add'), $attributes);
                                ?>
                                
                                <div class="row">
                                    
                                    <div class="col-md-3 col-sm-3 col-xs-12">
                                        <div class="item form-group">
                                            <label for="name">Name <span class="required">*</span></label>
                                            <input  class="form-control col-md-7 col-xs-12"  name="name"  id="name" value="<?php echo isset($post['name']) ?  $post['name'] : ''; ?>" placeholder="Name" required="required" type="text">
                                            <div class="help-block"><?php if($validator->getError('name')) { echo  $validator->getError('name'); } ?></div>
                                        </div>
                                    </div>
                                    <div class="col-md-3 col-sm-3 col-xs-12">
                                        <div class="item form-group">
                                            <label for="project_type">Property Type <span class="required">*</span></label>
                                                <select  class="form-control col-md-7 col-xs-12"  name="project_type"  id="project_type" required="required">
                                                    <?php $project_type = get_project_type(); ?>
                                                    <option value="">--Select project type--</option>
                                                    <?php foreach($project_type as $key=>$value){ ?>
                                                        <option value="<?php echo $key; ?>" <?php echo isset($post['project_type']) && $post['project_type'] == $key ?  'selected="selected"' : ''; ?>><?php echo $value; ?></option>
                                                    <?php } ?>
                                                </select>
                                        <div class="help-block"><?php if($validator->getError('project_type')) { echo  $validator->getError('project_type'); } ?></div>
                                        </div>
                                    </div>
                                    <div class="col-md-3 col-sm-3 col-xs-12">
                                        <div class="item form-group">
                                            <label for="latitude">Latitude </label>
                                            <input  class="form-control col-md-7 col-xs-12"  name="latitude"  id="latitude" value="<?php echo isset($post['latitude']) ?  $post['latitude'] : ''; ?>" placeholder="Latitude"  type="text">
                                            <div class="help-block"><?php if($validator->getError('latitude')) { echo  $validator->getError('latitude'); } ?></div>
                                        </div>
                                    </div>
                                    <div class="col-md-3 col-sm-3 col-xs-12">
                                        <div class="item form-group">
                                            <label for="longitude">Longitude </label>
                                            <input  class="form-control col-md-7 col-xs-12"  name="longitude"  id="longitude" value="<?php echo isset($post['longitude']) ?  $post['longitude'] : ''; ?>" placeholder="Longitude"  type="text">
                                            <div class="help-block"><?php if($validator->getError('longitude')) { echo  $validator->getError('longitude'); } ?></div>
                                        </div>
                                    </div>
                                    
                                </div>
                                
                                <div class="row">
                                    
                                    <div class="col-md-3 col-sm-3 col-xs-12">
                                        <div class="item form-group">
                                            <label for="location">Location </label>
                                            <input  class="form-control col-md-7 col-xs-12"  name="location"  id="location" value="<?php echo isset($post['location']) ?  $post['location'] : ''; ?>" placeholder="Location" required="required" type="text">
                                            <div class="help-block"><?php if($validator->getError('location')) { echo  $validator->getError('location'); } ?></div>
                                        </div>
                                    </div>
                                    <div class="col-md-3 col-sm-3 col-xs-12">
                                        <div class="item form-group">
                                            <label for="land_amount">Land Amount </label>
                                            <input  class="form-control col-md-7 col-xs-12"  name="land_amount"  id="land_amount" value="<?php echo isset($post['land_amount']) ?  $post['land_amount'] : ''; ?>" placeholder="Land Amount" type="text">
                                            <div class="help-block"><?php if($validator->getError('land_amount')) { echo  $validator->getError('land_amount'); } ?></div>
                                        </div>
                                    </div>
                                    <div class="col-md-3 col-sm-3 col-xs-12">
                                        <div class="item form-group">
                                            <label for="approval_no">Approval No </label>
                                            <input  class="form-control col-md-7 col-xs-12"  name="approval_no"  id="approval_no" value="<?php echo isset($post['approval_no']) ?  $post['approval_no'] : ''; ?>" placeholder="Approval No" type="text">
                                            <div class="help-block"><?php if($validator->getError('approval_no')) { echo  $validator->getError('approval_no'); } ?></div>
                                        </div>
                                    </div>
                                    <div class="col-md-3 col-sm-3 col-xs-12">
                                        <div class="item form-group">
                                            <label for="approval_date">Approval Date <span class="required">*</span></label>
                                            <input  class="form-control col-md-7 col-xs-12"  name="approval_date"  id="add_approval_date" value="<?php echo isset($post['approval_date']) ?  $post['approval_date'] : ''; ?>" placeholder="Approval Date" required="required"  type="text" autocomplete="off">
                                            <div class="help-block"><?php if($validator->getError('approval_date')) { echo  $validator->getError('approval_date'); } ?></div>
                                        </div>
                                    </div>
                                    
                                </div>
                                
                                <div class="row">
                                    
                                    <div class="col-md-3 col-sm-3 col-xs-12">
                                        <div class="item form-group">
                                            <label for="front_view">Front View </label>
                                            <input  class="form-control col-md-7 col-xs-12"  name="front_view"  id="front_view" value="<?php echo isset($post['front_view']) ?  $post['front_view'] : ''; ?>" placeholder="Front View" type="text">
                                            <div class="help-block"><?php if($validator->getError('front_view')) { echo  $validator->getError('front_view'); } ?></div>
                                        </div>
                                    </div>
                                    <div class="col-md-3 col-sm-3 col-xs-12">
                                        <div class="item form-group">
                                            <label for="no_of_building">No of Building </label>
                                            <input  class="form-control col-md-7 col-xs-12"  name="no_of_building"  id="no_of_building" value="<?php echo isset($post['no_of_building']) ?  $post['no_of_building'] : ''; ?>" placeholder="No of Building" type="text">
                                            <div class="help-block"><?php if($validator->getError('no_of_building')) { echo  $validator->getError('no_of_building'); } ?></div>
                                        </div>
                                    </div>
                                    <div class="col-md-3 col-sm-3 col-xs-12">
                                        <div class="item form-group">
                                            <label for="total_floor">Total Floor </label>
                                            <input  class="form-control col-md-7 col-xs-12"  name="total_floor"  id="total_floor" value="<?php echo isset($post['total_floor']) ?  $post['total_floor'] : ''; ?>" placeholder="Total Floor" type="text">
                                            <div class="help-block"><?php if($validator->getError('total_floor')) { echo  $validator->getError('total_floor'); } ?></div>
                                        </div>
                                    </div>
                                    <div class="col-md-3 col-sm-3 col-xs-12">
                                        <div class="item form-group">
                                            <label for="total_flat">Total Flat </label>
                                            <input  class="form-control col-md-7 col-xs-12"  name="total_flat"  id="total_flat" value="<?php echo isset($post['total_flat']) ?  $post['total_flat'] : ''; ?>" placeholder="Total Flat"  type="number" autocomplete="off">
                                            <div class="help-block"><?php if($validator->getError('total_flat')) { echo  $validator->getError('total_flat'); } ?></div>
                                        </div>
                                    </div>
                                    
                                </div>                                                      
                                
                                <div class="row">
                                    
                                    <div class="col-md-3 col-sm-3 col-xs-12">
                                        <div class="item form-group">
                                            <label for="total_sale">Total Sale </label>
                                            <input  class="form-control col-md-7 col-xs-12"  name="total_sale"  id="total_sale" value="<?php echo isset($post['total_sale']) ?  $post['total_sale'] : ''; ?>" placeholder="Total Sale" type="number">
                                            <div class="help-block"><?php if($validator->getError('total_sale')) { echo  $validator->getError('total_sale'); } ?></div>
                                        </div>
                                    </div>
                                    <div class="col-md-3 col-sm-3 col-xs-12">
                                        <div class="item form-group">
                                            <label for="total_available">Total Available </label>
                                            <input  class="form-control col-md-7 col-xs-12"  name="total_available"  id="total_available" value="<?php echo isset($post['total_available']) ?  $post['total_available'] : ''; ?>" placeholder="Total Available" type="text">
                                            <div class="help-block"><?php if($validator->getError('total_available')) { echo  $validator->getError('total_available'); } ?></div>
                                        </div>
                                    </div>
                                    <div class="col-md-3 col-sm-3 col-xs-12">
                                        <div class="item form-group">
                                            <label for="flat_sft">Squere Feet </label>
                                            <input  class="form-control col-md-7 col-xs-12"  name="flat_sft"  id="flat_sft" value="<?php echo isset($post['flat_sft']) ?  $post['flat_sft'] : ''; ?>" placeholder="Squere Feet" type="text">
                                            <div class="help-block"><?php if($validator->getError('flat_sft')) { echo  $validator->getError('flat_sft'); } ?></div>
                                        </div>
                                    </div>
                                    <div class="col-md-3 col-sm-3 col-xs-12">
                                        <div class="item form-group">
                                            <label for="flat_bed">Total Bed </label>
                                            <input  class="form-control col-md-7 col-xs-12"  name="flat_bed"  id="flat_bed" value="<?php echo isset($post['flat_bed']) ?  $post['flat_bed'] : ''; ?>" placeholder="Total Bed"  type="text" autocomplete="off">
                                            <div class="help-block"><?php if($validator->getError('flat_bed')) { echo  $validator->getError('flat_bed'); } ?></div>
                                        </div>
                                    </div>
                                    
                                </div>
                                
                                <div class="row">
                                    
                                    <div class="col-md-3 col-sm-3 col-xs-12">
                                        <div class="item form-group">
                                            <label for="flat_bath">Total Bath </label>
                                            <input  class="form-control col-md-7 col-xs-12"  name="flat_bath"  id="flat_bath" value="<?php echo isset($post['flat_bath']) ?  $post['flat_bath'] : ''; ?>" placeholder="Total Bath" type="text">
                                            <div class="help-block"><?php if($validator->getError('flat_bath')) { echo  $validator->getError('flat_bath'); } ?></div>
                                        </div>
                                    </div>
                                    <div class="col-md-3 col-sm-3 col-xs-12">
                                        <div class="item form-group">
                                            <label for="flat_baranda">Total Baranda </label>
                                            <input  class="form-control col-md-7 col-xs-12"  name="flat_baranda"  id="flat_baranda" value="<?php echo isset($post['flat_baranda']) ?  $post['flat_baranda'] : ''; ?>" placeholder="Total Baranda" type="text">
                                            <div class="help-block"><?php if($validator->getError('flat_baranda')) { echo  $validator->getError('flat_baranda'); } ?></div>
                                        </div>
                                    </div>
                                    <div class="col-md-3 col-sm-3 col-xs-12">
                                        <div class="item form-group">
                                            <label for="flat_bachine">Total Bachine </label>
                                            <input  class="form-control col-md-7 col-xs-12"  name="flat_bachine"  id="flat_bachine" value="<?php echo isset($post['flat_bachine']) ?  $post['flat_bachine'] : ''; ?>" placeholder="Squere Bachine" type="text">
                                            <div class="help-block"><?php if($validator->getError('flat_bachine')) { echo  $validator->getError('flat_bachine'); } ?></div>
                                        </div>
                                    </div>
                                    <div class="col-md-3 col-sm-3 col-xs-12">
                                        <div class="item form-group">
                                            <label for="flat_window">Total Window </label>
                                            <input  class="form-control col-md-7 col-xs-12"  name="flat_window"  id="flat_window" value="<?php echo isset($post['flat_window']) ?  $post['flat_window'] : ''; ?>" placeholder="Total Window"  type="text" autocomplete="off">
                                            <div class="help-block"><?php if($validator->getError('flat_window')) { echo  $validator->getError('flat_window'); } ?></div>
                                        </div>
                                    </div>
                                    
                                </div>
                                
                                <div class="row">
                                    
                                    <div class="col-md-3 col-sm-3 col-xs-12">
                                        <div class="item form-group">
                                            <label for="flat_dyning">Total Dyning </label>
                                            <input  class="form-control col-md-7 col-xs-12"  name="flat_dyning"  id="flat_dyning" value="<?php echo isset($post['flat_dyning']) ?  $post['flat_dyning'] : ''; ?>" placeholder="Total Dyning" type="text">
                                            <div class="help-block"><?php if($validator->getError('flat_dyning')) { echo  $validator->getError('flat_dyning'); } ?></div>
                                        </div>
                                    </div>
                                    <div class="col-md-3 col-sm-3 col-xs-12">
                                        <div class="item form-group">
                                            <label for="flat_drawing">Total Drawing </label>
                                            <input  class="form-control col-md-7 col-xs-12"  name="flat_drawing"  id="flat_drawing" value="<?php echo isset($post['flat_drawing']) ?  $post['flat_drawing'] : ''; ?>" placeholder="Total Drawing" type="text">
                                            <div class="help-block"><?php if($validator->getError('flat_drawing')) { echo  $validator->getError('flat_drawing'); } ?></div>
                                        </div>
                                    </div>
                                    <div class="col-md-3 col-sm-3 col-xs-12">
                                        <div class="item form-group">
                                            <label for="flat_kitchen">Total Kitchen </label>
                                            <input  class="form-control col-md-7 col-xs-12"  name="flat_kitchen"  id="flat_kitchen" value="<?php echo isset($post['flat_kitchen']) ?  $post['flat_kitchen'] : ''; ?>" placeholder="Total Kitchen" type="text">
                                            <div class="help-block"><?php if($validator->getError('flat_kitchen')) { echo  $validator->getError('flat_kitchen'); } ?></div>
                                        </div>
                                    </div>
                                    <div class="col-md-3 col-sm-3 col-xs-12">
                                        <div class="item form-group">
                                            <label for="flat_store_room">Store Room </label>
                                            <input  class="form-control col-md-7 col-xs-12"  name="flat_store_room"  id="flat_store_room" value="<?php echo isset($post['flat_store_room']) ?  $post['flat_store_room'] : ''; ?>" placeholder="Store Room"  type="text" autocomplete="off">
                                            <div class="help-block"><?php if($validator->getError('flat_store_room')) { echo  $validator->getError('flat_store_room'); } ?></div>
                                        </div>
                                    </div>
                                    
                                </div>
                                
                                <div class="row">
                                    
                                    <div class="col-md-3 col-sm-3 col-xs-12">
                                        <div class="item form-group">
                                            <label for="video">Video Id </label>
                                            <input  class="form-control col-md-7 col-xs-12"  name="video"  id="video" value="<?php echo isset($post['video']) ?  $post['video'] : ''; ?>" placeholder="Video Id" type="text">
                                            <div class="help-block"><?php if($validator->getError('video')) { echo  $validator->getError('video'); } ?></div>
                                        </div>
                                    </div>
                                    <div class="col-md-3 col-sm-3 col-xs-12">
                                        <div class="item form-group">
                                            <label for="project_status">Project Status <span class="required">*</span></label>
                                                <select  class="form-control col-md-7 col-xs-12"  name="project_status"  id="project_status" required="required">
                                                    <?php $project_status = get_project_status(); ?>
                                                    <option value="">--Select project status--</option>
                                                    <?php foreach($project_status as $key=>$value){ ?>
                                                        <option value="<?php echo $key; ?>" <?php echo isset($post['project_status']) && $post['project_status'] == $key ?  'selected="selected"' : ''; ?>><?php echo $value; ?></option>
                                                    <?php } ?>
                                                </select>
                                        <div class="help-block"><?php if($validator->getError('project_status')) { echo  $validator->getError('project_status'); } ?></div>
                                        </div>
                                    </div>
                                    <div class="col-md-3 col-sm-3 col-xs-12">
                                        <div class="item form-group">
                                            <label for="is_featured">Is Featured Project? </label>
                                                <select  class="form-control col-md-7 col-xs-12"  name="is_featured"  id="is_featured">
                                                    <option value="">--Select-- </option>
                                                    <option value="1" <?php if(isset($post['is_featured']) && $post['is_featured'] == 1){ echo 'selected="selected"'; } ?>>Yes</option>
                                                    <option value="0" <?php if(isset($post['is_featured']) && $post['is_featured'] == 0){ echo 'selected="selected"'; } ?>>No</option>
                                                </select>
                                        <div class="help-block"><?php if($validator->getError('is_featured')) { echo  $validator->getError('is_featured'); } ?></div>
                                        </div>
                                    </div>
                                </div>
                                
                                <div class="row">
                                    
                                    <div class="col-md-6 col-sm-6 col-xs-12">
                                        <div class="item form-group">
                                            <label for="address">Address <span class="required">*</span></label>
                                            <textarea  class="form-control col-md-7 col-xs-12 textarea-4column" style="height:70px;"  name="address"  id="address" required="required" placeholder="Address"><?php echo isset($post['address']) ?  $post['address'] : ''; ?></textarea>
                                            <div class="help-block"><?php if($validator->getError('address')) { echo  $validator->getError('address'); } ?></div>
                                        </div>
                                    </div>
                                    <div class="col-md-6 col-sm-6 col-xs-12">
                                        <div class="item form-group">
                                            <label for="note">Note </label>
                                            <textarea  class="form-control col-md-7 col-xs-12 textarea-4column" style="height:70px;"  name="note"  id="note" placeholder="Note"><?php echo isset($post['note']) ?  $post['note'] : ''; ?></textarea>
                                            <div class="help-block"><?php if($validator->getError('note')) { echo  $validator->getError('note'); } ?></div>
                                        </div>
                                    </div>
                                    
                                </div>
                                
                                
                                <div class="row">
                                    
                                    <div class="col-md-3 col-sm-3 col-xs-12">
                                        <div class="item form-group">
                                            <label for="brochure">Project Brochure </label> <br>                                         
                                            <div class="col-md-6 col-sm-6 col-xs-12">                                      
                                                <div class="btn btn-default btn-file">
                                                <i class="fa fa-paperclip"></i> Upload
                                                <input type="file" name="brochure">
                                                </div>
                                                <div class="help-block"><?php if($validator->getError('brochure')) { echo  $validator->getError('brochure'); } ?></div>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="col-md-3 col-sm-3 col-xs-12">
                                        <div class="item form-group">
                                            <label for="image">Project Master Design </label> <br>                                          
                                            <div class="col-md-6 col-sm-6 col-xs-12">                                      
                                                <div class="btn btn-default btn-file">
                                                <i class="fa fa-paperclip"></i> Upload
                                                <input type="file" name="image">
                                                </div>
                                                <div class="help-block"><?php if($validator->getError('image')) { echo  $validator->getError('image'); } ?></div>
                                            </div>
                                        </div>
                                    </div>
                                    
                                </div>
                                </div>
                                
                                <div class="ln_solid"></div>
                                <div class="form-group">
                                    <div class="col-md-6 col-md-offset-3">
                                        <a href="<?php echo site_url('admin/project'); ?>" class="btn btn-primary">Cancel</a>
                                        <button id="send" type="submit" class="btn btn-success">Submit</button>
                                    </div>
                                </div>
                                <?php echo form_close(); ?>
                                
                            </div>
                        </div>  

                        <?php if(isset($edit)){ ?>
                        
                        <div class="tab-pane fade in active" id="tab_edit_project">
                            <div class="x_content"> 
                                 
                               <?php 
                                    $attributes = ['class' => 'form-horizontal form-label-left', 'id' => 'edit', 'name'=>'edit'];
                                    echo form_open_multipart(site_url('admin/project/edit/'.$project->id), $attributes);
                                ?> 
                                
                                <div class="row">
                                    
                                    <div class="col-md-3 col-sm-3 col-xs-12">
                                        <div class="item form-group">
                                            <label for="name">Name <span class="required">*</span></label>
                                            <input  class="form-control col-md-7 col-xs-12"  name="name"  id="name" value="<?php echo isset($project->name) ?  $project->name : ''; ?>" placeholder="Name" required="required" type="text">
                                            <div class="help-block"><?php if($validator->getError('name')) { echo  $validator->getError('name'); } ?></div>
                                        </div>
                                    </div>
                                    <div class="col-md-3 col-sm-3 col-xs-12">
                                        <div class="item form-group">
                                            <label for="project_type">Property Type <span class="required">*</span></label>
                                             <select  class="form-control col-md-7 col-xs-12"  name="project_type"  id="project_type" required="required">
                                                <?php $project_type = get_project_type(); ?>
                                                <option value="">--Select project type--</option>
                                                <?php foreach($project_type as $key=>$value){ ?>
                                                    <option value="<?php echo $key; ?>" <?php if($project->project_type == $key){ echo 'selected="selected"'; } ?>><?php echo $value; ?></option>
                                                <?php } ?>
                                            </select>
                                        <div class="help-block"><?php if($validator->getError('project_type')) { echo  $validator->getError('project_type'); } ?></div>
                                        </div>
                                    </div>
                                    <div class="col-md-3 col-sm-3 col-xs-12">
                                        <div class="item form-group">
                                            <label for="latitude">Latitude</label>
                                            <input  class="form-control col-md-7 col-xs-12"  name="latitude"  id="latitude" value="<?php echo isset($project->latitude) ?  $project->latitude : ''; ?>" placeholder="Latitude" type="text">
                                            <div class="help-block"><?php if($validator->getError('latitude')) { echo  $validator->getError('latitude'); } ?></div>
                                        </div>
                                    </div>                                    
                                    <div class="col-md-3 col-sm-3 col-xs-12">
                                        <div class="item form-group">
                                            <label for="latitude">Longitude</label>
                                            <input  class="form-control col-md-7 col-xs-12"  name="longitude"  id="longitude" value="<?php echo isset($project->longitude) ?  $project->longitude : ''; ?>" placeholder="Longitude" type="text">
                                            <div class="help-block"><?php if($validator->getError('longitude')) { echo  $validator->getError('longitude'); } ?></div>
                                        </div>
                                    </div>
                                    
                                </div>
                                
                                <div class="row">
                                    
                                    <div class="col-md-3 col-sm-3 col-xs-12">
                                        <div class="item form-group">
                                            <label for="location">Location <span class="required">*</span></label>
                                            <input  class="form-control col-md-7 col-xs-12"  name="location"  id="location" value="<?php echo isset($project->location) ?  $project->location : ''; ?>" placeholder="Location" required="required" type="text">
                                            <div class="help-block"><?php if($validator->getError('location')) { echo  $validator->getError('location'); } ?></div>
                                        </div>
                                    </div>
                                    <div class="col-md-3 col-sm-3 col-xs-12">
                                        <div class="item form-group">
                                            <label for="land_amount">Land Amount</label>
                                            <input  class="form-control col-md-7 col-xs-12"  name="land_amount"  id="land_amount" value="<?php echo isset($project->land_amount) ?  $project->land_amount : ''; ?>" placeholder="Land Amount" type="text">
                                            <div class="help-block"><?php if($validator->getError('land_amount')) { echo  $validator->getError('land_amount'); } ?></div>
                                        </div>
                                    </div>                                    
                                    <div class="col-md-3 col-sm-3 col-xs-12">
                                        <div class="item form-group">
                                            <label for="approval_no">Approval No</label>
                                            <input  class="form-control col-md-7 col-xs-12"  name="approval_no"  id="approval_no" value="<?php echo isset($project->approval_no) ?  $project->approval_no : ''; ?>" placeholder="Approval No" type="text">
                                            <div class="help-block"><?php if($validator->getError('approval_no')) { echo  $validator->getError('approval_no'); } ?></div>
                                        </div>
                                    </div>
                                    <div class="col-md-3 col-sm-3 col-xs-12">
                                        <div class="item form-group">
                                            <label for="approval_date">Approval Date <span class="required">*</span></label>
                                            <input  class="form-control col-md-7 col-xs-12"  name="approval_date"  id="edit_approval_date" value="<?php echo isset($project->approval_date) ?  date('Y-m-d', strtotime($project->approval_date)) : ''; ?>" placeholder="Approval Date" required="required" type="text" autocomplete="off">
                                            <div class="help-block"><?php if($validator->getError('approval_date')) { echo  $validator->getError('approval_date'); } ?></div>
                                        </div>
                                    </div>
                                    
                                </div>
                                
                                <div class="row">
                                    
                                    <div class="col-md-3 col-sm-3 col-xs-12">
                                        <div class="item form-group">
                                            <label for="front_view">Front View </label>
                                            <input  class="form-control col-md-7 col-xs-12"  name="front_view"  id="front_view" value="<?php echo isset($project->front_view) ?  $project->front_view : ''; ?>" placeholder="Front View" type="text">
                                            <div class="help-block"><?php if($validator->getError('front_view')) { echo  $validator->getError('front_view'); } ?></div>
                                        </div>
                                    </div>
                                    <div class="col-md-3 col-sm-3 col-xs-12">
                                        <div class="item form-group">
                                            <label for="no_of_building">No of Buliding</label>
                                            <input  class="form-control col-md-7 col-xs-12"  name="no_of_building"  id="no_of_building" value="<?php echo isset($project->no_of_building) ?  $project->no_of_building : ''; ?>" placeholder="No of Buliding" type="text">
                                            <div class="help-block"><?php if($validator->getError('no_of_building')) { echo  $validator->getError('no_of_building'); } ?></div>
                                        </div>
                                    </div>                                    
                                    <div class="col-md-3 col-sm-3 col-xs-12">
                                        <div class="item form-group">
                                            <label for="total_floor">Total Floor</label>
                                            <input  class="form-control col-md-7 col-xs-12"  name="total_floor"  id="total_floor" value="<?php echo isset($project->total_floor) ?  $project->total_floor : ''; ?>" placeholder="Total Floor" type="text">
                                            <div class="help-block"><?php if($validator->getError('total_floor')) { echo  $validator->getError('total_floor'); } ?></div>
                                        </div>
                                    </div>
                                    <div class="col-md-3 col-sm-3 col-xs-12">
                                        <div class="item form-group">
                                            <label for="total_flat">Total Flat</label>
                                            <input  class="form-control col-md-7 col-xs-12"  name="total_flat"  id="total_flat" value="<?php echo isset($project->total_flat) ? $project->total_flat : ''; ?>" placeholder="Total Flat" type="number" autocomplete="off">
                                            <div class="help-block"><?php if($validator->getError('total_flat')) { echo  $validator->getError('total_flat'); } ?></div>
                                        </div>
                                    </div>
                                    
                                </div>
                                
                                <div class="row">
                                    
                                    <div class="col-md-3 col-sm-3 col-xs-12">
                                        <div class="item form-group">
                                            <label for="total_sale">Total Sale </label>
                                            <input  class="form-control col-md-7 col-xs-12"  name="total_sale"  id="total_sale" value="<?php echo isset($project->total_sale) ?  $project->total_sale : ''; ?>" placeholder="Total Sale" type="number">
                                            <div class="help-block"><?php if($validator->getError('total_sale')) { echo  $validator->getError('total_sale'); } ?></div>
                                        </div>
                                    </div>
                                    <div class="col-md-3 col-sm-3 col-xs-12">
                                        <div class="item form-group">
                                            <label for="total_available">Total Available</label>
                                            <input  class="form-control col-md-7 col-xs-12"  name="total_available"  id="total_available" value="<?php echo isset($project->total_available) ?  $project->total_available : ''; ?>" placeholder="Total Available" type="text">
                                            <div class="help-block"><?php if($validator->getError('total_available')) { echo  $validator->getError('total_available'); } ?></div>
                                        </div>
                                    </div>                                    
                                    <div class="col-md-3 col-sm-3 col-xs-12">
                                        <div class="item form-group">
                                            <label for="flat_sft">Squere Feet</label>
                                            <input  class="form-control col-md-7 col-xs-12"  name="flat_sft"  id="flat_sft" value="<?php echo isset($project->flat_sft) ?  $project->flat_sft : ''; ?>" placeholder="Squere Feet" type="text">
                                            <div class="help-block"><?php if($validator->getError('flat_sft')) { echo  $validator->getError('flat_sft'); } ?></div>
                                        </div>
                                    </div>
                                    <div class="col-md-3 col-sm-3 col-xs-12">
                                        <div class="item form-group">
                                            <label for="flat_bed">Total Bed</label>
                                            <input  class="form-control col-md-7 col-xs-12"  name="flat_bed"  id="flat_bed" value="<?php echo isset($project->flat_bed) ? $project->flat_bed : ''; ?>" placeholder="Total Bed" type="text" autocomplete="off">
                                            <div class="help-block"><?php if($validator->getError('flat_bed')) { echo  $validator->getError('flat_bed'); } ?></div>
                                        </div>
                                    </div>
                                    
                                </div>
                                
                                <div class="row">
                                    
                                    <div class="col-md-3 col-sm-3 col-xs-12">
                                        <div class="item form-group">
                                            <label for="flat_bath">Total Bath </label>
                                            <input  class="form-control col-md-7 col-xs-12"  name="flat_bath"  id="flat_bath" value="<?php echo isset($project->flat_bath) ?  $project->flat_bath : ''; ?>" placeholder="Total Bath" type="text">
                                            <div class="help-block"><?php if($validator->getError('flat_bath')) { echo  $validator->getError('flat_bath'); } ?></div>
                                        </div>
                                    </div>
                                    <div class="col-md-3 col-sm-3 col-xs-12">
                                        <div class="item form-group">
                                            <label for="flat_baranda">Total Baranda</label>
                                            <input  class="form-control col-md-7 col-xs-12"  name="flat_baranda"  id="flat_baranda" value="<?php echo isset($project->flat_baranda) ?  $project->flat_baranda : ''; ?>" placeholder="Total Baranda" type="text">
                                            <div class="help-block"><?php if($validator->getError('flat_baranda')) { echo  $validator->getError('flat_baranda'); } ?></div>
                                        </div>
                                    </div>                                    
                                    <div class="col-md-3 col-sm-3 col-xs-12">
                                        <div class="item form-group">
                                            <label for="flat_bachine">Total Bachine</label>
                                            <input  class="form-control col-md-7 col-xs-12"  name="flat_bachine"  id="flat_bachine" value="<?php echo isset($project->flat_bachine) ?  $project->flat_bachine : ''; ?>" placeholder="Total Bachine" type="text">
                                            <div class="help-block"><?php if($validator->getError('flat_bachine')) { echo  $validator->getError('flat_bachine'); } ?></div>
                                        </div>
                                    </div>
                                    <div class="col-md-3 col-sm-3 col-xs-12">
                                        <div class="item form-group">
                                            <label for="flat_window">Total Window</label>
                                            <input  class="form-control col-md-7 col-xs-12"  name="flat_window"  id="flat_window" value="<?php echo isset($project->flat_window) ? $project->flat_window : ''; ?>" placeholder="Total Window" type="text" autocomplete="off">
                                            <div class="help-block"><?php if($validator->getError('flat_window')) { echo  $validator->getError('flat_window'); } ?></div>
                                        </div>
                                    </div>
                                    
                                </div>
                                
                                <div class="row">
                                    
                                    <div class="col-md-3 col-sm-3 col-xs-12">
                                        <div class="item form-group">
                                            <label for="flat_dyning">Total Dyning </label>
                                            <input  class="form-control col-md-7 col-xs-12"  name="flat_dyning"  id="flat_dyning" value="<?php echo isset($project->flat_dyning) ?  $project->flat_dyning : ''; ?>" placeholder="Total Dyning" type="text">
                                            <div class="help-block"><?php if($validator->getError('flat_dyning')) { echo  $validator->getError('flat_dyning'); } ?></div>
                                        </div>
                                    </div>
                                    <div class="col-md-3 col-sm-3 col-xs-12">
                                        <div class="item form-group">
                                            <label for="flat_drawing">Total Drawing</label>
                                            <input  class="form-control col-md-7 col-xs-12"  name="flat_drawing"  id="flat_drawing" value="<?php echo isset($project->flat_drawing) ?  $project->flat_drawing : ''; ?>" placeholder="Total Drawing" type="text">
                                            <div class="help-block"><?php if($validator->getError('flat_drawing')) { echo  $validator->getError('flat_drawing'); } ?></div>
                                        </div>
                                    </div>                                    
                                    <div class="col-md-3 col-sm-3 col-xs-12">
                                        <div class="item form-group">
                                            <label for="flat_kitchen">Total Kitchen</label>
                                            <input  class="form-control col-md-7 col-xs-12"  name="flat_kitchen"  id="flat_kitchen" value="<?php echo isset($project->flat_kitchen) ?  $project->flat_kitchen : ''; ?>" placeholder="Total Kitchen" type="text">
                                            <div class="help-block"><?php if($validator->getError('flat_kitchen')) { echo  $validator->getError('flat_kitchen'); } ?></div>
                                        </div>
                                    </div>
                                    <div class="col-md-3 col-sm-3 col-xs-12">
                                        <div class="item form-group">
                                            <label for="flat_store_room">Store Room</label>
                                            <input  class="form-control col-md-7 col-xs-12"  name="flat_store_room"  id="flat_store_room" value="<?php echo isset($project->flat_store_room) ?  $project->flat_store_room : ''; ?>" placeholder="Store Room" type="text">
                                            <div class="help-block"><?php if($validator->getError('flat_store_room')) { echo  $validator->getError('flat_store_room'); } ?></div>
                                        </div>
                                    </div>
                                    
                                </div>
                                
                                <div class="row">
                                    
                                    <div class="col-md-3 col-sm-3 col-xs-12">
                                        <div class="item form-group">
                                            <label for="video">Video Id </label>
                                            <input  class="form-control col-md-7 col-xs-12"  name="video"  id="video" value="<?php echo isset($project->video) ?  $project->video : ''; ?>" placeholder="Video Id" type="text">
                                            <div class="help-block"><?php if($validator->getError('video')) { echo  $validator->getError('video'); } ?></div>
                                        </div>
                                    </div>
                                    <div class="col-md-3 col-sm-3 col-xs-12">
                                        <div class="item form-group">
                                            <label for="project_status">Project Status <span class="required">*</span></label>
                                            <select  class="form-control col-md-7 col-xs-12"  name="project_status"  id="project_status" required="required">
                                                <?php $project_status = get_project_status(); ?>
                                                <option value="">--Select project status--</option>
                                                <?php foreach($project_status as $key=>$value){ ?>
                                                    <option value="<?php echo $key; ?>" <?php if($project->project_status == $key){ echo 'selected="selected"'; } ?>><?php echo $value; ?></option>
                                                <?php } ?>
                                            </select>
                                        <div class="help-block"><?php if($validator->getError('project_status')) { echo  $validator->getError('project_status'); } ?></div>
                                        </div>
                                    </div>                                    
                                    <div class="col-md-3 col-sm-3 col-xs-12">
                                        <div class="item form-group">
                                            <label for="blood_group">Is Featured Project? </label>
                                            <select  class="form-control col-md-7 col-xs-12"  name="is_featured"  id="is_featured">
                                                <option value="">--Select-- </option>
                                                <option value="1" <?php if(isset($project) && $project->is_featured == 1){ echo 'selected="selected"'; } ?>>Yes</option>
                                                <option value="0" <?php if(isset($project) && $project->is_featured == 0){ echo 'selected="selected"'; } ?>>No</option>
                                            </select>
                                        <div class="help-block"><?php if($validator->getError('is_featured')) { echo  $validator->getError('is_featured'); } ?></div>
                                        </div>
                                    </div>
                                    <div class="col-md-3 col-sm-3 col-xs-12">
                                        <div class="item form-group">
                                            <label for="flat_store_room">Store Room</label>
                                            <input  class="form-control col-md-7 col-xs-12"  name="flat_store_room"  id="flat_store_room" value="<?php echo isset($project->flat_store_room) ?  $project->flat_store_room : ''; ?>" placeholder="Store Room" type="text">
                                            <div class="help-block"><?php if($validator->getError('flat_store_room')) { echo  $validator->getError('flat_store_room'); } ?></div>
                                        </div>
                                    </div>
                                    
                                </div>
                                
                                <div class="row">
                                    
                                    <div class="col-md-6 col-sm-6 col-xs-12">
                                        <div class="item form-group">
                                            <label for="address"> Address <span class="required">*</span></label>
                                            <textarea  class="form-control col-md-7 col-xs-12 textarea-4column" style="height:70px;" name="address" required="required" id="address" placeholder="Address"><?php echo isset($project->address) ?  $project->address : ''; ?></textarea>
                                            <div class="help-block"><?php if($validator->getError('address')) { echo  $validator->getError('address'); } ?></div>
                                        </div>
                                    </div>
                                    <div class="col-md-6 col-sm-6 col-xs-12">
                                        <div class="item form-group">
                                            <label for="note">Note </label>
                                            <textarea  class="form-control col-md-7 col-xs-12 textarea-4column" style="height:70px;" name="note"  id="present_address" placeholder="Note"><?php echo isset($project->note) ?  $project->note : ''; ?></textarea>
                                            <div class="help-block"><?php if($validator->getError('note')) { echo  $validator->getError('note'); } ?></div>
                                        </div>
                                   </div>                                    
                                    
                                </div>
                                
                                <div class="row">
                                    
                                    <div class="col-md-3 col-sm-3 col-xs-12">
                                        <div class="item form-group">
                                            <label for="brochure">Project Brochure </label>  <br>                                          
                                            <div class="col-md-6 col-sm-6 col-xs-12"> 
                                                <?php if(isset($project) && $project->brochure != ''){ ?>
                                                    <img src="<?php echo base_url(UPLOAD_PATH); ?>/project/<?php echo $project->brochure; ?>" alt="" width="100" /><br/><br/>
                                                     <input name="brochure_prev" value="<?php echo isset($project) ? $project->brochure : ''; ?>"  type="hidden">
                                                <?php } ?>
                                                <div class="btn btn-default btn-file">
                                                    <i class="fa fa-paperclip"></i> Upload
                                                    <input type="file" name="brochure" >
                                                </div>
                                                <div class="help-block"><?php if($validator->getError('brochure')) { echo  $validator->getError('brochure'); } ?></div>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="col-md-3 col-sm-3 col-xs-12">
                                        <div class="item form-group">
                                            <label for="image">Project Master Design </label> <br>                                           
                                            <div class="col-md-6 col-sm-6 col-xs-12"> 
                                                <?php if(isset($project) && $project->image != ''){ ?>
                                                    <img src="<?php echo base_url(UPLOAD_PATH); ?>/project/<?php echo $project->image; ?>" alt="" width="100" /><br/><br/>
                                                     <input name="image_prev" value="<?php echo isset($project) ? $project->image : ''; ?>"  type="hidden">
                                                <?php } ?>
                                                <div class="btn btn-default btn-file">
                                                    <i class="fa fa-paperclip"></i> Upload
                                                    <input type="file" name="image" >
                                                </div>
                                                <div class="help-block"><?php if($validator->getError('image')) { echo  $validator->getError('image'); } ?></div>
                                            </div>
                                        </div>
                                    </div> 
                                    <div class="col-md-3 col-sm-3 col-xs-12">
                                        <div class="item form-group">
                                            <label for="status">Status</label>
                                            <select  class="form-control col-md-7 col-xs-12"  name="status"  id="status">
                                                <option value="">--Select status-- </option>
                                                <option value="1" <?php if(isset($project) && $project->status == 1){ echo 'selected="selected"'; } ?>>Active</option>
                                                <option value="0" <?php if(isset($project) && $project->status == 0){ echo 'selected="selected"'; } ?>>In Active</option>
                                            </select>
                                        <div class="help-block"><?php if($validator->getError('status')) { echo  $validator->getError('status'); } ?></div>
                                        </div>
                                    </div>
                                    
                                </div>
                                </div>                                                               
                                
                                <div class="ln_solid"></div>
                                <div class="form-group">
                                    <div class="col-md-6 col-md-offset-3">
                                        <input type="hidden" name="user_id" id="user_id" value="<?php echo $project->user_id; ?>" />
                                        <input type="hidden" name="id" id="id" value="<?php echo $project->id; ?>" />
                                        <a href="<?php echo site_url('admin/project'); ?>" class="btn btn-primary">Cancel</a>
                                        <button id="send" type="submit" class="btn btn-success">Update</button>
                                    </div>
                                </div>
                                <?php echo form_close(); ?>
                            </div>
                        </div>                          
                        <?php } ?>                 
                        
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<div class="modal fade bs-project-modal-lg" tabindex="-1" role="dialog" aria-hidden="true">
    <div class="modal-dialog modal-lg">
      <div class="modal-content">
        <div class="modal-header">
          <button type="button" class="close" data-dismiss="modal"><span aria-hidden="true">×</span></button>
          <h4 class="modal-title">Project Details</h4>
        </div>
        <div class="modal-body fn_project_data">            
        </div>       
      </div>
    </div>
</div>

<script type="text/javascript">
      
    function get_project_modal(project_id){
                 
        $('.fn_flat_data').html('<p style="padding: 20px;"><p style="padding: 20px;text-align:center;"><img src="<?php echo base_url(IMG_URL); ?>/loader.gif" /></p>');
        $.ajax({       
          type   : "POST",
          url    : "<?php echo base_url('admin/project/view'); ?>",
          data   : {project_id : project_id},  
          success: function(response){                                                   
             if(response)
             {
                $('.fn_project_data').html(response);
             }
          }
       });
    }
    
</script>

<link href="<?php echo base_url(VENDOR_URL); ?>/datepicker/datepicker.css" rel="stylesheet">
<script src="<?php echo base_url(VENDOR_URL); ?>/datepicker/datepicker.js"></script>
<!-- datatable with buttons -->
 <script type="text/javascript">
     
     $('#add_approval_date').datepicker(); 
     $('#edit_approval_date').datepicker(); 
     
        $(document).ready(function() {
          $('#datatable-responsive').DataTable( {
              dom: 'Bfrtip',
              iDisplayLength: 15,
              buttons: [
                  'copyHtml5',
                  'excelHtml5',
                  'csvHtml5',
                  'pdfHtml5',
                  'pageLength'
              ],
              search: true
          });
        });
        
        $('#add').validate();
        $('#edit').validate();
</script>

<?php echo $this->endSection(); ?>