<table class="table table-striped table-bordered dt-responsive nowrap" cellspacing="0" width="100%">
    <tbody>

        <tr>
            <th width="20%">Name </th>
            <td  width="30%"> <?php echo $project->name; ?></td>
            <th width="20%">Property Type </th>
            <td width="30%"> <?php echo ucfirst($project->project_type); ?></td> 
        </tr>
          
        <tr>
            <th>Project Status </th>
            <td ><?php echo ucfirst($project->project_status); ?></td> 
            <th>Project Brochure </th>
            <td>
                <?php if($project->brochure){ ?>
                <a target="_blank" href="<?php echo base_url(UPLOAD_PATH); ?>/project/<?php echo $project->brochure; ?>" class="btn btn-success btn-xs"> <i class="fa fa-download"></i> Download</a> <br/>
                <?php } ?>
            </td> 
        </tr>
        
        <tr>
            <th>Latitude </th>
            <td> <?php echo $project->latitude; ?></td> 
            <th>Longitude </th>
            <td><?php echo $project->longitude; ?></td> 
        </tr>
        
        <tr>
            <th>Address </th>
            <td> <?php echo $project->address; ?></td> 
            <th>Location </th>
            <td><?php echo $project->location; ?></td> 
        </tr>
        
        <tr>
            <th> Front View </th>
            <td><?php echo $project->front_view; ?></td> 
            <th>Land Amount </th>
            <td><?php echo $project->land_amount; ?></td> 
        </tr>
        
        <tr>
            <th>Approval No </th>
            <td><?php echo $project->approval_no; ?></td> 
            <th>Approval Date </th>
            <td><?php echo $project->approval_date != '' ? date('d-m-Y', strtotime($project->approval_date)) : ''; ?></td>      
        </tr>
        
        <tr>
            <th>No Of Building </th>
            <td> <?php echo $project->no_of_building; ?></td> 
            <th>Total Floor </th>
            <td><?php echo $project->total_floor; ?></td> 
        </tr>
        
        <tr>
            <th>Total Flat </th>
            <td> <?php echo $project->total_flat; ?></td> 
            <th>Total Sale </th>
            <td><?php echo $project->total_sale; ?></td> 
        </tr>
        
        <tr>
            <th>Squere Feet </th>
            <td> <?php echo $project->flat_sft; ?></td> 
            <th>Total Bed </th>
            <td><?php echo $project->flat_bed; ?></td> 
        </tr>
        
        <tr>
            <th>Total Bath </th>
            <td> <?php echo $project->flat_bath; ?></td> 
            <th>Total Baranda </th>
            <td><?php echo $project->flat_baranda; ?></td> 
        </tr>
        
        <tr>
            <th>Total Bachine </th>
            <td> <?php echo $project->flat_bachine; ?></td> 
            <th>Total Window </th>
            <td><?php echo $project->flat_window; ?></td> 
        </tr>
        
        <tr>
            <th>Total Dyning </th>
            <td> <?php echo $project->flat_dyning; ?></td> 
            <th>Total Drawing </th>
            <td><?php echo $project->flat_drawing; ?></td> 
        </tr>
        
        <tr>
            <th>Total Kitchen </th>
            <td> <?php echo $project->flat_kitchen; ?></td> 
            <th>Store Room </th>
            <td><?php echo $project->flat_store_room; ?></td> 
        </tr>
        
        <tr>
            <th> Available </th>
            <td> <?php echo $project->total_available; ?></td> 
            <th>Status </th>
            <td > <?php echo $project->status ==1? 'Active' : 'Inactive'; ?></td> 
        </tr>
        
        <tr>
            <th>Is Featured Project? </th>
            <td ><?php echo $project->is_featured ==1 ? 'Yes' : 'No'; ?></td>        
            <th>Master Design </th>
            <td>
                <?php if($project->image){ ?>
                    <img src="<?php echo base_url(UPLOAD_PATH); ?>/project/<?php echo $project->image; ?>" alt="" height="300" width="300" />
                <?php } ?>
            </td> 
        </tr>  
        
        <tr>    
            <th>Video Id</th>
            <td colspan="3"><?php echo $project->video; ?></td> 
            <th>Note </th>
            <td colspan="3"><?php echo $project->note; ?></td> 
        </tr>
        
    </tbody>
</table>
