<?php echo $this->extend("layouts/master"); ?>
<?php echo $this->section("content"); ?>

<div class="row">
    <div class="col-md-12 col-sm-12 col-xs-12">
        <div class="x_panel">
            <div class="x_title">
                <h3 class="head-title"><i class="fa fa-lock"></i><small> Reset Password</small></h3>
                <ul class="nav navbar-right panel_toolbox">
                    <li><a class="collapse-link"><i class="fa fa-chevron-up"></i></a></li>                    
                </ul>
                <div class="clearfix"></div>
            </div>
            
            <div class="x_content quick-link">
                <?php  echo $this->include($path. '/quick-link-profile'); ?>               
            </div>
            
            <div class="x_content">
                <div class="" data-example-id="togglable-tabs">                    
                    <ul  class="nav nav-tabs bordered">
                        <li class="active"><a href="#tab_password"   role="tab" data-toggle="tab" aria-expanded="true"><i class="fa fa-gear"></i> Reset Password</a> </li>
                    </ul>
                    <br/>                    
                    <div class="tab-content">                  

                        <div class="tab-pane fade in active" id="tab_password">
                           <div class="x_content"> 
                               
                               <?php 
                                $attributes = ['class' => 'form-horizontal form-label-left', 'id' => 'add', 'name'=>'add'];
                                $action = 'admin/profile/password';
                                echo form_open_multipart(site_url($action), $attributes);
                               ?> 
                               
                                <div class="row">
                                
                                    <div class="item form-group">
                                        <label class="control-label col-md-3 col-sm-3 col-xs-12" for="password">Password <span class="required">*</span></label>
                                        <div class="col-md-6 col-sm-6 col-xs-12">
                                            <input  class="form-control col-md-7 col-xs-12"  name="password"  id="password" value="" required="required" type="password">
                                            <div class="help-block"><?php if($validator->getError('password')) { echo  $validator->getError('password'); } ?></div>
                                        </div>
                                    </div>  

                                    <div class="item form-group">
                                        <label class="control-label col-md-3 col-sm-3 col-xs-12" for="confirm_password">Confirm Password <span class="required">*</span></label>
                                        <div class="col-md-6 col-sm-6 col-xs-12">
                                            <input  class="form-control col-md-7 col-xs-12"  name="confirm_password"  id="confirm_password" value="" required="required" type="password">
                                            <div class="help-block"><?php if($validator->getError('confirm_password')) { echo  $validator->getError('confirm_password'); } ?></div>
                                        </div>
                                    </div>                               
                                </div>
                         
                                <div class="ln_solid"></div>
                                <div class="form-group">
                                    <div class="col-md-6 col-md-offset-3">
                                        <a href="<?php echo site_url('admin/profile/password'); ?>" class="btn btn-primary">Cancel</a>
                                        <button id="send" type="submit" class="btn btn-success">Update</button>
                                    </div>
                                </div>
                                <?php echo form_close(); ?>
                            </div>
                        </div>                         
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>


<script type="text/javascript">
     
$("#add").validate({
        rules: {
        password: {
            required: true,
            minlength: 6
        },
        confirm_password: {
            required: true,
            minlength: 6,
            equalTo: "#password"
        }
        }  
    }); 
    
</script>  

<?php echo $this->endSection(); ?>