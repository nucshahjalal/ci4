<?php echo $this->extend("layouts/master"); ?>
<?php echo $this->section("content"); ?>

<div class="row">
    <div class="col-md-12 col-sm-12 col-xs-12">
        <div class="x_panel">
            <div class="x_title">
                <h3 class="head-title"><i class="fa fa-lock"></i><small> My Profile</small></h3>
                <ul class="nav navbar-right panel_toolbox">
                    <li><a class="collapse-link"><i class="fa fa-chevron-up"></i></a></li>                    
                </ul>
                <div class="clearfix"></div>
            </div>
            
            <div class="x_content quick-link">
                <?php  echo $this->include($path. '/quick-link-profile'); ?>               
            </div>
            
            <div class="x_content">
                <div class="" data-example-id="togglable-tabs">                    
                    <ul  class="nav nav-tabs bordered">
                        <li class="<?php if(isset($profile)){ echo 'active'; }?>"><a href="#tab_profile"   role="tab" data-toggle="tab" aria-expanded="true"><i class="fa fa-eye"></i> Profile</a> </li>
                        <li  class="<?php if(isset($update)){ echo 'active'; }?>"><a href="#tab_update"  role="tab"  data-toggle="tab" aria-expanded="false"><i class="fa fa-pencil-square-o"></i> Update</a> </li>                          
                    </ul>
                    <br/>                    
                    <div class="tab-content">                  

                        <div  class="tab-pane fade in active" id="tab_profile">
                            <div class="x_content">  
                                <div class="col-md-12">
                                    <div class="profile_img">                                        
                                         <?php if($profile->image){ ?>
                                                <img src="<?php echo base_url(UPLOAD_PATH); ?>/user/<?php echo $profile->image; ?>" alt="" width="80" />
                                            <?php }else{ ?>
                                                <img src="<?php echo base_url(IMG_URL); ?>/default.jpg" alt="" width="80" /><br/><br/>
                                            <?php } ?>
                                      </div>
                                  </div>
                                
                                <table id="datatable-responsive" class="table table-striped table-bordered dt-responsive nowrap" cellspacing="0" width="100%">
                                    <tbody>                                        
                                        <tr>
                                            <th width="18%">User Name</th>
                                            <td width="32%"><?php echo $profile->name; ?></td>
                                            <th width="18%">Email</th>
                                            <td width="32%"><?php echo $profile->email; ?></td>
                                        </tr> 
                                        
                                        <tr>
                                            <th width="18%">User Type</th>
                                            <td width="32%"><?php echo $profile->user_type == 1 ? 'Admin' : 'Employee'; ?></td>
                                            <th width="18%">Mobile</th>
                                            <td width="32%"><?php echo $profile->mobile; ?></td>
                                        </tr>
                                        
                                        <tr>
                                            <th width="18%">Address</th>
                                            <td ><?php echo $profile->address; ?></td>
                                            <th width="18%">Last Logged In</th>
                                            <td ><?php echo date('M j, Y H:i:s A', strtotime($profile->last_logged_in)); ?></td>
                                        </tr>                                        
                                    </tbody> 
                                </table> 
                            </div>
                        </div>  

                        <div class="tab-pane fade in" id="tab_update">
                           <div class="x_content"> 
                               
                               <?php 
                                $attributes = ['class' => 'form-horizontal form-label-left', 'id' => 'add', 'name'=>'add'];
                                $action = 'admin/profile/store';
                                echo form_open_multipart(site_url($action), $attributes);
                               ?> 
                               
                            <div class="row">
                                <div class="item form-group">
                                    <label class="control-label col-md-3 col-sm-3 col-xs-12" for="name">Name <span class="required">*</span></label>
                                    <div class="col-md-6 col-sm-6 col-xs-12">
                                        <input  class="form-control col-md-7 col-xs-12"  name="name"  id="name" value="<?php echo isset($profile->name) ?  $profile->name : ''; ?>" placeholder="Name" required="required" type="text">
                                        <div class="help-block"><?php if($validator->getError('name')) { echo  $validator->getError('name'); } ?></div>
                                    </div>
                                </div> 
                              
                                <div class="item form-group">
                                    <label class="control-label col-md-3 col-sm-3 col-xs-12" for="user_type">User Type <span class="required">*</span></label>
                                    <div class="col-md-6 col-sm-6 col-xs-12">
                                        <select  class="form-control col-md-7 col-xs-12"  name="user_type" required="required" id="user_type">
                                            <?php $user_types = get_user_type(); ?>
                                            <option value="">Select user type</option>
                                            <?php  foreach($user_types as $key=>$value){ ?>
                                                <option value="<?php  echo $key; ?>" <?php  if($profile->user_type == $key){ echo 'selected="selected"'; } ?>><?php  echo $value; ?></option>
                                            <?php  } ?>
                                        </select>
                                        <div class="help-block"><?php if($validator->getError('user_type')) { echo  $validator->getError('user_type'); } ?></div>
                                    </div>
                                </div>
                                
                                <div class="item form-group">
                                    <label class="control-label col-md-3 col-sm-3 col-xs-12" for="email">Email</label>
                                    <div class="col-md-6 col-sm-6 col-xs-12">
                                        <input  class="form-control col-md-7 col-xs-12"  name="email"  id="email" value="<?php echo isset($profile->email) ?  $profile->email : ''; ?>" placeholder="Email" type="email"  readonly="readonly">
                                        <div class="help-block"><?php if($validator->getError('email')) { echo  $validator->getError('email'); } ?></div>
                                    </div>
                                </div>
                                
                                <div class="item form-group">
                                    <label class="control-label col-md-3 col-sm-3 col-xs-12" for="mobile">Mobile <span class="required">*</span></label>
                                    <div class="col-md-6 col-sm-6 col-xs-12">
                                        <input  class="form-control col-md-7 col-xs-12"  name="mobile"  id="mobile" value="<?php echo isset($profile->mobile) ?  $profile->mobile : ''; ?>" placeholder="Mobile" required="required" type="number">
                                        <div class="help-block"><?php if($validator->getError('mobile')) { echo  $validator->getError('mobile'); } ?></div>
                                    </div>
                                </div>
                                
                                <div class="item form-group">
                                    <label class="control-label col-md-3 col-sm-3 col-xs-12" for="address">Address</label>
                                    <div class="col-md-6 col-sm-6 col-xs-12">
                                        <input  class="form-control col-md-7 col-xs-12"  name="address"  id="address" value="<?php echo isset($profile->address) ?  $profile->address : ''; ?>" placeholder="Address" type="text">
                                        <div class="help-block"><?php if($validator->getError('address')) { echo  $validator->getError('address'); } ?></div>
                                    </div>
                                </div>
                               
                               </div>
                         
                                <div class="ln_solid"></div>
                                <div class="form-group">
                                    <div class="col-md-6 col-md-offset-3">
                                        <input type="hidden" value="<?php echo isset($profile) ? $profile->id : ''; ?>" name="id" />
                                        <a href="<?php echo site_url('admin/profile'); ?>" class="btn btn-primary">Cancel</a>
                                        <button id="send" type="submit" class="btn btn-success">Update</button>
                                    </div>
                                </div>
                                <?php echo form_close(); ?>
                            </div>
                        </div>                         
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>


<script type="text/javascript">
    $("#profile").validate();  
</script>

<?php echo $this->endSection(); ?>