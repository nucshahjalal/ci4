<?php 

namespace Modules\Admin\Models;
use CodeIgniter\Model;
  
class SliderModel extends Model{

    protected $table = 'sliders';
    protected $primaryKey = 'id';
    
    protected $allowedFields = [
        
        'title',
        'image',
        
        'status',
        'created_at',
        'created_by',
        'modified_at',
        'modified_by'
        
    ];
    
    
    public function get_single_slider($id){
        
        $result = $this->db->table('sliders AS S ')
                ->select('S.* ')
                ->where(['S.id' =>$id])
                ->get()->getRow();
        return $result;
    }
    
}