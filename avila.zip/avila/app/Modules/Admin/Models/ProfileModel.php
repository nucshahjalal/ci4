<?php 

namespace Modules\Admin\Models;
use CodeIgniter\Model;
  
class ProfileModel extends Model{

    protected $table = 'users';
    protected $primaryKey = 'id';
    
    protected $allowedFields = [
        'user_type',
        'name',
        'email',
        'mobile',
        'address',
        'password', 
        'image'
    ];
    
    
}