<?php 

namespace Modules\Admin\Models;
use CodeIgniter\Model;
  
class ProjectModel extends Model{

    protected $table = 'projects';
    protected $primaryKey = 'id';
    
    protected $allowedFields = [
        
        'project_status',
        'project_type',
        'is_featured',
        'name',
        'brochure',
        'latitude',
        'longitude', 
        'address',
        'location',
        'land_amount',
        'approval_no',
        'approval_date',
        'front_view',
        
        'no_of_building',
        'total_floor',
        'total_flat',
        'total_sale',
        'total_available',
        'flat_sft',
        'flat_bed',
        'flat_bath',
        'flat_baranda',
        'flat_bachine',
        'flat_window',
        'flat_dyning',
        'flat_drawing',
        'flat_kitchen',
        'flat_store_room',
        'image',
        'video',
        'note',
        
        'status',
        'created_at',
        'created_by',
        'modified_at',
        'modified_by'
        
    ];
    
    public function get_single_project($id){
        
        $result = $this->db->table('projects AS P ')
                ->select('P.* ')
                ->where(['P.id' =>$id])
                ->get()->getRow();
        return $result;
    }
    
}