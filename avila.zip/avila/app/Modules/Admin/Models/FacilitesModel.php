<?php 

namespace Modules\Admin\Models;
use CodeIgniter\Model;
  
class FacilitesModel extends Model{

    protected $table = 'facilities';
    protected $primaryKey = 'id';
    
    protected $allowedFields = [
        
        'title',
        'image',
        'status',
        'created_at',
        'created_by',
        'modified_at',
        'modified_by'
        
    ];
    
    
    public function get_single_facilities($id){
        
        $result = $this->db->table('facilities AS F ')
                ->select('F.* ')
                ->where(['F.id' =>$id])
                ->get()->getRow();
        return $result;
    }
    
}