<?php 

namespace Modules\Admin\Models;
use CodeIgniter\Model;
  
class ContactModel extends Model{

    protected $table = 'contacts';
    protected $primaryKey = 'id';
    
    protected $allowedFields = [
        
        'name',
        'email',
        'phone',
        'subject',
        'message',
        
        'status',
        'created_at',
        'created_by',
        'modified_at',
        'modified_by'
        
    ];
    
    public function get_single_contact($id){
        
        $result = $this->db->table('contacts AS C ')
                ->select('C.* ')
                ->where(['C.id' =>$id])
                ->get()->getRow();
        return $result;
    }
    
    
}