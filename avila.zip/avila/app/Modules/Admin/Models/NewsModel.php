<?php 

namespace Modules\Admin\Models;
use CodeIgniter\Model;
  
class NewsModel extends Model{

    protected $table = 'news';
    protected $primaryKey = 'id';
    
    protected $allowedFields = [
        
        'title',
        'initial_part',
        'rest_part',
        'image',
        
        'status',
        'created_at',
        'created_by',
        'modified_at',
        'modified_by'
        
    ];
    
    public function get_single_news($id){
        
        $result = $this->db->table('news AS N ')
                ->select('N.* ')
                ->where(['N.id' =>$id])
                ->get()->getRow();
        return $result;
    }
    
}