<?php 

namespace Modules\Admin\Models;
use CodeIgniter\Model;
  
class TestimonialModel extends Model{

    protected $table = 'testimonials';
    protected $primaryKey = 'id';
    
    protected $allowedFields = [
        
        'name',
        'designation',
        'rating',
        'testimonial',
        'image',
        
        'status',
        'created_at',
        'created_by',
        'modified_at',
        'modified_by'
        
    ];
    
    public function get_single_testimonial($id){
        
        $result = $this->db->table('testimonials AS T ')
                ->select('T.* ')
                ->where(['T.id' =>$id])
                ->get()->getRow();
        return $result;
    }
    
}