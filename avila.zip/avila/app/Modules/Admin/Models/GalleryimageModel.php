<?php 

namespace Modules\Admin\Models;
use CodeIgniter\Model;
  
class GalleryimageModel extends Model{

    protected $table = 'gallery_images';
    protected $primaryKey = 'id';
    
    protected $allowedFields = [
        'gallery_id',
        'image',
        'caption',
        'status',
        'created_at',
        'created_by',
        'modified_at',
        'modified_by'
        
    ];
    
    public function get_gallery_image_list(){
        
        $results = $this->db->table('gallery_images AS GI')
                   ->select('GI.*,G.title')
                   ->join('galleries AS G','GI.gallery_id = G.id ', 'left')
                   ->orderBy('id','desc')->get()->getResult();
        return $results;
    }
    
    
    public function get_single_gallery_image($id){
        
        $result = $this->db->table('gallery_images AS GI')
                 ->select('GI.*,G.title')
                 ->join('galleries AS G','GI.gallery_id = G.id ', 'left')
                 ->where(['GI.id' =>$id])
                 ->get()->getRow();
        return $result;
    }
    
}