<?php 

namespace Modules\Admin\Models;
use CodeIgniter\Model;
  
class ProjectimageModel extends Model{

    protected $table = 'project_images';
    protected $primaryKey = 'id';
    
    protected $allowedFields = [
        
        'project_id',
        'image',
        'caption',
        
        'status',
        'created_at',
        'created_by',
        'modified_at',
        'modified_by'
        
    ];
    
     public function get_project_image_list(){
        
        $results = $this->db->table('project_images AS PI ')
                   ->select('PI.*,P.name ')
                   ->join('projects AS P ','PI.project_id = P.id ', 'left')
                  ->orderBy('PI.id','desc')->get()->getResult();
        return $results;
    }
    
    
    public function get_single_project_image($id){
        
       $result = $this->db->table('project_images AS PI ')
                   ->select('PI.*,P.name ')
                   ->join('projects AS P ','PI.project_id = P.id ', 'left')
                  ->where(['PI.id' =>$id])
                  ->get()->getRow();
        return $result;
    }
    
    
}