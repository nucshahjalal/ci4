<?php 

namespace Modules\Admin\Models;
use CodeIgniter\Model;
  
class HeadingModel extends Model{

    protected $table = 'heading';
    protected $primaryKey = 'id';
    
    protected $allowedFields = [
        
        'news_title',
        'news_note',
        'gallery_title',
        'gallery_note',
        'project_title',
        'project_note', 
        
        'progress_title',
        'progress_note',
        'complete_title',
        'complete_note',
        'ongoing_title',
        'ongoing_note',
        
        'upcoming_title',
        'upcoming_note',
        'facility_title',
        'facility_note',
        'contact_title',
        'contact_note',
        
        'status',
        'created_at',
        'created_by',
        'modified_at',
        'modified_by'
        
    ];
    
    
    
}