<?php 

namespace Modules\Admin\Models;
use CodeIgniter\Model;
  
class FloorplanModel extends Model{

    protected $table = 'floor_plan_images';
    protected $primaryKey = 'id';
    
    protected $allowedFields = [
        
        'project_id',
        'image',
        'caption',
        
        'status',
        'created_at',
        'created_by',
        'modified_at',
        'modified_by'
        
    ];
    
    public function get_floorplan_list(){
        
        $results = $this->db->table('floor_plan_images AS fL ')
                   ->select('fL.*,P.name ')
                   ->join('projects AS P ','fL.project_id = P.id ', 'left')
                  ->orderBy('fL.id','desc')->get()->getResult();
        return $results;
    }
    
    
    public function get_single_floorplan($id){
        
        $result = $this->db->table('floor_plan_images AS fL ')
                   ->select('fL.*,P.name ')
                   ->join('projects AS P ','fL.project_id = P.id ', 'left')
                  ->where(['fL.id' =>$id])
                  ->get()->getRow();
        return $result;
    }
    
}