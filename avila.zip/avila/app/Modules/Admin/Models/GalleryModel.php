<?php 

namespace Modules\Admin\Models;
use CodeIgniter\Model;
  
class GalleryModel extends Model{

    protected $table = 'galleries';
    protected $primaryKey = 'id';
    
    protected $allowedFields = [
        
        'title',
        'note',
        
        'status',
        'created_at',
        'created_by',
        'modified_at',
        'modified_by'
        
    ];
    
    public function get_single_gallery($id){
        
        $result = $this->db->table('galleries AS G ')
                ->select('G.* ')
                ->where(['G.id' =>$id])
                ->get()->getRow();
        return $result;
    }
    
}