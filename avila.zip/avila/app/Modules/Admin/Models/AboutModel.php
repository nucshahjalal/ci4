<?php 

namespace Modules\Admin\Models;
use CodeIgniter\Model;
  
class AboutModel extends Model{

    protected $table = 'abouts';
    protected $primaryKey = 'id';
    
    protected $allowedFields = [
        
        'title',
        'description',
        'image',
        'video',
        
        'status',
        'created_at',
        'created_by',
        'modified_at',
        'modified_by'
    ];
    
    
    
}