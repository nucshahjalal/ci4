<?php 

namespace Modules\Admin\Models;
use CodeIgniter\Model;
  
class UserModel extends Model{

    protected $table = 'users';
    protected $primaryKey = 'id';
    
    protected $allowedFields = [
        'user_type',
        'is_default',
        'name',
        'email',
        'mobile',
        'address',
        'password',
        'temp_password',
        'last_logged_in',
        'image' 
    ];
    
    
    protected $validationRules    = [
        'email'        => 'required|valid_email|is_unique[users.email,id,{id}]',
    ];

    protected $validationMessages = [
        'email'        => [
            'is_unique' => 'Sorry. That email has already been taken. Please choose another.',
        ],
    ];
    
    
    public function get_single_user($id){
        
        $result = $this->db->table('users AS U ')
                ->select('U.* ')
                ->where(['U.id' =>$id])
                ->get()->getRow();
        return $result;
    }
    
}