<?php 

namespace Modules\Admin\Models;
use CodeIgniter\Model;
  
class SettingModel extends Model{

    protected $table = 'settings';
    protected $primaryKey = 'id';
    
    protected $allowedFields = [
        
        'email',
        'mobile',
        'phone',
        'skype',
        'fax',
        'name', 
        
        'address',
        'opening_day',
        'opening_time',
        'close_day',
        'currency',
        
        'facebook',
        'twitter',
        'linked_in',
        'youtube',
        'pinterest',
        'instagram',
        'key_note',
        'copy_right',
        'google_map',
        
        'status',
        'created_at',
        'created_by',
        'modified_at',
        'modified_by'
        
    ];
    
    
    
}