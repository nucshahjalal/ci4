<?php

$routes->group("admin", ["namespace" => "\Modules\Admin\Controllers"], function ($routes) {

    // admin 
    $routes->get("/", "Admin::index");
    $routes->post("login", "Admin::login");
    $routes->get("logout", "Admin::logout");
    
    $routes->get("other", "Admin::other"); // extra
    
    // dashboard
    $routes->get("dashboard", "Dashboard::index");
    
    // user
     $routes->get("user", "User::index");
     $routes->get("user/add", "User::add");
     $routes->post("user/add", "User::add");
     $routes->get("user/edit/(:num)", "User::edit/$1");
     $routes->post("user/edit", "User::edit");
     $routes->post("user/edit/(:num)", "User::edit/$1");
     $routes->get("user/delete/(:num)", "User::delete/$1");
     $routes->get("user/view/(:num)", "User::view/$1");
     
    // setting
     $routes->get("setting", "Setting::index");
     $routes->get("setting/add", "Setting::add");
     $routes->post("setting/add", "Setting::add");
     
     // about
     $routes->get("about", "About::index");
     $routes->get("about/add", "About::add");
     $routes->post("about/add", "About::add");
     
     // heading
     $routes->get("heading", "Heading::index");
     $routes->get("heading/add", "Heading::add");
     $routes->post("heading/add", "Heading::add");
     
     // contact
     $routes->get("contact", "Contact::index");     
     $routes->get("contact/add", "Contact::add");
     $routes->post("contact/add", "Contact::add");     
     $routes->get("contact/edit/(:num)", "Contact::edit/$1");
     $routes->post("contact/edit", "Contact::edit");
     $routes->post("contact/edit/(:num)", "Contact::edit/$1");
     $routes->get("contact/delete/(:num)", "Contact::delete/$1");
     $routes->post("contact/view", "Contact::view");
     
     // slider
     $routes->get("slider", "Slider::index");
     $routes->get("slider/add", "Slider::add");
     $routes->post("slider/add", "Slider::add");
     $routes->get("slider/edit/(:num)", "Slider::edit/$1");
     $routes->post("slider/edit", "Slider::edit");
     $routes->post("slider/edit/(:num)", "Slider::edit/$1");
     $routes->get("slider/delete/(:num)", "Slider::delete/$1");
     
     // news
     $routes->get("news", "News::index");
     $routes->get("news/add", "News::add");
     $routes->post("news/add", "News::add");
     $routes->get("news/edit/(:num)", "News::edit/$1");
     $routes->post("news/edit", "News::edit");
     $routes->post("news/edit/(:num)", "News::edit/$1");
     $routes->get("news/delete/(:num)", "News::delete/$1");
     $routes->post("news/view", "News::view");
     
     // testmonial
     $routes->get("testimonial", "Testimonial::index");
     $routes->get("testimonial/add", "Testimonial::add");
     $routes->post("testimonial/add", "Testimonial::add");
     $routes->get("testimonial/edit/(:num)", "Testimonial::edit/$1");
     $routes->post("testimonial/edit", "Testimonial::edit");
     $routes->post("testimonial/edit/(:num)", "Testimonial::edit/$1");
     $routes->get("testimonial/delete/(:num)", "Testimonial::delete/$1");
     $routes->post("testimonial/view", "Testimonial::view");
     
     // facility
     $routes->get("facility", "Facilities::index");
     $routes->get("facility/add", "Facilities::add");
     $routes->post("facility/add", "Facilities::add");
     $routes->get("facility/edit/(:num)", "Facilities::edit/$1");
     $routes->post("facility/edit", "Facilities::edit");
     $routes->post("facility/edit/(:num)", "Facilities::edit/$1");
     $routes->get("facility/delete/(:num)", "Facilities::delete/$1");
     
     // gellery
     $routes->get("gallery", "Gallery::index");
     $routes->get("gallery/add", "Gallery::add");
     $routes->post("gallery/add", "Gallery::add");
     $routes->get("gallery/edit/(:num)", "Gallery::edit/$1");
     $routes->post("gallery/edit", "Gallery::edit");
     $routes->post("gallery/edit/(:num)", "Gallery::edit/$1");
     $routes->get("gallery/delete/(:num)", "Gallery::delete/$1");
     
     // gellery image
     $routes->get("image", "GalleryImage::index");
     $routes->get("image/add", "GalleryImage::add");
     $routes->post("image/add", "GalleryImage::add");
     $routes->get("image/edit/(:num)", "GalleryImage::edit/$1");
     $routes->post("image/edit", "GalleryImage::edit");
     $routes->post("image/edit/(:num)", "GalleryImage::edit/$1");
     $routes->get("image/delete/(:num)", "GalleryImage::delete/$1");
   
    
     // project
     $routes->get("project", "Project::index");
     $routes->get("project/add", "Project::add");
     $routes->post("project/add", "Project::add");
     $routes->get("project/edit/(:num)", "Project::edit/$1");
     $routes->post("project/edit", "Project::edit");
     $routes->post("project/edit/(:num)", "Project::edit/$1");
     $routes->get("project/delete/(:num)", "Project::delete/$1");
     $routes->post("project/view", "Project::view");
     
     // projectimge
     $routes->get("projectimage", "ProjectImage::index");
     $routes->get("projectimage/add", "ProjectImage::add");
     $routes->post("projectimage/add", "ProjectImage::add");
     $routes->get("projectimage/edit/(:num)", "ProjectImage::edit/$1");
     $routes->post("projectimage/edit", "ProjectImage::edit");
     $routes->post("projectimage/edit/(:num)", "ProjectImage::edit/$1");
     $routes->get("projectimage/delete/(:num)", "ProjectImage::delete/$1");
     
     // floorplan
     $routes->get("floorplan", "Floorplan::index");
     $routes->get("floorplan/add", "Floorplan::add");
     $routes->post("floorplan/add", "Floorplan::add");
     $routes->get("floorplan/edit/(:num)", "Floorplan::edit/$1");
     $routes->post("floorplan/edit", "Floorplan::edit");
     $routes->post("floorplan/edit/(:num)", "Floorplan::edit/$1");
     $routes->get("floorplan/delete/(:num)", "Floorplan::delete/$1");
     
      // profile
     $routes->get("profile", "Profile::index");
     $routes->post("profile/store", "Profile::store");
     $routes->get("profile/password", "Profile::password");
     $routes->post("profile/password", "Profile::password");
     
});
