<?php

namespace Modules\Admin\Controllers;

use App\Controllers\AvilaController;
use Modules\Admin\Models\ProfileModel;

class Profile extends AvilaController {

    public $folder = '\Modules\Admin\Views';
    public $model = '';

    public function __construct() {
        
        $this->model = new ProfileModel(); 
        $this->data['path'] = $this->folder;
    }

    public function index() {
        
        $user_id = $this->session->get('id');
        $this->data['profile'] = $this->db->table('users')->where(['status' => 1, 'id'=>$user_id])->get()->getRow();
        return view($this->folder . "/profile/index", $this->data);
    }


    public function store() {

        if ($this->_prepare_profile_validation()) {
            
            $data = $this->_get_posted_profile_data();
            $this->model->save($data);
            if ($this->request->getVar('id')) {
                $this->session->set('success', 'Profile data successfully saved.');
            }else{
                $this->session->set('success', 'Profile data successfully updated.');
            }
            
            return $this->response->redirect(site_url('/admin/profile'));
            
        } else {
            $this->data['profile'] = $this->db->table('users')->where(['status' => 1])->get()->getRow();
            $this->data['post'] = $_POST;
            return view($this->folder . "/profile/profile", $this->data);
        }
    }   
    
    private function _prepare_profile_validation() {

        $rules = [
            
            'name' => 'required',
            'mobile' => 'required',
            'user_type' => 'required'
        ];
        
        $validate = $this->validate($rules);        
        return $validate;        
    }
    
    private function _get_posted_profile_data() {

        $data = array();

        $data['user_type'] = $this->request->getVar('user_type');
        $data['name'] = $this->request->getVar('name');
        $data['mobile'] = $this->request->getVar('mobile');
        $data['address'] = $this->request->getVar('address');
        $data['modified_at'] = date('Y-m-d H:i:s');
        $data['modified_by'] = logged_in_user_id();

        if ($this->request->getVar('id')) {
            
            $data['id'] = $this->request->getVar('id');
            
        } else {
            
            $data['status'] = 1;
            $data['created_at'] = date('Y-m-d H:i:s');
            $data['created_by'] = logged_in_user_id();
            
        }
        
        return $data;
    }   
    
    
    public function password(){
        
        if($_POST){
            
            if ($this->_prepare_password_validation()) {
                $password = md5($this->request->getVar('password'));
                $temp_password = base64_encode($this->request->getVar('password'));
                $user_id = $this->session->get('id');
                $this->db->table('users')->set(['password'=> $password, 'temp_password'=>$temp_password])->where('id', $user_id)->update();
                $this->session->set('success', 'You have successfully reset password.');  
                return redirect()->to('/admin/dashboard');
            
            }
        }
                
        $this->data['list'] = TRUE;
        return view($this->folder . "/profile/password", $this->data);
    }
    
     private function _prepare_password_validation() {

        $rules = [
            
            'password' => 'required|numeric|min_length[6]|max_length[12]',
            'confirm_password' => 'required|numeric|min_length[6]|max_length[12]',
        ];
        
        $validate = $this->validate($rules);        
        return $validate;        
    }
    
}
