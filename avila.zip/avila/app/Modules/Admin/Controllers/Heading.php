<?php

namespace Modules\Admin\Controllers;

use App\Controllers\AvilaController;
use Modules\Admin\Models\HeadingModel;

class Heading extends AvilaController {

    public $folder = '\Modules\Admin\Views';
    public $model = '';

    public function __construct() {
        
        parent::__construct();
        $this->model = new HeadingModel();
        $this->data['path'] = $this->folder;
    }

    public function index() {

        $this->data['heading'] = $this->db->table('heading')->where(['status' => 1])->get()->getRow();
        $this->data['list'] = TRUE;
        return view($this->folder . "\heading\index", $this->data);
    }

    public function add() {

        if ($this->_prepare_heading_validation()) {

            $data = $this->_get_posted_heading_data();
            $this->model->save($data);

            if ($this->request->getVar('id')) {
                $this->session->set('success', 'Heading data successfully saved.');
            } else {
                $this->session->set('success', 'Heading data successfully updated.');
            }
            return $this->response->redirect(site_url('admin/heading'));
            
        } else {
            
            $this->data['post'] = $_POST;
            $this->data['add'] = TRUE;
            return view($this->folder . "/heading/index", $this->data);
        }
    }


    
    private function _prepare_heading_validation() {

        $rules = [
            
             "news_title" => ["label" => "News title", "rules" => "required"],
             "gallery_title" => ["label" => "Gallery title", "rules" => "required"],
             "project_title" => ["label" => "Project title", "rules" => "required"],
             "progress_title" => ["label" => "Progress title", "rules" => "required"],
             "complete_title" => ["label" => "Complete title", "rules" => "required"],
             "ongoing_title" => ["label" => "Ongoing title", "rules" => "required"],
             "upcoming_title" => ["label" => "Upcoming title", "rules" => "required"],
             "contact_title" => ["label" => "Contact title", "rules" => "required"],
            
        ];

        $validate = $this->validate($rules);
        return $validate;
    }

    
    private function _get_posted_heading_data() {

        $data = array();

        $data['news_title'] = $this->request->getVar('news_title');
        $data['news_note'] = $this->request->getVar('news_note');
        $data['gallery_title'] = $this->request->getVar('gallery_title');
        $data['gallery_note'] = $this->request->getVar('gallery_note');
        $data['project_title'] = $this->request->getVar('project_title');
        
        $data['project_note'] = $this->request->getVar('project_note');
        $data['progress_title'] = $this->request->getVar('progress_title');
        $data['progress_note'] = $this->request->getVar('progress_note');
        $data['complete_title'] = $this->request->getVar('complete_title');
        $data['complete_note'] = $this->request->getVar('complete_note');
        
        $data['ongoing_title'] = $this->request->getVar('ongoing_title');
        $data['ongoing_note'] = $this->request->getVar('ongoing_note');
        $data['upcoming_title'] = $this->request->getVar('upcoming_title');
        $data['upcoming_note'] = $this->request->getVar('upcoming_note');
        $data['facility_title'] = $this->request->getVar('facility_title');
        $data['facility_note'] = $this->request->getVar('facility_note');
        $data['contact_title'] = $this->request->getVar('contact_title');
        $data['contact_note'] = $this->request->getVar('contact_note');
        $data['modified_at'] = date('Y-m-d H:i:s');
        $data['modified_by'] = logged_in_user_id();

        if ($this->request->getVar('id')) {
            
            $data['id'] = $this->request->getVar('id');
            
        } else {
            
            $data['status'] = 1;
            $data['created_at'] = date('Y-m-d H:i:s');
            $data['created_by'] = logged_in_user_id();
        }
      
        return $data;
    }

}
