<?php

namespace Modules\Admin\Controllers;

use App\Controllers\AvilaController;
use Modules\Admin\Models\TestimonialModel;

class Testimonial extends AvilaController {

    public $folder = '\Modules\Admin\Views';
    public $model = '';

    public function __construct() {
        
        $this->model = new TestimonialModel();
    }

    public function index() {
        
        $this->data['testimonials'] = $this->db->table('testimonials')->orderBy('id','desc')->get()->getResult();
        $this->data['list'] = TRUE;
        return view($this->folder . "/testimonial/index", $this->data);
    }


    public function add() {

        if ($_POST && $this->_prepare_testimonial_validation()) {

            $data = $this->_get_posted_testimonial_data();
            if($this->model->insert($data)){
                $this->session->set('success', 'Testimonial data successfully saved.');
                return $this->response->redirect(site_url('/admin/testimonial'));
            
            } else {
                $this->session->set('error', 'Testimonial data insert failed.');
            }
        }
        
        $this->data['post'] = $_POST;
        $this->data['add'] = TRUE;
        return view($this->folder . "/testimonial/index", $this->data);
    }

    
    public function  edit($id = null) {

        if ($_POST && $this->_prepare_testimonial_validation()) {

            $data = $this->_get_posted_testimonial_data();
                        
            if($this->model->save($data)){
                $this->session->set('success', 'Testimonial data successfully updated.');
                return $this->response->redirect(site_url('/admin/testimonial'));
            
            } else {
                $this->session->set('error', 'Testimonial data  updated failed.');
                return $this->response->redirect(site_url('admin/testimonial/edit/' . $data['id']));
            }
        }
        
        $this->data['testimonial'] = $this->model->get_single_testimonial($id);
        $this->data['post'] = $_POST;
        $this->data['edit'] = TRUE;            
        return view($this->folder . "/testimonial/index", $this->data);
    }
    

    public function view() {
        
        $testi_id = $this->request->getVar('testi_id');
        $this->data['testimonial'] = $this->model->get_single_testimonial($testi_id);
        return view($this->folder . "/testimonial/get-single-testimonial", $this->data);
    }
    
    private function _prepare_testimonial_validation() {

        $rules = [
            
            'name' => 'required',
            'rating' => 'required|numeric|min_length[1]|max_length[1]',
            'testimonial' => ["label" => "Testimonial", "rules" => "required"]
        ];
        
        if (!$this->request->getVar('id')) {
            $rules['image'] = ["label" => "Testimonial photo", "rules" => "required"];
        }
                                        
        if ($this->request->getFile("image")->getName()) {
            $rules['image'] = 'uploaded[image]|is_image[image]|mime_in[image,image/png,image/jpg,image/jpeg,image/pjpeg,image/x-png,image/gif]|ext_in[image,png,jpg,gif,jpeg,pjpeg]';
        }
        
        $validate = $this->validate($rules);
        return $validate;
    }

    
    private function _get_posted_testimonial_data() {

        $data = array();

        $data['name'] = $this->request->getVar('name');
        $data['designation'] = $this->request->getVar('designation');
        $data['rating'] = $this->request->getVar('rating');
        $data['testimonial'] = $this->request->getVar('testimonial');
        $data['modified_at'] = date('Y-m-d H:i:s');
        $data['modified_by'] = logged_in_user_id();
            
        if ($this->request->getVar('id')) {
            
            $data['status'] = $this->request->getVar('status');
            $data['id'] = $this->request->getVar('id');
            
        } else {
            
            $data['status'] = 1;           
            $data['created_at'] = date('Y-m-d H:i:s');
            $data['created_by'] = logged_in_user_id();
        }
        
        $data['image'] = $this->__upload_image();
        return $data;
    }
    
    public function delete($id) {
        
        $testimonial = $this->db->table('testimonials')->where(['id' => $id])->get()->getRow();
        
        if($this->model->delete($id)){
        
            // process delete image
            $destination = UPLOAD_PATH.'testimonial/'; 
            if (file_exists($destination . $testimonial->image)) {
                @unlink($destination . $testimonial->image);
            }
        
            $this->session->set('success', 'Testimonial data deleted successfully.');
            
        }else{
            
            $this->session->set('error', 'Testimonial data deleted failed. Please try again.');  
            
        }
        
        return $this->response->redirect(site_url('/admin/testimonial'));
    }
    
    private function __upload_image(){
        
        $file = $this->request->getFile("image");
        $image_upload = $file->getBasename();
        $prev_image = $this->request->getVar('image_prev');
        $return_iamge = '';
        
        if($image_upload){
            
            $ext = $file->guessExtension();        
            $destination = UPLOAD_PATH.'testimonial/'; 
            $image_name = 'testimonial-'.time() . '-shdl.' . $ext;

             if ($file->move($destination, $image_name)) {     
                 
                $return_iamge = $image_name;
                
                // need to unlink previous image
                if ($prev_image != "") {
                    if (file_exists($destination . $prev_image)) {
                        @unlink($destination . $prev_image);
                    }
                }
             } 
             
        }else{ 
            
             $return_iamge = $prev_image;
        }
         
        return $return_iamge;
    }
    
}
