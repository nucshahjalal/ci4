<?php

namespace Modules\Admin\Controllers;

use App\Controllers\AvilaController;
use Modules\Admin\Models\GalleryModel;

class Gallery extends AvilaController {

    public $folder = '\Modules\Admin\Views';
    public $model = '';

    public function __construct() {
        
        $this->model = new GalleryModel();
        $this->data['path'] = $this->folder;
    }

    public function index() {

        $this->data['galleries'] = $this->db->table('galleries')->orderBy('id','desc')->get()->getResult();
        $this->data['list'] = TRUE;
        return view($this->folder . "\gallery\index", $this->data);
    }


    public function add() {

        if ($_POST && $this->_prepare_gallery_validation()) {

            $data = $this->_get_posted_gallery_data();
            if($this->model->insert($data)){
                $this->session->set('success', 'Gallery data successfully saved.');
                return $this->response->redirect(site_url('/admin/gallery'));
            } else {
                $this->session->set('error', 'Gallery data insert failed.');
            }
        }
        
        $this->data['post'] = $_POST;
        $this->data['add'] = TRUE;
        return view($this->folder . "\gallery\index", $this->data);
    }

    
    public function edit($id = null) {

        if ($_POST && $this->_prepare_gallery_validation()) {

            $data = $this->_get_posted_gallery_data();
                        
            if($this->model->save($data)){
               $this->session->set('success', 'Gallery data successfully updated.');
               return $this->response->redirect(site_url('/admin/gallery'));
            } else {
                $this->session->set('error', 'Gallery data  updated failed.');
                return $this->response->redirect(site_url('admin/gallery/edit/' . $data['id']));
            }
        }
        
        $this->data['gallery'] = $this->model->get_single_gallery($id);
        $this->data['post'] = $_POST;
        $this->data['edit'] = TRUE;            
        return view($this->folder . "\gallery\index", $this->data);
    }

    
    private function _prepare_gallery_validation() {

        $rules = [
            
            'title' => 'required'
        ];


        $validate = $this->validate($rules);
        return $validate;
    }

    
    private function _get_posted_gallery_data() {

        $data = array();

        $data['title'] = $this->request->getVar('title');
        $data['note'] = $this->request->getVar('note');
        $data['modified_at'] = date('Y-m-d H:i:s');
        $data['modified_by'] = logged_in_user_id();
            
        if ($this->request->getVar('id')) {
            
            $data['status'] = $this->request->getVar('status');
            $data['id'] = $this->request->getVar('id');
            
        } else {
            
            $data['status'] = 1;           
            $data['created_at'] = date('Y-m-d H:i:s');
            $data['created_by'] = logged_in_user_id();
        }

        return $data;
    }
    
    public function delete($id) {
        
       if ($this->model->delete($id)) {
            $this->session->set('success', 'Gallery data  successfully deleted.');
        } else {
            $this->session->set('error', 'Gallery data deleted failed.');
        }

        return $this->response->redirect(site_url('admin/gallery'));
    }
    
}
