<?php

namespace Modules\Admin\Controllers;

use App\Controllers\AvilaController;
use Modules\Admin\Models\NewsModel;

class News extends AvilaController {

    public $folder = '\Modules\Admin\Views';
    public $model = '';

    public function __construct() {
        
        $this->model = new NewsModel();
    }

    public function index() {
        
        $this->data['newses'] = $this->db->table('news')->orderBy('id','desc')->get()->getResult();
        $this->data['list'] = TRUE;
        return view($this->folder . "/news/index", $this->data);
    }


    public function add() {

        if ($this->_prepare_news_validation()) {

            $data = $this->_get_posted_news_data();
            if($this->model->insert($data)){
               $this->session->set('success', 'News data successfully saved.');
               return $this->response->redirect(site_url('/admin/news'));
            
            } else {
                $this->session->set('error', 'News data insert failed.');
            }
        }
        
        $this->data['post'] = $_POST;
        $this->data['add'] = TRUE;
        return view($this->folder . "/news/index", $this->data);
    }

    
    public function edit($id = null) {

        if ($_POST && $this->_prepare_news_validation()) {

            $data = $this->_get_posted_news_data();
                        
            if($this->model->save($data)){
                $this->session->set('success', 'News data successfully updated.');
                return $this->response->redirect(site_url('/admin/news'));
            } else {
                $this->session->set('error', 'News data  updated failed.');
                return $this->response->redirect(site_url('admin/news/edit/' . $data['id']));
            }
        }
        
        $this->data['news'] = $this->model->get_single_news($id);
        $this->data['post'] = $_POST;
        $this->data['edit'] = TRUE;            
        return view($this->folder . "/news/index", $this->data);
    }

    public function view() {
        
        $news_id = $this->request->getVar('news_id');
        $this->data['newses'] = $this->model->get_single_news($news_id);
        return view($this->folder . "/news/get-single-news", $this->data);
    }
    
    private function _prepare_news_validation() {

        $rules = [
            
            'title' => 'required|is_unique[news.title,id,{id}]',
            "initial_part" => ["label" => "Initial part", "rules" => "required"]
        ];

        $validate = $this->validate($rules);
        return $validate;
    }

    
    private function _get_posted_news_data() {

        $data = array();

        $data['title'] = $this->request->getVar('title');
        $data['initial_part'] = $this->request->getVar('initial_part');
        $data['rest_part'] = $this->request->getVar('rest_part');
        $data['image'] = $this->request->getVar('image');
        $data['modified_at'] = date('Y-m-d H:i:s');
        $data['modified_by'] = logged_in_user_id();
            
        if ($this->request->getVar('id')) {
            
            $data['status'] = $this->request->getVar('status');
            $data['id'] = $this->request->getVar('id');
            
        } else {
            
            $data['status'] = 1;           
            $data['created_at'] = date('Y-m-d H:i:s');
            $data['created_by'] = logged_in_user_id();
        }
        
        $data['image'] = $this->__upload_image();
        return $data;
    }
    
    public function delete($id) {
        
        $news = $this->db->table('news')->where(['id' => $id])->get()->getRow();
        
        if($this->model->delete($id)){
        
            // process delete image
            $destination = UPLOAD_PATH.'news/'; 
            if (file_exists($destination . $news->image)) {
                @unlink($destination . $news->image);
            }
        
            $this->session->set('success', 'News data deleted successfully.');
            
        }else{
            
            $this->session->set('error', 'News data deleted failed. Please try again.');  
        }
        
        return $this->response->redirect(site_url('/admin/news'));
    }
    
    
    private function __upload_image(){
        
        $file = $this->request->getFile("image");
        $image_upload = $file->getBasename();
        $prev_image = $this->request->getVar('image_prev');
        $return_iamge = '';
        
        if($image_upload){
            
            $ext = $file->guessExtension();        
            $destination = UPLOAD_PATH.'news/'; 
            $image_name = 'news-'.time() . '-shdl.' . $ext;

             if ($file->move($destination, $image_name)) {     
                 
                $return_iamge = $image_name;
                
                // need to unlink previous image
                if ($prev_image != "") {
                    if (file_exists($destination . $prev_image)) {
                        @unlink($destination . $prev_image);
                    }
                }
             } 
             
        }else{ 
            
             $return_iamge = $prev_image;
        }
         
        return $return_iamge;
    }
    
    
}
