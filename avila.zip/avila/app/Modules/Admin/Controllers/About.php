<?php

namespace Modules\Admin\Controllers;

use App\Controllers\AvilaController;
use Modules\Admin\Models\AboutModel;

class About extends AvilaController {

    public $folder = '\Modules\Admin\Views';
    public $model = '';

    public function __construct() {
        
        parent::__construct();
        $this->model = new AboutModel();  
        $this->data['path'] = $this->folder;
    }

    public function index() {
        
        $this->data['about'] = $this->db->table('abouts')->where(['status' => 1])->get()->getRow();
        $this->data['list'] = TRUE;
        return view($this->folder . "\about\index", $this->data);
    }


    public function add() {

       if ($this->_prepare_about_validation()) {

            $data = $this->_get_posted_about_data();
            $this->model->save($data);

            if ($this->request->getVar('id')) {
                $this->session->set('success', 'About data successfully saved.');
            } else {
                $this->session->set('success', 'About data successfully updated.');
            }
            return $this->response->redirect(site_url('admin/about'));
        } else {
            $this->data['post'] = $_POST;
            $this->data['add'] = TRUE;
            return view($this->folder . "/about/index", $this->data);
        }
    }

    
    
    private function _prepare_about_validation() {

        $rules = [
            
            'title' => 'required',
            'description' => 'required',
        ];
      
        
        if ($this->request->getFile("image")->getName()) {
            $rules['image'] = 'uploaded[image]|is_image[image]|mime_in[image,image/png,image/jpg,image/jpeg,image/pjpeg,image/x-png,image/gif]|ext_in[image,png,jpg,gif,jpeg,pjpeg]';
        }

        $validate = $this->validate($rules);        
        return $validate;
        
    }

    
    private function _get_posted_about_data() {

        $data = array();

        $data['title'] = $this->request->getVar('title');
        $data['description'] = $this->request->getVar('description');
        $data['video'] = $this->request->getVar('video');
        $data['modified_at'] = date('Y-m-d H:i:s');
        $data['modified_by'] = logged_in_user_id();

        if ($this->request->getVar('id')) {
            
            $data['id'] = $this->request->getVar('id');
            
        } else {
            
            $data['status'] = 1;
            $data['created_at'] = date('Y-m-d H:i:s');
            $data['created_by'] = logged_in_user_id();
            
        }

        $data['image'] = $this->__upload_image();
        
        return $data;
    }
    
    private function __upload_image(){
        
        $file = $this->request->getFile("image");
        $image_upload = $file->getBasename();
        $prev_image = $this->request->getVar('image_prev');
        $return_iamge = '';
        
        if($image_upload){
            
            $ext = $file->guessExtension();        
            $destination = UPLOAD_PATH.'about/'; 
            $image_name = 'about-'.time() . '-shdl.' . $ext;

             if ($file->move($destination, $image_name)) {     
                 
                $return_iamge = $image_name;
                
                // need to unlink previous image
                if ($prev_image != "") {
                    if (file_exists($destination . $prev_image)) {
                        @unlink($destination . $prev_image);
                    }
                }
             } 
             
        }else{ 
            
             $return_iamge = $prev_image;
        }
         
        return $return_iamge;
    }

}
