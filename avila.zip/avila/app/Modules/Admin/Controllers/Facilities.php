<?php

namespace Modules\Admin\Controllers;

use App\Controllers\AvilaController;
use Modules\Admin\Models\FacilitesModel;

class Facilities extends AvilaController {

    public $folder = '\Modules\Admin\Views';
    public $model = '';

    public function __construct() {
        
        $this->model = new FacilitesModel();
    }

    public function index() {

        $this->data['facilities'] = $this->db->table('facilities')->orderBy('id','desc')->get()->getResult();
        $this->data['list'] = TRUE;
        return view($this->folder . "/facility/index", $this->data);
    }


    public function add() {

        if ($_POST && $this->_prepare_facility_validation()) {

            $data = $this->_get_posted_facility_data();
            if($this->model->insert($data)){
                $this->session->set('success', 'Facility data successfully saved.');
                return $this->response->redirect(site_url('/admin/facility'));
            
            } else {
                $this->session->set('error', 'Facility data insert failed.');
            }
        }
        
        $this->data['post'] = $_POST;
        $this->data['add'] = TRUE;
        return view($this->folder . "/facility/index", $this->data);
    }

    
    public function edit($id = null) {

        if ($_POST && $this->_prepare_facility_validation()) {

            $data = $this->_get_posted_facility_data();
                        
        if($this->model->save($data)){
            $this->session->set('success', 'Facility data successfully updated.');
            return $this->response->redirect(site_url('/admin/facility'));
            
            } else {
                $this->session->set('error', 'Facility data  updated failed.');
                return $this->response->redirect(site_url('admin/facility/edit/' . $data['id']));
            }
        }
        
        $this->data['facility'] = $this->model->get_single_facilities($id);
        $this->data['post'] = $_POST;
        $this->data['edit'] = TRUE;            
        return view($this->folder . "/facility/index", $this->data);
        
    }

    
    private function _prepare_facility_validation() {

        $rules = [
            
            'title' => 'required'
        ];
        
        if (!$this->request->getVar('id')) {
            $rules['image'] = ["label" => "Facilites image", "rules" => "required"];
        }
        
        if ($this->request->getFile("image")->getName()) {
            $rules['image'] = 'uploaded[image]|is_image[image]|mime_in[image,image/png,image/jpg,image/jpeg,image/pjpeg,image/x-png,image/gif]|ext_in[image,png,jpg,gif,jpeg,pjpeg]';
        }

        $validate = $this->validate($rules);
        return $validate;
    }

    
    private function _get_posted_facility_data() {

        $data = array();

        $data['title'] = $this->request->getVar('title');
        $data['modified_at'] = date('Y-m-d H:i:s');
        $data['modified_by'] = logged_in_user_id();
            
        if ($this->request->getVar('id')) {
            
            $data['status'] = $this->request->getVar('status');
            $data['id'] = $this->request->getVar('id');
            
        } else {
            
            $data['status'] = 1;           
            $data['created_at'] = date('Y-m-d H:i:s');
            $data['created_by'] = logged_in_user_id();
            
        }
        
        $data['image'] = $this->__upload_image();
        return $data;
    }
    
    public function delete($id) {
        
        $facility = $this->db->table('facilities')->where(['id' => $id])->get()->getRow();
        
        if($this->model->delete($id)){
        
            // process delete image
            $destination = UPLOAD_PATH.'facility/'; 
            if (file_exists($destination . $facility->image)) {
                @unlink($destination . $facility->image);
            }
        
            $this->session->set('success', 'Facility data deleted successfully.');
            
        }else{
            
            $this->session->set('error', 'Facility data deleted failed. Please try again.');  
            
        }
        
        return $this->response->redirect(site_url('/admin/facility'));
    }
    
    private function __upload_image(){
        
        $file = $this->request->getFile("image");
        $image_upload = $file->getBasename();
        $prev_image = $this->request->getVar('image_prev');
        $return_iamge = '';
        
        if($image_upload){
            
            $ext = $file->guessExtension();        
            $destination = UPLOAD_PATH.'facility/'; 
            $image_name = 'facility-'.time() . '-shdl.' . $ext;

             if ($file->move($destination, $image_name)) {     
                 
                $return_iamge = $image_name;
                
                // need to unlink previous image
                if ($prev_image != "") {
                    if (file_exists($destination . $prev_image)) {
                        @unlink($destination . $prev_image);
                    }
                }
             } 
             
        }else{ 
            
             $return_iamge = $prev_image;
        }
         
        return $return_iamge;
    }
}
