<?php

namespace Modules\Admin\Controllers;

use App\Controllers\AvilaController;
use Modules\Admin\Models\FloorplanModel;

class Floorplan extends AvilaController {

    public $folder = '\Modules\Admin\Views';
    public $model = '';

    public function __construct() {
        
        $this->model = new FloorplanModel();
        $this->data['path'] = $this->folder;
    }

    public function index() {

        $this->data['floorplans'] = $this->model->get_floorplan_list();
        $this->data['projects'] = $this->db->table('projects')->where(['status'=>1])->get()->getResult();
        $this->data['list'] = TRUE;
        return view($this->folder . "/floorplan/index", $this->data);
    }

    public function add() {
        
        if ($_POST && $this->_prepare_floorplan_validation()) {

            $data = $this->_get_posted_floorplan_data();
            if($this->model->insert($data)){
                $this->session->set('success', 'Floor plan data successfully saved.');
                 return $this->response->redirect(site_url('/admin/floorplan'));
            
            } else {
                $this->session->set('error', 'Floor plan data insert failed.');
            }
        }
        
        $this->data['post'] = $_POST;
        $this->data['add'] = TRUE;
        return view($this->folder . "/floorplan/index", $this->data);
    }

    
    public function edit($id = null) {
        
        if ($_POST && $this->_prepare_floorplan_validation()) {
            $data = $this->_get_posted_floorplan_data();
                        
            if($this->model->save($data)){
                $this->session->set('success', 'Floor plan data successfully updated.');
                return $this->response->redirect(site_url('/admin/floorplan'));
            
            } else {
                $this->session->set('error', 'Floor plan data  updated failed.');
                return $this->response->redirect(site_url('admin/floorplan/edit/' . $data['id']));
            }
        }
        
        $this->data['projects'] = $this->db->table('projects')->where(['status'=>1])->get()->getResult();
        $this->data['floorplan'] = $this->model->get_single_floorplan($id);
        $this->data['post'] = $_POST;
        $this->data['edit'] = TRUE;            
        return view($this->folder . "/floorplan/index", $this->data);
    }

    
    private function _prepare_floorplan_validation() {

        $rules = [
             "project_id" => ["label" => "Project Name", "rules" => "required"],
        ];

        if (!$this->request->getVar('id')) {
            $rules['image'] = ["label" => "Floor plan image", "rules" => "required"];
        }
        
        if ($this->request->getFile("image")->getName()) {
            $rules['image'] = 'uploaded[image]|is_image[image]|mime_in[image,image/png,image/jpg,image/jpeg,image/pjpeg,image/x-png,image/gif]|ext_in[image,png,jpg,gif,jpeg,pjpeg]';
        }

        $validate = $this->validate($rules);
        return $validate;
    }

    
    private function _get_posted_floorplan_data() {

        $data = array();

        $data['project_id'] = $this->request->getVar('project_id');
        $data['caption'] = $this->request->getVar('caption');
        $data['modified_at'] = date('Y-m-d H:i:s');
        $data['modified_by'] = logged_in_user_id();

        if ($this->request->getVar('id')) {
            
            $data['status'] = $this->request->getVar('status');
            $data['id'] = $this->request->getVar('id');
            
        } else {
            
            $data['status'] = 1;           
            $data['created_at'] = date('Y-m-d H:i:s');
            $data['created_by'] = logged_in_user_id();
        }

        $data['image'] = $this->__upload_image();
        return $data;
    }
    
    public function delete($id) {
        
        $image = $this->db->table('floor_plan_images')->where(['id' => $id])->get()->getRow();
        
        if($this->model->delete($id)){
        
            // process delete image
            $destination = UPLOAD_PATH.'project-image/'; 
            if (file_exists($destination . $image->image)) {
                @unlink($destination . $image->image);
            }
        
            $this->session->set('success', 'Floor plan data deleted successfully.');
            
        }else{
            
            $this->session->set('error', 'Floor plan data deleted failed. Please try again.');  
            
        }
        
        return $this->response->redirect(site_url('/admin/floorplan'));
    }
    
    private function __upload_image(){
        
        $file = $this->request->getFile("image");
        $image_upload = $file->getBasename();
        $prev_image = $this->request->getVar('image_prev');
        $return_iamge = '';
        
        if($image_upload){
            
            $ext = $file->guessExtension();        
            $destination = UPLOAD_PATH.'floorplan/'; 
            $image_name = 'floorplan-'.time() . '-shdl.' . $ext;

             if ($file->move($destination, $image_name)) {     
                 
                $return_iamge = $image_name;
                
                // need to unlink previous image
                if ($prev_image != "") {
                    if (file_exists($destination . $prev_image)) {
                        @unlink($destination . $prev_image);
                    }
                }
             } 
             
        }else{ 
            
             $return_iamge = $prev_image;
        }
         
        return $return_iamge;
    }
    
}
