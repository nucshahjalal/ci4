<?php

namespace Modules\Admin\Controllers;

use App\Controllers\AvilaController;
use Modules\Admin\Models\ProjectimageModel;

class ProjectImage extends AvilaController {

    public $folder = '\Modules\Admin\Views';
    public $model = '';

    public function __construct() {
        
        $this->model = new ProjectimageModel();
        $this->data['path'] = $this->folder;
    }

    public function index() {

        $this->data['imageprojects'] = $this->model->get_project_image_list();
        $this->data['projects'] = $this->db->table('projects')->where(['status'=>1])->get()->getResult();
        $this->data['list'] = TRUE;
        return view($this->folder . "/projectimage/index", $this->data);
    }


    public function add() {
        
        if ($_POST &&  $this->_prepare_projectimage_validation()) {

            $data = $this->_get_posted_projectimage_data();
            if($this->model->insert($data)){
                $this->session->set('success', 'Project image data successfully saved.');
                return $this->response->redirect(site_url('/admin/projectimage'));
                
            } else {
                $this->session->set('error', 'Project data insert failed.');
            }
        }
        
        $this->data['post'] = $_POST;
        $this->data['add'] = TRUE;
        return view($this->folder . "/projectimage/index", $this->data);
    }

    
    public function  edit($id = null) {
        
        if ( $_POST &&  $this->_prepare_projectimage_validation()) {
            $data = $this->_get_posted_projectimage_data();
            if($this->model->save($data)){
                $this->session->set('success', 'Project image data successfully updated.');
                return $this->response->redirect(site_url('/admin/projectimage'));
            
            } else {
                $this->session->set('error', 'Project data  updated failed.');
                return $this->response->redirect(site_url('admin/projectimage/edit/' . $data['id']));
            }
        }
        
        $this->data['projectimage'] = $this->model->get_single_project_image($id);
        $this->data['projects'] = $this->db->table('projects')->where(['status'=>1])->get()->getResult();
        $this->data['post'] = $_POST;
        $this->data['edit'] = TRUE;            
        return view($this->folder . "/projectimage/index", $this->data);
    }

    
    private function _prepare_projectimage_validation() {

        $rules = [
            
             "project_id" => ["label" => "Project Name", "rules" => "required"],
        ];

        if (!$this->request->getVar('id')) {
            $rules['image'] = ["label" => "Project Image", "rules" => "required"];
        }
        
        if ($this->request->getFile("image")->getName()) {
            $rules['image'] = 'uploaded[image]|is_image[image]|mime_in[image,image/png,image/jpg,image/jpeg,image/pjpeg,image/x-png,image/gif]|ext_in[image,png,jpg,gif,jpeg,pjpeg]';
        }

        $validate = $this->validate($rules);
        return $validate;
    }

    
    private function _get_posted_projectimage_data() {

        $data = array();

        $data['project_id'] = $this->request->getVar('project_id');
        $data['caption'] = $this->request->getVar('caption');
        $data['modified_at'] = date('Y-m-d H:i:s');
        $data['modified_by'] = logged_in_user_id();
            
        if ($this->request->getVar('id')) {
            
            $data['status'] = $this->request->getVar('status');
            $data['id'] = $this->request->getVar('id');
            
        } else {
            
            $data['status'] = 1;           
            $data['created_at'] = date('Y-m-d H:i:s');
            $data['created_by'] = logged_in_user_id();
        }

        $data['image'] = $this->__upload_image();
        return $data;
    }
    
    public function delete($id) {
        
        $image = $this->db->table('project_images')->where(['id' => $id])->get()->getRow();
        
        if($this->model->delete($id)){
        
            // process delete image
            $destination = UPLOAD_PATH.'project-image/'; 
            if (file_exists($destination . $image->image)) {
                @unlink($destination . $image->image);
            }
        
            $this->session->set('success', 'Project image data deleted successfully.');
            
        }else{
            
            $this->session->set('error', 'Project image data deleted failed. Please try again.');  
            
        }
        
        return $this->response->redirect(site_url('/admin/projectimage'));
    }
    
    
    private function __upload_image(){
        
        $file = $this->request->getFile("image");
        $image_upload = $file->getBasename();
        $prev_image = $this->request->getVar('image_prev');
        $return_iamge = '';
        
        if($image_upload){
            
            $ext = $file->guessExtension();        
            $destination = UPLOAD_PATH.'project-image/'; 
            $image_name = 'project-image-'.time() . '-shdl.' . $ext;

             if ($file->move($destination, $image_name)) {     
                 
                $return_iamge = $image_name;
                
                // need to unlink previous image
                if ($prev_image != "") {
                    if (file_exists($destination . $prev_image)) {
                        @unlink($destination . $prev_image);
                    }
                }
             } 
             
        }else{ 
            
             $return_iamge = $prev_image;
        }
         
        return $return_iamge;
    }
    
    
}
