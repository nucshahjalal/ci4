<?php

namespace Modules\Admin\Controllers;

use App\Controllers\AvilaController;
use Modules\Admin\Models\GalleryimageModel;

class GalleryImage extends AvilaController {

    public $folder = '\Modules\Admin\Views';
    public $model = '';

    public function __construct() {
        
        $this->model = new GalleryimageModel();
        $this->data['path'] = $this->folder;
    }

    public function index() {

        $this->data['images'] = $this->model->get_gallery_image_list();
        $this->data['galleries'] = $this->db->table('galleries')->where(['status'=>1])->get()->getResult();
        $this->data['list'] = TRUE;
        return view($this->folder . "/image/index", $this->data);
    }


    public function add() {
        
        if ($_POST && $this->_prepare_image_validation()) {

            $data = $this->_get_posted_image_data();
            if($this->model->insert($data)){
                $this->session->set('success', 'Image data successfully saved.');
                return $this->response->redirect(site_url('/admin/image'));
            } else {
                $this->session->set('error', 'Image data insert failed.');
            }
        }
        
        $this->data['post'] = $_POST;
        $this->data['add'] = TRUE;
        return view($this->folder . "/image/index", $this->data);
    }

    
    public function edit($id = null) {
        
        if ($_POST && $this->_prepare_image_validation()) {
            $data = $this->_get_posted_image_data();
                        
            if($this->model->save($data)){
                $this->session->set('success', 'Image data successfully updated.');
                return $this->response->redirect(site_url('/admin/image'));
            
            } else {
                $this->session->set('error', 'Image data  updated failed.');
                return $this->response->redirect(site_url('admin/image/edit/' . $data['id']));
            }
        }
        
        $this->data['galleries'] = $this->db->table('galleries')->where(['status'=>1])->get()->getResult();
        $this->data['image'] = $this->model->get_single_gallery_image($id);
        $this->data['post'] = $_POST;
        $this->data['edit'] = TRUE;            
        return view($this->folder . "/image/index", $this->data);
        
    }

    
    private function _prepare_image_validation() {

        $rules = [
            
            "gallery_id" => ["label" => "Gallery", "rules" => "required"]
        ];
        
        if (!$this->request->getVar('id')) {
            $rules['image'] = ["label" => "Gallery Image", "rules" => "required"];
        }
        
        if ($this->request->getFile("image")->getName()) {
            $rules['image'] = 'uploaded[image]|is_image[image]|mime_in[image,image/png,image/jpg,image/jpeg,image/pjpeg,image/x-png,image/gif]|ext_in[image,png,jpg,gif,jpeg,pjpeg]';
        }

        $validate = $this->validate($rules);
        return $validate;
    }

    
    private function _get_posted_image_data() {

        $data = array();

        $data['gallery_id'] = $this->request->getVar('gallery_id');
        $data['caption'] = $this->request->getVar('caption');
        $data['modified_at'] = date('Y-m-d H:i:s');
        $data['modified_by'] = logged_in_user_id();
            
        if ($this->request->getVar('id')) {
            
            $data['status'] = $this->request->getVar('status');
            $data['id'] = $this->request->getVar('id');
            
        } else {
            
            $data['status'] = 1;           
            $data['created_at'] = date('Y-m-d H:i:s');
            $data['created_by'] = logged_in_user_id();
            
        }

        $data['image'] = $this->__upload_image();
        return $data;
    }
    
    public function delete($id) {
        
        
        $image = $this->db->table('gallery_images')->where(['id' => $id])->get()->getRow();
        
        if($this->model->delete($id)){
        
            // process delete image
            $destination = UPLOAD_PATH.'gallery/'; 
            if (file_exists($destination . $image->image)) {
                @unlink($destination . $image->image);
            }
        
            $this->session->set('success', 'Image data deleted successfully.');
            
        }else{
            
            $this->session->set('error', 'Image data deleted failed. Please try again.');  
            
        }
        
        return $this->response->redirect(site_url('/admin/image'));
    }
    
    private function __upload_image(){
        
        $file = $this->request->getFile("image");
        $image_upload = $file->getBasename();
        $prev_image = $this->request->getVar('image_prev');
        $return_iamge = '';
        
        if($image_upload){
            
            $ext = $file->guessExtension();        
            $destination = UPLOAD_PATH.'gallery/'; 
            $image_name = 'gallery-'.time() . '-shdl.' . $ext;

             if ($file->move($destination, $image_name)) {     
                 
                $return_iamge = $image_name;
                
                // need to unlink previous image
                if ($prev_image != "") {
                    if (file_exists($destination . $prev_image)) {
                        @unlink($destination . $prev_image);
                    }
                }
             } 
             
        }else{ 
            
             $return_iamge = $prev_image;
        }
         
        return $return_iamge;
    }
    
}
