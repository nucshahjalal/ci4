<?php

namespace Modules\Admin\Controllers;

use App\Controllers\BaseController;
use Modules\Admin\Models\UserModel;

class Admin extends BaseController {

    public $folder = '\Modules\Admin\Views';
    public $data = array();
    public $db = '';
    
    public function index() {
      
        helper('form');
        $this->data['title_for_layout'] = 'Welcome to Login AVILABD.com';
        return view($this->folder . "\login", $this->data);
    }

    public function login() {

        $session = session();        
        $this->db = \Config\Database::connect();
        
        $email = $this->request->getVar('email');
        $password = md5($this->request->getVar('password'));
        
        $login = $this->db->table('users')->where(['status' => 1, 'email'=>$email, 'password'=>$password])->get()->getRow();
                
        if ($login) {        
               
            
            $session->set('id', $login->id);
            $session->set('name', $login->name);
            $session->set('email', $login->email);
            $session->set('image', $login->image);
            $session->set('success', 'You have successfully logged in.');          
            
            $this->db->table('users')->set('last_logged_in', date('Y-m-d H:i:s'))->where('id', $login->id)->update();
            
            return redirect()->to('/admin/dashboard');           
            
        } else {
            $session->setFlashdata('error', 'Invalid Login. Please try again.');
            return redirect()->to('admin');
        }
    }
    
    
    public function logout(){
        
        $session = session();
        $session->destroy();
        return redirect()->to('admin');
    }

}
