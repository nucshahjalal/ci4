<?php

namespace Modules\Admin\Controllers;

use App\Controllers\AvilaController;
use Modules\Admin\Models\SettingModel;

class Setting extends AvilaController {

    public $folder = '\Modules\Admin\Views';
    public $model = '';

    public function __construct() {
        
        $this->model = new SettingModel();
        $this->data['path'] = $this->folder;
    }

    public function index() {

        $this->data['setting'] = $this->db->table('settings')->where(['status' => 1])->get()->getRow();
        $this->data['list'] = TRUE;
        return view($this->folder . "\setting\index", $this->data);
    }

    public function add() {

        if ($this->_prepare_setting_validation()) {

            $data = $this->_get_posted_setting_data();
            $this->model->save($data);

            if ($this->request->getVar('id')) {
                $this->session->set('success', 'Setting data successfully saved.');
            } else {
                $this->session->set('success', 'Setting data successfully updated.');
            }
            return $this->response->redirect(site_url('admin/setting'));
        } else {
            $this->data['post'] = $_POST;
            $this->data['add'] = TRUE;
            return view($this->folder . "/setting/index", $this->data);
        }
    }


    
    private function _prepare_setting_validation() {

        $rules = [
            
            'name' => 'required',
            'address' => 'required',
            'copy_right' => 'required',
            "opening_day" => ["label" => "Opening day", "rules" => "required"],
            'email' => 'required|valid_email[settings.email,id,{id}]',
            'mobile' => 'required|min_length[6]|max_length[20]'
        ];

        $validate = $this->validate($rules);
        return $validate;
    }

    
    private function _get_posted_setting_data() {

        $data = array();

        $data['email'] = $this->request->getVar('email');
        $data['mobile'] = $this->request->getVar('mobile');
        $data['phone'] = $this->request->getVar('phone');
        $data['skype'] = $this->request->getVar('skype');
        $data['fax'] = $this->request->getVar('fax');
        
        $data['name'] = $this->request->getVar('name');
        $data['address'] = $this->request->getVar('address');
        $data['opening_day'] = $this->request->getVar('opening_day');
        $data['opening_time'] = $this->request->getVar('opening_time');
        $data['close_day'] = $this->request->getVar('close_day');
        
        $data['currency'] = $this->request->getVar('currency');
        $data['facebook'] = $this->request->getVar('facebook');
        $data['twitter'] = $this->request->getVar('twitter');
        $data['linked_in'] = $this->request->getVar('linked_in');
        $data['youtube'] = $this->request->getVar('youtube');

        $data['pinterest'] = $this->request->getVar('pinterest');
        $data['instagram'] = $this->request->getVar('instagram');
        $data['key_note'] = $this->request->getVar('key_note');
        $data['copy_right'] = $this->request->getVar('copy_right');
        $data['google_map'] = $this->request->getVar('google_map');
        $data['modified_at'] = date('Y-m-d H:i:s');
        $data['modified_by'] = logged_in_user_id();

        if ($this->request->getVar('id')) {
            
            $data['id'] = $this->request->getVar('id');
            
        } else {
            
            $data['status'] = 1;
            $data['created_at'] = date('Y-m-d H:i:s');
            $data['created_by'] = logged_in_user_id();
            
        }

        return $data;
    }

}
