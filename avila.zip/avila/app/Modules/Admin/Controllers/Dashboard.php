<?php

namespace Modules\Admin\Controllers;

use App\Controllers\ShdlController;
use Modules\Admin\Models\AdminModel;

class Dashboard extends ShdlController {

    public $folder = '\Modules\Admin\Views';

    public function __construct()
    {
      
    } 
    
    public function index() {         
        
        return view($this->folder . "\dashboard", $this->data);
    }
}