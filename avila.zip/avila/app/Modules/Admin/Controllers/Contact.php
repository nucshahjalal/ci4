<?php

namespace Modules\Admin\Controllers;

use App\Controllers\AvilaController;
use Modules\Admin\Models\ContactModel;

class Contact extends AvilaController {

    public $folder = '\Modules\Admin\Views';
    public $model = '';

    public function __construct() {
        
        $this->model = new ContactModel();
    }

    public function index() {

        $this->data['contacts'] = $this->db->table('contacts')->orderBy('id','desc')->get()->getResult();
        $this->data['list'] = TRUE;
        return view($this->folder . "\contact\index", $this->data);
    }


    public function add() {

        if ($_POST && $this->_prepare_contact_validation()) {

            $data = $this->_get_posted_contact_data();
            if ($this->model->insert($data)) {
                $this->session->set('success', 'Contact data successfully inserted.');
                return $this->response->redirect(site_url('admin/contact'));
            } else {
                $this->session->set('error', 'Contact data insert failed.');
            }
        }

        $this->data['post'] = $_POST;
        $this->data['add'] = TRUE;
        return view($this->folder . "\contact\index", $this->data);
    }

    
    public function edit($id = null) {

        if ($_POST && $this->_prepare_contact_validation()) {

            $data = $this->_get_posted_contact_data();
            if ($this->model->save($data)) {
                $this->session->set('success', 'Contact data successfully updated.');
                return $this->response->redirect(site_url('admin/contact'));
            } else {
                $this->session->set('error', 'Contact data  updated failed.');
                return $this->response->redirect(site_url('admin/contact/edit/' . $data['id']));
            }
        }

        $this->data['contact'] = $this->model->get_single_contact($id);
        $this->data['post'] = $_POST;
        $this->data['edit'] = TRUE;           
        return view($this->folder . "\contact\index", $this->data);
    }

    public function view() {
        
        $contact_id = $this->request->getVar('contact_id');
        $this->data['contact'] = $this->model->get_single_contact($contact_id);
        return view($this->folder . "/contact/get-single-contact", $this->data);
    }
    
    private function _prepare_contact_validation() {

        $rules = [
            
            'name' => 'required',
            'email' => 'required|valid_email',
            'subject' => 'required'
        ];


        $validate = $this->validate($rules);
        return $validate;
    }

    
    private function _get_posted_contact_data() {

        $data = array();

        $data['name'] = $this->request->getVar('name');
        $data['email'] = $this->request->getVar('email');
        $data['phone'] = $this->request->getVar('phone');
        $data['subject'] = $this->request->getVar('subject');
        $data['message'] = $this->request->getVar('message');
        $data['modified_at'] = date('Y-m-d H:i:s');
        $data['modified_by'] = logged_in_user_id();

        if ($this->request->getVar('id')) {
            
            $data['status'] = $this->request->getVar('status');
            $data['id'] = $this->request->getVar('id');
            
        } else {
            
            $data['status'] = 1;           
            $data['created_at'] = date('Y-m-d H:i:s');
            $data['created_by'] = logged_in_user_id();
            
        }

        return $data;
    }
    
    public function delete($id) {
        
       if ($this->model->delete($id)) {
            $this->session->set('success', 'Contact data  successfully deleted.');
        } else {
            $this->session->set('error', 'Contact data deleted failed.');
        }

        return $this->response->redirect(site_url('/admin/contact'));
    }
    
    
}
