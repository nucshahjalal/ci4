<?php

namespace Modules\Admin\Controllers;

use App\Controllers\AvilaController;
use Modules\Admin\Models\AdminModel;
use Modules\Admin\Models\UserModel;

class User extends AvilaController {

    public $folder = '\Modules\Admin\Views';
    public $model = '';

    public function __construct() {
        $this->model = new UserModel();
    }

    public function index() {

        $this->data['users'] = $this->db->table('users')->get()->getResult();
        $this->data['list'] = TRUE;
        return view($this->folder . "/user/index", $this->data);
    }


    public function add() {

        if ($this->_prepare_user_validation()) {

            $data = $this->_get_posted_user_data();
            if($this->model->insert($data)){
                $this->session->set('success', 'User data successfully saved.');
                return $this->response->redirect(site_url('/admin/user'));
            } else {
                
                $this->session->set('error', 'Contact data insert failed.');
            }
        }
        
        $this->data['users'] = $this->db->table('users')->get()->getResult();
        $this->data['post'] = $_POST;
        $this->data['add'] = TRUE;
        return view($this->folder . "/user/index", $this->data);
    }

    
    public function edit($id = null) {

        if ($_POST && $this->_prepare_user_validation()) {

            $data = $this->_get_posted_user_data();
            if ($this->model->save($data)){
                $this->session->set('success', 'User data successfully updated.');
                return $this->response->redirect(site_url('/admin/user'));
            } else {
                $this->session->set('error', 'User data  updated failed.');
                return $this->response->redirect(site_url('admin/user/edit/' . $data['id']));    
            }
        }
        
        $this->data['user'] = $this->model->get_single_user($id);
        $this->data['post'] = $_POST;
        $this->data['edit'] = TRUE;            
        return view($this->folder . "/user/index", $this->data);
    }

    
    private function _prepare_user_validation() {

        $rules = [
            
            'name' => 'required|min_length[3]',
            'user_type' => 'required',
            'email' => 'required|valid_email|is_unique[users.email,id,{id}]',
            'mobile' => 'required|numeric|min_length[6]|max_length[15]'
        ];

        if (!$this->request->getVar('id')) {
            $rules['password'] = 'required|min_length[3]|max_length[12]';
        }

        $validate = $this->validate($rules);
        return $validate;
    }

    
    private function _get_posted_user_data() {

        $data = array();

        $data['name'] = $this->request->getVar('name');
        $data['user_type'] = $this->request->getVar('user_type');
        $data['email'] = $this->request->getVar('email');
        $data['mobile'] = $this->request->getVar('mobile');
        $data['address'] = $this->request->getVar('address');
        $data['modified_at'] = date('Y-m-d H:i:s');
        $data['modified_by'] = logged_in_user_id();
        
        if ($this->request->getVar('password')) {
            
            $data['password'] = md5($this->request->getVar('password'));
            $data['temp_password'] = base64_decode($data['password']);
        }

        if ($this->request->getVar('id')) {
            
            $data['id'] = $this->request->getVar('id');
            
        } else {
            
            $data['status'] = 1; 
            $data['is_default'] = 0; 
            $data['last_logged_in'] = date('Y-m-d H:i:s');
            $data['created_at'] = date('Y-m-d H:i:s');
            $data['created_by'] = logged_in_user_id();
        }

        $data['image'] = $this->__upload_image();
        return $data;
    }
    
    
     
    private function __upload_image(){
        
        $file = $this->request->getFile("image");
        $image_upload = $file->getName();
        $prev_image = $this->request->getVar('image_prev');
        $return_iamge = '';
        
        if($image_upload){
            
            $ext = $file->guessExtension();        
            $destination = UPLOAD_PATH.'user/'; 
            $image_name = 'user-'.time() . '-shdl.' . $ext;

             if ($file->move($destination, $image_name)) {     
                 
                $return_iamge = $image_name;
                
                // need to unlink previous image
                if ($prev_image != "") {
                    if (file_exists($destination . $prev_image)) {
                        @unlink($destination . $prev_image);
                    }
                }
             } 
             
        }else{ 
            
             $return_iamge = $prev_image;
        }
         
        return $return_iamge;
    }

    
    public function delete($id) {
        
        
        $user = $this->db->table('users')->where(['id' => $id])->get()->getRow();
        
        if($this->model->delete($id)){
        
            // process delete image
            $destination = UPLOAD_PATH.'user/'; 
            if (file_exists($destination . $user->image)) {
                @unlink($destination . $user->image);
            }
        
            $this->session->set('success', 'User data deleted successfully.');
            
        }else{
            
            $this->session->set('error', 'User data deleted failed. Please try again.');  
            
        }
        
        return $this->response->redirect(site_url('/admin/user'));
    }

}
