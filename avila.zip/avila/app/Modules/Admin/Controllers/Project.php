<?php

namespace Modules\Admin\Controllers;

use App\Controllers\AvilaController;
use Modules\Admin\Models\ProjectModel;

class Project extends AvilaController {

    public $folder = '\Modules\Admin\Views';
    public $model = '';

    public function __construct() {
        
        $this->model = new ProjectModel(); 
        $this->data['path'] = $this->folder;
    }

    public function index() {

        $this->data['projects'] = $this->db->table('projects')->orderBy('id','desc')->get()->getResult();
        $this->data['list'] = TRUE;
        return view($this->folder . "/project/index", $this->data);
    }

    public function add() {

        if ($_POST && $this->_prepare_project_validation()) {

            $data = $this->_get_posted_project_data();
            if($this->model->insert($data)){
                $this->session->set('success', 'Project data successfully saved.');
                return $this->response->redirect(site_url('/admin/project'));
            
            } else {
                $this->session->set('error', 'Project data insert failed.');
            }
        }
        
        $this->data['post'] = $_POST;
        $this->data['add'] = TRUE;
        return view($this->folder . "/project/index", $this->data);
    }

    
    public function edit($id = null) {

        if ($_POST && $this->_prepare_project_validation()) {

            $data = $this->_get_posted_project_data();
            
            if($this->model->save($data)){
                $this->session->set('success', 'Project data successfully updated.');
                return $this->response->redirect(site_url('/admin/project'));
            
            } else {
                $this->session->set('error', 'Project data  updated failed.');
                return $this->response->redirect(site_url('admin/project/edit/' . $data['id']));
            }
        }
        
        $this->data['project'] = $this->model->get_single_project($id);
        $this->data['post'] = $_POST;
        $this->data['edit'] = TRUE;            
        return view($this->folder . "/project/index", $this->data);
    }

    public function view() {
        
        $project_id = $this->request->getVar('project_id');       
        $this->data['project'] = $this->model->get_single_project($project_id);       
        return view($this->folder . "/project/get-single-project", $this->data);
    }
    
    private function _prepare_project_validation() {

        $rules = [
            
            'name' => 'required',
            "project_status" => ["label" => "Project status", "rules" => "required"],
            "project_type" => ["label" => "Project type", "rules" => "required"],
            "location" => "required",
            "approval_date" => "required",
            "address" => "required",
            
        ];
        
        if ($this->request->getFile("image")->getName()) {
            $rules['image'] = 'uploaded[image]|is_image[image]|mime_in[image,image/png,image/jpg,image/jpeg,image/pjpeg,image/x-png,image/gif]|ext_in[image,png,jpg,gif,jpeg,pjpeg]';
        }
        
        if ($this->request->getFile("brochure")->getName()) {
            $rules['brochure'] = 'uploaded[brochure]|mime_in[brochure,application/msword,application/vnd.ms-office,application/pdf]|ext_in[brochure,doc,docx,pdf]';
        }
        
        $validate = $this->validate($rules);
        return $validate;
    }

    
    private function _get_posted_project_data() {

        $data = array();

        $data['project_status'] = $this->request->getVar('project_status');
        $data['project_type'] = $this->request->getVar('project_type'); 
        $data['is_featured'] = $this->request->getVar('is_featured');
        $data['name'] = $this->request->getVar('name');
        $data['brochure'] = $this->request->getVar('brochure');
        
        $data['latitude'] = $this->request->getVar('latitude');
        $data['longitude'] = $this->request->getVar('longitude');
        $data['address'] = $this->request->getVar('address');
        $data['location'] = $this->request->getVar('location');
        $data['land_amount'] = $this->request->getVar('land_amount');
        
        $data['approval_no'] = $this->request->getVar('approval_no');        
        $data['front_view'] = $this->request->getVar('front_view');
        $data['no_of_building'] = $this->request->getVar('no_of_building');
        $data['total_floor'] = $this->request->getVar('total_floor');
        $data['total_flat'] = $this->request->getVar('total_flat');
        $data['total_sale'] = $this->request->getVar('total_sale');
        $data['total_available'] = $this->request->getVar('total_available');
        
        $data['flat_sft'] = $this->request->getVar('flat_sft');
        $data['flat_bed'] = $this->request->getVar('flat_bed');
        $data['flat_bath'] = $this->request->getVar('flat_bath');
        $data['flat_baranda'] = $this->request->getVar('flat_baranda');
        $data['flat_bachine'] = $this->request->getVar('flat_bachine');
        $data['flat_window'] = $this->request->getVar('flat_window');
        $data['flat_dyning'] = $this->request->getVar('flat_dyning');
        $data['flat_drawing'] = $this->request->getVar('flat_drawing');
        $data['flat_kitchen'] = $this->request->getVar('flat_kitchen');
        $data['flat_store_room'] = $this->request->getVar('flat_store_room');
        $data['video'] = $this->request->getVar('video');
        $data['note'] = $this->request->getVar('note');
        
        $data['approval_date'] = '';
        if($this->request->getVar('approval_date') !=       ''){
            $data['approval_date'] = date('Y-m-d', strtotime($this->request->getVar('approval_date')));
        }
        $data['modified_at'] = date('Y-m-d H:i:s');
        $data['modified_by'] = logged_in_user_id();
            
        if ($this->request->getVar('id')) {
            
            $data['status'] = $this->request->getVar('status');
            $data['id'] = $this->request->getVar('id');
            
        } else {
            
            $data['status'] = 1;           
            $data['created_at'] = date('Y-m-d H:i:s');
            $data['created_by'] = logged_in_user_id();
        }
        
        $data['image'] = $this->__upload_image();
        $data['brochure'] = $this->__upload_brochure();
        return $data;
    }
    
    public function delete($id) {
        
        $project = $this->db->table('projects')->where(['id' => $id])->get()->getRow();
        
        if($this->model->delete($id)){
        
            // process delete image
            $destination = UPLOAD_PATH.'project/'; 
            if (file_exists($destination . $project->image)) {
                @unlink($destination . $project->image);
            }
            
            if(file_exists($destination . $project->brochure)) {
                @unlink($destination . $project->brochure);
            }
            
            $this->session->set('success', 'Project data deleted successfully.');
            
        }else{
            
            $this->session->set('error', 'Project data deleted failed. Please try again.');  
            
        }
        
        return $this->response->redirect(site_url('/admin/project'));
    }
    
    private function __upload_image(){
        
        $file = $this->request->getFile("image");
        $image_upload = $file->getBasename();
        $prev_image = $this->request->getVar('image_prev');
        $return_iamge = '';
        
        if($image_upload){
            
            $ext = $file->guessExtension();        
            $destination = UPLOAD_PATH.'project/'; 
            $image_name = 'project-'.time() . '-shdl.' . $ext;

             if ($file->move($destination, $image_name)) {     
                 
                $return_iamge = $image_name;
                
                // need to unlink previous image
                if ($prev_image != "") {
                    if (file_exists($destination . $prev_image)) {
                        @unlink($destination . $prev_image);
                    }
                }
             } 
             
        }else{ 
            
             $return_iamge = $prev_image;
        }
         
        return $return_iamge;
    }
    
    private function __upload_brochure(){
        
        $file = $this->request->getFile("brochure");
        $brochure_upload = $file->getBasename();
        $prev_brochure = $this->request->getVar('brochure_prev');
        $return_brochure = '';
        
        if($brochure_upload){
            
            $ext = $file->guessExtension();        
            $destination = UPLOAD_PATH.'project/'; 
            $brochure_name = 'brochure-'.time() . '-shdl.' . $ext;

             if ($file->move($destination, $brochure_name)) {     
                 
                $return_brochure = $brochure_name;
                
                // need to unlink previous image
                if ($prev_brochure != "") {
                    if (file_exists($destination . $prev_brochure)) {
                        @unlink($destination . $prev_brochure);
                    }
                }
             } 
             
        }else{ 
            
             $return_brochure = $prev_brochure;
        }
         
        return $return_brochure;
    }
    
}
