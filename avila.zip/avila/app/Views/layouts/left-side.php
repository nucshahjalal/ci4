<div class="col-md-3 left_col">
    <div class="left_col scroll-view">
        <div class="navbar nav_title" style="border: 0;">
            <a href="<?php echo site_url('admin/dashboard'); ?>" class="site_title">
                <img class="logo" width="180" src="<?php echo base_url(IMG_URL); ?>/logo.png">
               <!--<span>AVILA</span>-->
            </a>
        </div>
        <div class="clearfix"></div>        
        <!-- sidebar menu -->
        <div id="sidebar-menu" class="main_menu_side hidden-print main_menu">
            <div class="menu_section">

                <ul class="nav side-menu">

                    <li><a href="<?php echo site_url('admin/dashboard'); ?>"><i class="fa fa-dashboard"></i> Dashboard</a>  </li>
                    
                    <li><a href="<?php echo site_url('admin/user'); ?>"><i class="fa fa-users"></i> Users</a>  </li>
                    <li><a><i class="fa fa-gears"></i>Settings <span class="fa fa-chevron-down"></span></a>
                        <ul class="nav child_menu">
                            <li><a href="<?php echo site_url('admin/setting'); ?>">General Settings</a></li>
                            <li><a href="<?php echo site_url('admin/about'); ?>">About AVILA</a></li>
                            <li><a href="<?php echo site_url('admin/heading'); ?>">Heading</a></li>
                        </ul>
                    </li> 
                    <li><a href="<?php echo site_url('admin/contact'); ?>"><i class="fa fa-envelope"></i> Contacts</a>  </li>
                    <li><a href="<?php echo site_url('admin/slider'); ?>"><i class="fa fa-sliders"></i> Slider</a>  </li>
                    <li><a href="<?php echo site_url('admin/news'); ?>"><i class="fa fa-file-o"></i> News</a>  </li>
                    <li><a href="<?php echo site_url('admin/testimonial'); ?>"><i class="fa fa-male"></i> Testimonials</a>  </li>
                    <li><a href="<?php echo site_url('admin/facility'); ?>"><i class="fa fa-certificate"></i> Facilities</a>  </li>                      
                    <li><a><i class="fa fa-home"></i>Projects <span class="fa fa-chevron-down"></span></a>
                        <ul class="nav child_menu">
                            <li><a href="<?php echo site_url('admin/project'); ?>">Projects</a></li>
                            <li><a href="<?php echo site_url('admin/projectimage'); ?>">Project Image</a></li>
                            <li><a href="<?php echo site_url('admin/floorplan'); ?>">Floor Plan</a></li>
                        </ul>
                    </li>  
                    <li><a><i class="fa fa-image"></i>Media Gallery <span class="fa fa-chevron-down"></span></a>
                        <ul class="nav child_menu">
                            <li><a href="<?php echo site_url('admin/gallery'); ?>">Galleries</a></li>
                            <li><a href="<?php echo site_url('admin/image'); ?>">Gallery Image</a></li>
                        </ul>
                    </li> 
                    <li><a><i class="fa fa-lock"></i>My Profile <span class="fa fa-chevron-down"></span></a>
                        <ul class="nav child_menu">
                            <li><a href="<?php echo site_url('admin/profile'); ?>">My Profile</a></li>
                            <li><a href="<?php echo site_url('admin/profile/password'); ?>">Reset Password</a></li>
                            <li><a href="<?php echo site_url('admin/logout'); ?>">Logout</a></li>
                        </ul>
                    </li>   
                </ul>
            </div>     
        </div>
        <!-- /sidebar menu -->
    </div>
</div>