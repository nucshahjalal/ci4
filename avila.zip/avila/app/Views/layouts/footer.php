<footer>
    <div class="pull-right">
        ©2014 All rights reserved SHDL
    </div>
    <div class="clearfix"></div>
</footer>