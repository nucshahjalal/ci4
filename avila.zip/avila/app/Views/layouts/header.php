<div class="top_nav">
    <div class="nav_menu">
        <nav>
            <div class="col-md-2">
                <div class="nav toggle">
                    <a id="menu_toggle"><i class="fa fa-bars"></i></a>
                </div>
            </div>
            <div class="col-md-6 ">
                <div class="school-name"><?php echo $title_for_layout; ?></div>
            </div>
            <div class="col-md-1 ">
                <a href="<?php echo base_url(); ?>" class="" target="_blank" style="line-height: 45px;float: right;"><i class="fa fa-globe"></i> Web</a>
            </div>
            <div class="col-md-3">
                <ul class="nav navbar-nav navbar-right">
                    <li class="">
                        
                        <a href="javascript:;" class="user-profile dropdown-toggle" data-toggle="dropdown" aria-expanded="false">
                            <?php $photo = session('image'); ?>
                            <?php if($photo){ ?>
                                <img src="<?php echo base_url(UPLOAD_PATH); ?>/user/<?php echo $photo; ?>" alt="" width="60" /> 
                            <?php }else{ ?>
                                <img src="<?php echo base_url(IMG_URL); ?>/default.jpg" alt="" width="60" /> 
                            <?php } ?>
                            <?php echo session('name'); ?>
                            <span class=" fa fa-angle-down"></span>
                        </a>
                        <ul class="dropdown-menu dropdown-usermenu pull-right">
                            <li><a href="<?php echo site_url('admin/profile'); ?>"> My Profile</a></li>
                            <li><a href="<?php echo site_url('admin/profile/password'); ?>">Reset Password</a></li>
                            <li><a href="<?php echo site_url('admin/logout'); ?>"><i class="fa fa-sign-out pull-right"></i> Logout </a></li>
                        </ul>
                    </li>                    
                </ul>
            </div>
        </nav>
    </div>
</div>