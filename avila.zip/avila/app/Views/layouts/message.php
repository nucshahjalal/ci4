<style type="text/css">
    .alert {
        padding: 8px 35px 8px 14px;
        margin-bottom: 20px;
        text-shadow: 0 1px 0 rgba(255, 255, 255, 0.5);
        background-color: #fcf8e3;
        border: 1px solid #fbeed5;  
        color: #c09853;
    }    
    .alert-success {
        color: #468847;
        background-color: #dff0d8;
        border-color: #d6e9c6;
    }
    .alert-danger,
    .alert-error {
        color: #b94a48;
        background-color: #f2dede;
        border-color: #eed3d7;
    }
    .alert-info {
        color: #3a87ad;
        background-color: #d9edf7;
        border-color: #bce8f1;
    }  
    .remove{ 
        font-weight: bold;
        font-size: 12px;
        cursor: pointer;
    }
    #message_div{ 
        padding: 10px 10px 10px 10px;
        margin-bottom: 10px;
    }
    #message_div ul{ 
        margin: 0;
        list-style-type: none;
        width: 99%;
        float: left;
    }
</style>

<?php

$session = session(); 
$message = '';
$class = '';

if ($session->get('success')):
    $message = $session->get('success');
    $session->remove('success');
    $class = 'success';
    
elseif ($session->get('error')):
    $message = $session->get('error');
    $session->remove('error');
    $class = 'error';
    
elseif ($session->get('warning')):
    $message = $session->get('warning');
    $session->remove('warning');
    $class = 'warning';
    
elseif ($session->get('info')):
    $message = $session->get('info');
    $session->remove('alert_info');
    $class = 'info';
endif;

?>

<?php
if ($message):
    ?>
<div class="row"> 
    <div class="col-lg-12">
        <div id="message_div" class="alert alert-<?php echo $class; ?>">
            <ul>
                <?php
                echo $message;
                ?>          
            </ul>
            <span class="remove">X</span>
        </div>
    </div>
    </div>
    <?php
endif;
?>
<script type="text/javascript">
    $(function () {
        $('#message_div').delay(10000).fadeOut();
        $('.remove').click(function () {
            $('#message_div').hide();
        });
    });
</script>