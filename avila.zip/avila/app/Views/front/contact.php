<?php echo $this->extend("front/master"); ?>
<?php echo $this->section("content"); ?>  

<!-- breadcumb-start -->
<div class="breadcumb-area">
    <div class="img bg-with-black">
        <img src="<?php echo base_url(IMG_URL); ?>/breadcumb-bg.jpg" alt="">
    </div>
    <div class="content">
        <div class="container">
            <div class="row">
                <div class="col-12">
                    <div class="breadcumb">
                        <ul class="links">
                            <li><a href="<?php echo site_url(); ?>">Home</a></li>
                            <li><a href="<?php echo site_url('contact'); ?>">Contact Us</a></li>
                        </ul>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<!-- breadcumb-end -->

<!-- contact-form-start -->
<div class="contact-form-area">
    <div class="container">
        <div class="row">
            <div class="col-12">
                <div class="section-title">
                    <h2 class="title">Get In Touch</h2>
                </div>
            </div>
        </div>
        <div class="row">
            <div class="col-lg-10 offset-lg-1 col-md-10 offset-md-1 col-sm-12 col-12">
                    <?php 
                       $attributes = ['class' => 'form-horizontal form-label-left', 'id' => 'contact', 'name'=>'add'];
                       $action = 'contactstore';
                       echo form_open(site_url($action), $attributes);
                    ?>
                    <div class="row">
                        <div class="col-lg-6 col-md-6 col-sm-12 col-12">
                            <div class="cf-input-box">
                                <input type="text" name="name" required="required" placeholder="Name*"/>
                            </div>
                            <div class="cf-input-box">
                                <input type="email" name="email"  required="required" placeholder="Email*"/>
                            </div>
                            <div class="cf-input-box">
                                <input type="text" name="phone"  required="required" placeholder="Phone*"/>
                            </div>
                            <div class="cf-input-box">
                                <input type="text" name="subject" required="required" placeholder="Subject*">
                            </div>
                        </div>
                        <div class="col-lg-6 col-md-6 col-sm-12 col-12">
                            <div class="cf-input-box">
                                <textarea name="message" placeholder="Message"></textarea>
                            </div>
                            <div class="cf-input-box text-right">
                                <input type="submit" value="Submit">
                            </div>
                        </div>
                    </div>
                <?php echo form_close(); ?>
            </div>
        </div>

    </div>
</div>
<script type="text/javascript">
    $("#contact").validate();  
</script>
<!-- contact-form-end -->

<!-- contact-start -->
<div class="contact-area">
    <div class="container">
        <div class="row">
            <div class="col-12">
                <div class="section-title">
                    <h2 class="title">Contact</h2>
                </div>
            </div>
        </div>
        <div class="row justify-content-center">
            <div class="col-lg-8 col-md-10 col-12">
                <div class="row">
                    <div class="col-lg-5 col-md-5 col-sm-6 col-12">
                        <div class="contact-info">
                            <h4 class="title">AVILA Contact Info</h4>
                            <ul class="info">
                                <li><span class="icon"><i class="fas fa-phone"></i></span> <?php echo $setting->mobile; ?></li>
                                <li><span class="icon"><i class="fas fa-fax"></i></span> <?php echo $setting->fax; ?></li>
                                <?php if($setting->skype){ ?>
                                <li><span class="icon"><i class="fab fa-skype"></i></span> <?php echo $setting->skype; ?></li>
                                <?php } ?>
                                <li><span class="icon"><i class="fas fa-envelope"></i></span> <?php echo $setting->email; ?></li>
                                <li><span class="icon"><i class="fas fa-map-marker-alt"></i></span> <?php echo $setting->address; ?></li>
                            </ul>
                        </div>
                    </div>
                    <div class="col-lg-5 offset-lg-2 col-md-5 offset-md-2 col-sm-6 col-12">
                        <div class="contact-info">
                            <h4 class="title">Opening Hour</h4>
                            <ul class="info">
                                <li>Opeing Days: <?php echo $setting->opening_day; ?></li>
                                <li>Opening Time: <?php echo $setting->opening_time; ?></li>
                                <li>Closed: <?php echo $setting->close_day; ?></li>
                            </ul>
                            <ul class="share">
                                <li>Social:</li>
                                <?php  if($setting->facebook){ ?>
                                    <li><a href="<?php echo $setting->facebook; ?>" target="_blank"><i class="fab fa-facebook-f"></i></a></li>
                                <?php } ?>
                                <?php  if($setting->twitter){ ?>
                                    <li><a href="<?php echo $setting->twitter; ?>" target="_blank"><i class="fab fa-twitter"></i></a></li>
                                <?php } ?>
                                <?php  if($setting->linked_in){ ?>
                                    <li><a href="<?php echo $setting->linked_in; ?>" target="_blank"><i class="fab fa-linkedin-in"></i></a></li>
                                <?php } ?>
                                <?php  if($setting->pinterest){ ?>
                                    <li><a href="<?php echo $setting->pinterest; ?>" target="_blank"><i class="fab fa-pinterest-p"></i></a></li>
                                <?php } ?>
                                <?php  if($setting->youtube){ ?>
                                   <li><a href="<?php echo $setting->youtube; ?>" target="_blank"><i class="fab fa-youtube"></i></a></li>
                                <?php } ?>
                                <?php  if($setting->instagram){ ?>
                                   <li><a href="<?php echo $setting->instagram; ?>" target="_blank"><i class="fab fa-instagram"></i></a></li>
                                <?php } ?> 
                            </ul>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<!-- contact-end -->
<!-- map-start -->
 <?php  if($setting->google_map){ ?>
<div id="googleMap">
    <?php echo $setting->google_map; ?>
</div>
<!-- map-end -->
 <?php } ?>
<!-- map-script -->

<?php echo $this->endSection(); ?>