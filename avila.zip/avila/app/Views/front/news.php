<?php echo $this->extend("front/master"); ?>
<?php echo $this->section("content"); ?>  

<!-- breadcumb-start -->
<div class="breadcumb-area">
    <div class="img bg-with-black">
        <img src="<?php echo base_url(IMG_URL); ?>/breadcumb-bg.jpg" alt="">
    </div>
    <div class="content">
        <div class="container">
            <div class="row">
                <div class="col-12">
                    <div class="breadcumb">
                        <ul class="links">
                            <li><a href="<?php echo site_url(); ?>">Home</a></li>
                            <li><a href="<?php echo site_url('news'); ?>">News</a></li>
                        </ul>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<!-- breadcumb-end -->


<!-- news-start -->
<?php if(isset($news) && !empty($news)){ ?>
<div class="news-area">
    <div class="container">
        <div class="row">
            <div class="col-lg-8 offset-lg-2 col-md-10 offset-md-1 col-sm-12 col-12">
                <div class="section-title">
                    <h2 class="title"><?php echo $heading->news_title; ?></h2>
                    <p class="text"><?php echo $heading->news_note; ?></p>
                </div>
            </div>
        </div>
        <div class="row justify-content-center">
            <?php foreach($news as $obj){ ?>
                <div class="col-lg-4 col-md-6 col-sm-6 col-12">
                    <div class="single-news">
                        <div class="img">
                            <?php if($obj->image){ ?>
                                <img src="<?php echo base_url(UPLOAD_PATH); ?>/news/<?php echo $obj->image; ?>" alt=""  />
                            <?php }else{ ?>
                                <img src="<?php echo base_url(IMG_URL); ?>/news-default.jpg" alt="">
                            <?php } ?>
                        </div>
                        <div class="content">
                            <ul class="meta">
                                <li><span class="icon"><i class="far fa-calendar-alt"></i></span> <?php echo date('d/m/Y', strtotime($obj->created_at)); ?></li>
                                <li><span class="icon"><i class="fas fa-user"></i></span> Admin</li>
                            </ul>
                            <h2 class="title"><a href="<?php echo site_url('news-detail/'.$obj->id); ?>"><?php echo $obj->title; ?></a></h2>
                            <p class="text">
                                <?php echo substr(strip_tags($obj->initial_part), 0, 150); ?>...
                            </p>
                            <div class="more"><a class="link" href="<?php echo site_url('news-detail/'.$obj->id); ?>">Read More</a></div>
                        </div>
                    </div>
                </div>
            <?php } ?>
        </div>
    </div>
</div>
<!-- news-end -->
<?php } ?>

<?php echo $this->endSection(); ?>