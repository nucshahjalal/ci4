<?php echo $this->extend("front/master"); ?>
<?php echo $this->section("content"); ?>  

<!-- breadcumb-start -->
<div class="breadcumb-area">
    <div class="img bg-with-black">
        <img src="<?php echo base_url(IMG_URL); ?>/breadcumb-bg.jpg" alt="">
    </div>
    <div class="content">
        <div class="container">
            <div class="row">
                <div class="col-12">
                    <div class="breadcumb">
                        <ul class="links">
                            <li><a href="<?php echo site_url(); ?>">Home</a></li>
                            <li><a href="<?php echo site_url($project_url); ?>"><?php echo ucfirst($project_url); ?></a></li>
                        </ul>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<!-- breadcumb-end -->


<!-- complete-start -->
<div class="complete-area">
    <div class="container">
        <div class="row">
            <div class="col-lg-10 offset-lg-1 col-md-10 offset-md-1 col-sm-12 col-12">
                <div class="section-title">
                    <h2 class="title"><?php echo ucfirst($project_title); ?></h2>
                    <p class="text">
                        <?php echo ucfirst($project_note); ?>
                    </p>
                </div>
            </div>
        </div>
        <div class="row">
            <div class="col-lg-6 offset-lg-0 col-md-10 offset-md-1 col-sm-12 col-12">
                <div class="complete-contents">
                    <div class="select-project">
                        <h4 class="name">Select Projects</h4>
                         <?php 
                            $attributes = ['class' => 'form-horizontal form-label-left', 'id' => 'edit', 'name'=>'edit'];
                            $action = 'home/completed';
                            echo form_open_multipart(site_url($action), $attributes);
                        ?>
                        <select name="project" id="project" onchange="get_project(this.value);">
                            <option value="">--Select Project--</option>
                            <?php if(isset($projects) && !empty($projects)){ ?>
                                <?php foreach($projects as $obj){ ?>
                                    <option value="<?php echo site_url($obj->project_status.'/'.$obj->id); ?>" <?php if($project->id == $obj->id){ echo 'selected="selected"';} ?>><?php echo $obj->name; ?></option>   
                                <?php } ?>
                            <?php } ?>
                        </select>
                        <?php echo form_close(); ?>
                    </div>
                    <h4 class="title">Project Name: <?php echo $project->name; ?></h4>
                    <div class="two-icon">
                        <p class="name">
                            <?php if($project->brochure){ ?>
                                <a href="<?php echo base_url(UPLOAD_PATH); ?>/project/<?php echo $project->brochure; ?>" target="_blank">Brochures <span class="icon"><i class="fas fa-file-pdf"></i></span> </a>
                            <?php }else{ ?>
                                <a href="javascript:void(0);" >Brochures <span class="icon"><i class="fas fa-file-pdf"></i></span> </a>
                            <?php }?>
                        </p>
                    </div>
                    <ul class="infos">
                        <?php if($project->location){ ?>
                            <li>
                                <span class="head" style="vertical-align: top;">Location</span>
                                <span class="info">: <?php echo $project->location; ?></span>
                            </li>
                        <?php }?>
                            
                        <?php if($project->address){ ?>    
                        <li>
                            <span class="head">Address</span>
                            <span class="info">: <?php echo $project->address; ?></span>
                        </li>
                        <?php }?>
                        
                        <?php if($project->project_status){ ?> 
                            <li>
                                <span class="head">Project Status</span>
                                <span class="info">: <?php echo ucfirst($project->project_status); ?></span>
                            </li>
                        <?php }?>
                        
                        <?php if($project->project_type){ ?>     
                        <li>
                            <span class="head">Project Type</span>
                            <span class="info">: <?php echo ucfirst($project->project_type); ?></span>
                        </li>
                        <?php }?>
                        
                        <?php if($project->land_amount){ ?> 
                        <li>
                            <span class="head">Land Amount</span>
                            <span class="info">: <?php echo $project->land_amount; ?></span>
                        </li>
                        <?php }?>
                        
                        <?php if($project->approval_no){ ?> 
                        <li>
                            <span class="head">Approval No</span>
                            <span class="info">: <?php echo $project->approval_no; ?></span>
                        </li>
                        <?php }?>
                        <?php if($project->approval_date){ ?> 
                        <li>
                            <span class="head">Approval Date</span>
                            <span class="info">: <?php echo $project->approval_date; ?></span>
                        </li>
                        <?php }?>
                        <?php if($project->no_of_building){ ?> 
                        <li>
                            <span class="head">No Of Building(s)</span>
                            <span class="info">: <?php echo $project->no_of_building; ?></span>
                        </li>
                        <?php }?>
                        <?php if($project->total_floor){ ?> 
                        <li>
                            <span class="head">Floor(s)</span>
                            <span class="info">: <?php echo $project->total_floor; ?></span>
                        </li>
                        <?php }?>
                    </ul>                    
                    
                    <?php if($project->total_flat){ ?>
                        <h4 class="title">Project Statistics</h4>
                        <ul class="infos">
                            <?php if($project->total_flat){ ?>
                            <li>
                                <span class="head">Total</span>
                                <span class="info">: <?php echo $project->total_flat; ?></span>
                            </li>
                             <?php }?>
                            <?php if($project->total_floor){ ?>
                            <li>
                                <span class="head">Total Sale Out</span>
                                <span class="info">: <?php echo $project->total_sale; ?></span>
                            </li>
                             <?php }?>
                            <?php if($project->total_floor){ ?>
                            <li>
                                <span class="head">Available</span>
                                <span class="info">: <?php echo $project->total_available; ?></span>
                            </li>
                             <?php }?>
                        </ul>
                    <?php } ?> 
                </div>
            </div>
            <div class="col-lg-6 offset-lg-0 col-md-10 offset-md-1 col-sm-12 col-12 d-flex align-items-center">
                <div class="complete-banner">
                    <div class="project-carousel owl-carousel">
                        <?php if(isset($images) && !empty($images)){ ?>
                            <?php foreach($images as $obj){ ?>
                                <?php if($obj->image){ ?>
                                    <div class="box"><img src="<?php echo base_url(UPLOAD_PATH); ?>/project-image/<?php echo $obj->image; ?>" alt=""  /></div>
                                <?php }else{ ?>
                                    <div class="box"><img src="<?php echo base_url(IMG_URL); ?>/completed-default.jpg" alt=""></div>
                                <?php } ?>
                            <?php } ?>
                        <?php }else{ ?>
                           <div class="box"><img src="<?php echo base_url(UPLOAD_PATH); ?>/project/<?php echo $project->image; ?>" alt=""/></div>
                        <?php } ?>
                    </div>
                    
                    <div class="cb-buttons">
                            <?php if($project->brochure){ ?>
                                <a  class="button" href="<?php echo base_url(UPLOAD_PATH); ?>/project/<?php echo $project->brochure; ?>" target="_blank">Brochures <span class="icon"><i class="fas fa-file-pdf"></i></span> </a>
                            <?php }else{ ?>
                                <a  class="button" href="javascript:void(0);" >Brochures <span class="icon"><i class="fas fa-file-pdf"></i></span> </a>
                            <?php }?>                        
                    </div>
                </div>
            </div>
        </div>
        
        <div class="row">
            <div class="col-12">
                <div id="main">           
                    
                     <div class="" data-example-id="togglable-tabs">
                         
                         <ul  class="nav nav-tabs bordered">
                             <li class="active"><a href="#tab_1"   role="tab" data-toggle="tab" aria-expanded="true"><i class="fa fa-gear"></i>  Project Master Design</a> </li>
                             <li class=""><a href="#tab_2"   role="tab" data-toggle="tab" aria-expanded="true"><i class="fa fa-gear"></i>  Typical Floor Flan</a> </li>
                             <li class=""><a href="#tab_3"   role="tab" data-toggle="tab" aria-expanded="true"><i class="fa fa-gear"></i>  Flat Details</a> </li>
                         </ul>
                         <br/>
                         
                         <div class="tab-content" style="border: 1px solid #07ff71;padding: 10px;background: #f1efef;"> 
                             
                            <div  class="tab-pane fade in active show" id="tab_1">
                                   <?php if($project->image){ ?>
                                        <img src="<?php echo base_url(UPLOAD_PATH); ?>/project/<?php echo $project->image; ?>" alt=""/>
                                    <?php }else{ ?>
                                        <img src="<?php echo base_url(IMG_URL); ?>/project-default.jpg" alt="">
                                    <?php } ?>
                            </div>
                             
                             <div  class="tab-pane fade in " id="tab_2">
                                 
                                 <?php if(isset($floorplans) && !empty($floorplans)){ ?>
                                    <div class="project-carousel owl-carousel">
                                        <?php foreach($floorplans as $obj){ ?>
                                            <?php if($obj->image){ ?>
                                                <div class="box"><img src="<?php echo base_url(UPLOAD_PATH); ?>/floorplan/<?php echo $obj->image; ?>" alt=""  /></div>
                                            <?php }else{ ?>
                                                <div class="box"><img src="<?php echo base_url(IMG_URL); ?>/completed-default.jpg" alt=""></div>
                                            <?php } ?>
                                        <?php } ?>
                                    </div>
                                 <?php }else{ ?>
                                    <div>No floor Plan image found</div>
                                 <?php } ?>
                                 
                             </div>
                             
                             <div  class="tab-pane fade in " id="tab_3">
                                 
                                    <?php if($project->project_status == 'completed'){ ?>
                                        <div>All Project are sale out</div>
                                    <?php }else if($project->project_status == 'upcoming'){ ?>
                                        <div>Project details coming soon........</div>
                                    <?php }else{ ?>
                                        
                                         <?php if(isset($projects) && !empty($projects)){ ?>

                                            <div class="accordion" id="faq">
                                                <?php foreach($projects as $key=>$obj){ ?>
                                                <div class="card">
                                                    <div class="card-header" id="faqhead1">
                                                        <a href="#" class="btn btn-header-link" data-toggle="collapse"  data-target="#faq<?php echo $key+1; ?>" aria-expanded="true" aria-controls="faq1">Project <?php echo $key+1; ?></a>
                                                    </div>

                                                    <div id="faq1" class="collapse show" aria-labelledby="faqhead<?php echo $key+1; ?>" data-parent="#faq">
                                                        <div class="card-body">
                                                            <table>
                                                                <tr>                                                                                               
                                                                    <th  width="20%">Total Sft</th>
                                                                    <td  width="30%"><?php echo $obj->flat_sft; ?></td>
                                                                    <th width="20%">Front View</th>
                                                                    <td width="30%"><?php echo $obj->front_view; ?></td>
                                                                </tr>
                                                                <tr>
                                                                    <th>Total Bed</th>
                                                                    <td><?php echo $obj->flat_bed; ?></td>                                       
                                                                    <th>Total Bath</th>
                                                                    <td><?php echo $obj->flat_bath; ?></td>
                                                                </tr>
                                                                <tr>
                                                                    <th>Total Baranda</th>
                                                                    <td><?php echo $obj->flat_baranda; ?></td>                                        
                                                                    <th>Total Bachine</th>
                                                                    <td><?php echo $obj->flat_bachine; ?></td>
                                                                </tr>
                                                                <tr>
                                                                    <th>Total Window</th>
                                                                    <td><?php echo $obj->flat_window; ?></td>                                       
                                                                    <th>Dyning</th>
                                                                    <td><?php echo $obj->flat_dyning; ?></td>
                                                                </tr>
                                                                <tr>
                                                                    <th>Kitchen</th>
                                                                    <td><?php echo $obj->flat_kitchen; ?></td>                                       
                                                                    <th>Store Room</th>
                                                                    <td><?php echo $obj->flat_store_room; ?></td>
                                                                </tr>
                                                                <tr>
                                                                    <th>Drawing</th>
                                                                    <td><?php echo $obj->flat_drawing; ?></td>                                      
                                                                    <th>Availability</th>
                                                                    <td><?php echo $obj->total_available; ?></td>
                                                                </tr>
                                                                <tr>
                                                                    <th>Project Note</th>
                                                                    <td colspan="3"><?php echo $obj->note; ?></td>                                                                   
                                                                </tr>
                                                                <tr>                                                                   
                                                                    <th>Floor Layout</th>
                                                                    <td colspan="3">
                                                                        <?php if($obj->image){ ?>
                                                                            <img src="<?php echo base_url(UPLOAD_PATH); ?>/project/<?php echo $obj->image; ?>" alt="" />
                                                                        <?php } ?>
                                                                    </td> 
                                                                </tr>
                                                            </table>
                                                        </div>
                                                    </div>
                                                </div>                                       
                                                <?php } ?>
                                            </div>
                                        
                                        <?php }else{ ?>
                                            <div>No project details found</div>
                                        <?php } ?>
                                    <?php } ?>    
                             </div>
                         
                         </div> 
                         
                     </div>
                </div>
            </div>
        </div>
    </div>
</div>
<!-- complete-end -->

<script type="text/javascript">
    function get_project(url){
        if(url){
            window.location.href = url; 
        }
    }
    
</script>

<?php echo $this->endSection(); ?>