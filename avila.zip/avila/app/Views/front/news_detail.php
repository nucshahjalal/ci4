<?php echo $this->extend("front/master"); ?>
<?php echo $this->section("content"); ?>  

<!-- breadcumb-start -->
<div class="breadcumb-area">
    <div class="img bg-with-black">
        <img src="<?php echo base_url(IMG_URL); ?>/breadcumb-bg.jpg" alt="">
    </div>
    <div class="content">
        <div class="container">
            <div class="row">
                <div class="col-12">
                    <div class="breadcumb">
                        <ul class="links">
                            <li><a href="<?php echo site_url(); ?>">Home</a></li>
                            <li><a href="<?php echo site_url('news'); ?>">News</a></li>
                        </ul>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<!-- breadcumb-end -->


<!-- news-details-start -->
<div class="news-details-area">
    <div class="container">
        <div class="row"> 

            <div class="col-lg-9">

                <div class="col-lg-12 col-12">
                    <div class="details-content">
                        <h2 class="name"><?php echo $single->title; ?></h2>
                        <p class="text"><?php echo $single->initial_part; ?></p>
                        <div class="meta-share">
                            <ul class="meta">
                                <li><span class="icon"><i class="far fa-calendar-alt"></i></span> <?php echo date('d/m/Y', strtotime($single->created_at)); ?></li>
                                <li><span class="icon"><i class="fas fa-user"></i></span> Admin</li>
                            </ul>
                            <ul class="share" style="display: none;">
                                <li>Share:</li>
                                <li><a href="#" target="_blank"><i class="fab fa-facebook-f"></i></a></li>
                                <li><a href="#" target="_blank"><i class="fab fa-twitter"></i></a></li>
                                <li><a href="#" target="_blank"><i class="fab fa-google-plus-g"></i></a></li>
                                <li><a href="#" target="_blank"><i class="fab fa-linkedin-in"></i></a></li>
                                <li><a href="#" target="_blank"><i class="fab fa-pinterest-p"></i></a></li>
                            </ul>
                        </div>
                        <div class="img">
                             <?php if($single->image){ ?>
                            <img src="<?php echo base_url(UPLOAD_PATH); ?>/news/<?php echo $single->image; ?>" alt=""  />
                            <?php }else{ ?>
                                <img src="<?php echo base_url(IMG_URL); ?>/news-default.jpg" alt="">
                            <?php } ?>
                        </div>
                    </div>
                </div>
                <div class="col-lg-12">
                    <div class="text-other-post">
                        <p class="text"><?php echo $single->rest_part; ?></p>
                    </div>
                </div>

            </div>
            <div class="col-lg-3">
                <div class="col-lg-12 col-md-12 col-sm-12 col-12">
                    <h2 class="name"><?php echo $heading->news_title; ?></h2><br/>
                </div>
                <?php if(isset($news) && !empty($news)){ ?>
                <?php foreach($news as $obj){ ?>
                    <div class="col-lg-12 col-md-12 col-sm-12 col-12">
                        <div class="single-news">
                            <div class="img">
                                <?php if($obj->image){ ?>
                                <img src="<?php echo base_url(UPLOAD_PATH); ?>/news/<?php echo $obj->image; ?>" alt=""  />
                                <?php }else{ ?>
                                    <img src="<?php echo base_url(IMG_URL); ?>/news-default.jpg" alt="">
                                <?php } ?>
                            </div>
                            <div class="content">
                                <ul class="meta">
                                    <li><span class="icon"><i class="far fa-calendar-alt"></i></span> <?php echo date('d/m/Y', strtotime($obj->created_at)); ?></li>
                                    <li><span class="icon"><i class="fas fa-user"></i></span> Admin</li>
                                </ul>
                                <h2 class="title"><a href="<?php echo site_url('news-detail/'.$obj->id); ?>"><?php echo $obj->title; ?></a></h2>
                                <div class="more"><a class="link" href="<?php echo site_url('news-detail/'.$obj->id); ?>">Read More</a></div>
                            </div>
                        </div>
                    </div> 
                <?php } ?>
                <?php } ?>
                
            </div>
        </div>
    </div>
</div>
<!-- news-details-end -->

<?php echo $this->endSection(); ?>