<!-- footer-start -->
<footer>
    <div class="footer-top-area">
        <div class="container">
            <div class="row">
                <div class="col-lg-4 col-md-4 col-sm-6 col-12">
                    <div class="fw-info footer-widget">
                        <div class="flogo">
                            <img src="<?php echo base_url(IMG_URL); ?>/logo.png" alt="">
                        </div>
                        <p class="text">
                           <?php echo $setting->key_note; ?>
                        </p>
                    </div>
                </div>
                <div class="col-lg-4 col-md-4 col-sm-6 col-12">
                    <div class="fw-address footer-widget">
                        <h2 class="title">Get In Touch</h2>
                        <ul class="adress">
                            <li><span class="icon"><i class="fas fa-envelope"></i></span> <?php echo $setting->email; ?></li>
                            <li><span class="icon"><i class="fas fa-phone"></i></span> +<?php echo $setting->mobile; ?></li>
                            <li><span class="icon"><i class="fas fa-home"></i></span> <?php echo $setting->address; ?></li>
                        </ul>
                    </div>
                </div>
                <div class="col-lg-3 col-md-3 col-sm-6 col-12">
                    <div class="fw-social footer-widget">
                        <h2 class="title">Follow Us</h2>
                        <ul class="social">
                            <?php  if($setting->facebook){ ?>
                                <li><a href="<?php echo $setting->facebook; ?>" target="_blank"><i class="fab fa-facebook-f"></i></a></li>
                            <?php } ?>
                            <?php  if($setting->twitter){ ?>
                                <li><a href="<?php echo $setting->twitter; ?>" target="_blank"><i class="fab fa-twitter"></i></a></li>
                            <?php } ?>
                            <?php  if($setting->linked_in){ ?>
                                <li><a href="<?php echo $setting->linked_in; ?>" target="_blank"><i class="fab fa-linkedin-in"></i></a></li>
                            <?php } ?>
                            <?php  if($setting->pinterest){ ?>
                                <li><a href="<?php echo $setting->pinterest; ?>" target="_blank"><i class="fab fa-pinterest-p"></i></a></li>
                            <?php } ?>
                            <?php  if($setting->youtube){ ?>
                               <li><a href="<?php echo $setting->youtube; ?>" target="_blank"><i class="fab fa-youtube"></i></a></li>
                            <?php } ?>
                            <?php  if($setting->instagram){ ?>
                               <li><a href="<?php echo $setting->instagram; ?>" target="_blank"><i class="fab fa-instagram"></i></a></li>
                            <?php } ?>  
                        </ul>
                    </div>
                </div>                    
            </div>
        </div>
    </div>
    <div class="footer-bottom-area">
        <div class="container">
            <div class="row">
                <div class="col-lg-6 col-md-8 col-sm-8 col-12">
                    <div class="copyright">
                        <p class="text"><?php echo $setting->copy_right; ?></p>
                    </div>
                </div>
                <div class="col-lg-6 col-md-4 col-sm-4 col-12">
                    <div class="back-top" style="margin-right: 100px;">
                        <a class="smoothscroll" href="#_hero">Back to Top</a>
                    </div>
                </div>
            </div>
        </div>
    </div>
</footer>
<!-- footer-end -->