<?php echo $this->extend("front/master"); ?>
<?php echo $this->section("content"); ?>  

<!-- breadcumb-start -->
<div class="breadcumb-area">
    <div class="img bg-with-black">
        <img src="<?php echo base_url(IMG_URL); ?>/breadcumb-bg.jpg" alt="">
    </div>
    <div class="content">
        <div class="container">
            <div class="row">
                <div class="col-12">
                    <div class="breadcumb">
                        <ul class="links">
                            <li><a href="<?php echo site_url(); ?>">Home</a></li>
                            <li><a href="<?php echo site_url('gallery'); ?>">Gallery</a></li>
                        </ul>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<!-- breadcumb-end -->

<!-- gallery-start -->
<div class="gallery-area">
    <div class="container">
        <div class="row">
            <div class="col-lg-10 offset-lg-1 col-md-10 offset-md-1 col-sm-12 col-12">
                <div class="section-title">
                    <h2 class="title"><?php echo $heading->gallery_title; ?></h2>
                    <p class="text"><?php echo $heading->gallery_note; ?></p>
                </div>
            </div>
        </div>
        
        <?php if(isset($galleries) && !empty($galleries)){ ?>
        <?php foreach($galleries as $obj){ ?>
             <?php $images = get_images_by_gallery($obj->id); ?>    
             <?php if(isset($images) && !empty($images)){ ?>
                <div class="row">
                    <div class="col-12">
                        <h4 class="title"><?php echo $obj->title; ?></h4>
                    </div>
                    <div class="col-12">
                        <div class="gallery-carousel owl-carousel">
                          <?php foreach($images as $img){ ?>
                            <div class="single-gallery">
                                <a class="img" href="<?php echo base_url(UPLOAD_PATH); ?>/gallery/<?php echo $img->image; ?>" data-fancybox="images">
                                    <i class="icon fas fa-search-plus"></i>
                                    <?php if($img->image){ ?>
                                        <img src="<?php echo base_url(UPLOAD_PATH); ?>/gallery/<?php echo $img->image; ?>" alt=""  />
                                    <?php }else{ ?>
                                        <img src="<?php echo base_url(IMG_URL); ?>/gallery-default.jpg" alt="" />
                                    <?php } ?>
                                </a>
                            </div>  
                            <?php } ?>
                        </div>
                    </div>
                </div> 
             <?php } ?>
        <?php } ?>
        <?php } ?>
       
    </div>
</div>
<!-- gallery-end -->

<?php echo $this->endSection(); ?>