<?php echo $this->extend("front/master"); ?>
<?php echo $this->section("content"); ?>  

<!-- breadcumb-start -->
<div class="breadcumb-area">
    <div class="img bg-with-black">
        <img src="<?php echo base_url(IMG_URL); ?>/breadcumb-bg.jpg" alt="">
    </div>
    <div class="content">
        <div class="container">
            <div class="row">
                <div class="col-12">
                    <div class="breadcumb">
                        <ul class="links">
                            <li><a href="<?php echo site_url(); ?>">Home</a></li>
                            <li><a href="<?php echo site_url('about'); ?>">About Us</a></li>
                        </ul>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<!-- breadcumb-end -->

<!-- about-start -->
<div class="about-area">
    <div class="container">
        <div class="row">
            <div class="col-lg-6 col-md-6 col-sm-12 col-12">
                <div class="about-content">
                    <h2 class="title"><?php echo $about->title; ?></h2>
                    <p class="text">
                        <?php echo $about->description; ?>
                    </p>
                </div>
            </div>
            <div class="col-lg-6 col-md-6 col-sm-12 col-12 d-flex align-items-center">
                <div class="about-banner">
                     <?php if(isset($about) && $about->image){ ?>
                        <img src="<?php echo base_url(UPLOAD_PATH); ?>/about/<?php echo $about->image; ?>" alt="" />
                     <?php }else{ ?>    
                        <img src="<?php echo base_url(IMG_URL); ?>/about-default.jpg" alt="">
                     <?php } ?>
                </div>
            </div>
        </div>
    </div>
</div>
<!-- about-end -->

<!-- purchase-start -->
<div class="purchase-area bg-with-black">
    <div class="container">
        <div class="row">
            <div class="col-lg-8 offset-lg-2 col-md-10 offset-md-1 col-sm-12 col-12">
                <div class="section-title color-white">
                    <h2 class="title"><?php echo $heading->contact_title; ?></h2>
                    <p class="text"><?php echo $heading->contact_note; ?></p>
                </div>
            </div>
            <div class="col-12">
                <div class="purchase-buttons">
                    <a class="link" href="<?php echo base_url('ongoing'); ?>">Purchase Now</a>
                    <a class="link" href="<?php echo base_url('ongoing'); ?>">View More Info</a>
                </div>
            </div>
        </div>
    </div>
</div>
<!-- purchase-end -->

<?php if(isset($about) && $about->video){ ?>
<!-- about-youtube-start -->
<div class="about-youtube-area">
    <div class="container">
        <div class="row">
            <div class="col-lg-8 offset-lg-2 col-md-10 offset-md-1 col-sm-12 col-12">
                <div class="about-youtube">
                    <?php echo $about->video; ?>
                </div>
            </div>
        </div>
    </div>
</div>
<!-- about-youtube-end -->
<?php } ?>

<?php echo $this->endSection(); ?>

