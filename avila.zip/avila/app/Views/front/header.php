<header id="_hero">
    <div class="header-top-area">
        <div class="container">
            <div class="row">
                <div class="col-lg-8 col-md-9 col-sm-12 col-12">
                    <div class="hta-left">
                        <p class="htal-info"><span class="icon"><i class="fas fa-map-marker-alt"></i></span> <?php echo $setting->address; ?></p>
                        <ul class="htal-info htar-social" style="display: none;">
                            <?php  if($setting->facebook){ ?>
                                <li><a href="<?php echo $setting->facebook; ?>" target="_blank"><i class="fab fa-facebook-f"></i></a></li>
                            <?php } ?>
                            <?php  if($setting->twitter){ ?>
                                <li><a href="<?php echo $setting->twitter; ?>" target="_blank"><i class="fab fa-twitter"></i></a></li>
                            <?php } ?>
                            <?php  if($setting->linked_in){ ?>
                                <li><a href="<?php echo $setting->linked_in; ?>" target="_blank"><i class="fab fa-linkedin-in"></i></a></li>
                            <?php } ?>
                            <?php  if($setting->pinterest){ ?>
                                <li><a href="<?php echo $setting->pinterest; ?>" target="_blank"><i class="fab fa-pinterest-p"></i></a></li>
                            <?php } ?>
                            <?php  if($setting->youtube){ ?>
                               <li><a href="<?php echo $setting->youtube; ?>" target="_blank"><i class="fab fa-youtube"></i></a></li>
                            <?php } ?>
                            <?php  if($setting->instagram){ ?>
                               <li><a href="<?php echo $setting->instagram; ?>" target="_blank"><i class="fab fa-instagram"></i></a></li>
                            <?php } ?>                            
                        </ul>
                    </div>
                </div>
                <div class="col-lg-4 col-md-3 col-sm-12 col-12">
                    <div class="hta-right">
                        <p class="htal-info header-phone_"><span class="icon"><i class="fas fa-mobile-alt"></i></span> <a href="tel:+<?php echo $setting->mobile; ?>" style="font-size: 18px;"><?php echo $setting->mobile; ?></a></p>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div class="header-bottom-area">
        <div class="container">
            <div class="row">
                <div class="col-lg-2 col-md-4 col-sm-12 col-12">
                    <div class="logo">
                        <a href="<?php echo site_url(); ?>"><img src="<?php echo base_url(IMG_URL); ?>/logo.png" alt=""></a>
                    </div>
                </div>
                <div class="col-lg-10 col-md-8 offset-md-0 col-sm-8 offset-sm-2 col-12">
                    <div class="menu">
                        <nav id="mobile_menu_active">
                            <ul>
                                <li class="active"><a href="<?php echo site_url(); ?>">Home</a></li>
                                <li><a href="<?php echo site_url('about'); ?>">About</a></li>
                                <li><a href="javascript:void(0);">Projects <span class="down-icon"><i class="fas fa-chevron-down"></i></span></a>
                                    <ul class="drop">
                                        <li><a href="<?php echo site_url('upcoming'); ?>">Up Coming</a></li>
                                        <li><a href="<?php echo site_url('ongoing'); ?>">On Going</a></li>
                                        <li><a href="<?php echo site_url('completed'); ?>">Completed</a></li>
                                    </ul>
                                </li>
                                <li><a href="<?php echo site_url('news'); ?>">News</a></li>
                                <li><a href="<?php echo site_url('gallery'); ?>">Gallery</a></li>
                                <li><a href="<?php echo site_url('contact'); ?>">Contacts</a></li>
                            </ul>
                        </nav>
                    </div>
                </div>
            </div>
        </div>
    </div>
</header>