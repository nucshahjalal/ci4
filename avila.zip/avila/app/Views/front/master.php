<!DOCTYPE html>
<html lang="en">
<head>
    <!--- Basic Page Needs  -->
    <meta charset="utf-8">
    <title><?php echo $title_for_layout; ?></title>
    <meta name="description" content="">
    <meta name="author" content="">
    <meta name="keywords" content="">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <!-- Mobile Specific Meta  -->
    <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1">
    
    <!-- CSS -->
    <link rel="stylesheet" href="<?php echo base_url(CSS_URL); ?>/front/bootstrap.min.css">
    <link rel="stylesheet" href="<?php echo base_url(CSS_URL); ?>/front/jquery-ui.css">
    <link rel="stylesheet" href="<?php echo base_url(CSS_URL); ?>/front/fontawesome-all.min.css">
    <link rel="stylesheet" href="<?php echo base_url(CSS_URL); ?>/front/owl.carousel.min.css">
    <link rel="stylesheet" href="<?php echo base_url(CSS_URL); ?>/front/jquery.fancybox.min.css">
    <link rel="stylesheet" href="<?php echo base_url(CSS_URL); ?>/front/meanmenu.css">
    <link rel="stylesheet" href="<?php echo base_url(CSS_URL); ?>/front/style.css">
    <link rel="stylesheet" href="<?php echo base_url(CSS_URL); ?>/front/responsive.css">

    <!-- Favicon -->
    <link rel="shortcut icon" type="image/png" href="<?php echo IMG_URL; ?>favicon.ico">
    
    <!-- HTML5 Shim and Respond.js IE8 support of HTML5 elements and media queries -->
    <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
    <!--[if lt IE 9]>
        <script src="https://oss.maxcdn.com/libs/html5shiv/3.7.0/html5shiv.js"></script>
        <script src="https://oss.maxcdn.com/libs/respond.js/1.4.2/respond.min.js"></script>
        <![endif]-->
    
     <!-- jQuery -->
    <script src="<?php echo base_url(JS_URL); ?>/jquery-1.11.2.min.js"></script>
    <script src="<?php echo base_url(JS_URL); ?>/jquery.validate.js"></script>
</head>

<body>
    <div id="preloader"></div>
    
    <!-- header-start -->    
    <?php echo $this->include('front/header'); ?>
    <!-- header-end -->
    
    <!-- page content -->
    <?php $this->renderSection("content"); ?>
    <!-- /page content -->    
        
    <!-- footer-start -->
     <?php echo $this->include('front/footer'); ?>
    <!-- footer-end -->
    
    
    
    <div class="floating-feedback">
        <div class="ff-box">
            <h4 class="title">Share your feedback</h4>
            <span class="ff-close" id="ff_close"><i class="fas fa-times"></i></span>
            <form action="#">
                <div class="input-box">
                    <input type="text" placeholder="Name">
                </div>
                <div class="input-box">
                    <input type="text" placeholder="Phone">
                </div>
                <div class="input-box">
                    <input type="email" placeholder="Email">
                </div>
                <div class="input-box">
                    <input type="text" placeholder="Subject">
                </div>
                <div class="input-box">
                    <textarea placeholder="Message"></textarea>
                </div>
                <div class="input-box">
                    <input type="submit" value="Send">
                </div>
            </form>
        </div>
        <span class="icon" id="ff_open"><i class="fas fa-envelope"></i></span>
    </div>
    
    <div class="floating-link">
        <ul>
            <?php  if($setting->facebook){ ?>
                <li><a href="<?php echo $setting->facebook; ?>" target="_blank"><i class="fab fa-facebook-f"></i></a></li>
            <?php } ?>
            <?php  if($setting->twitter){ ?>
                <li><a href="<?php echo $setting->twitter; ?>" target="_blank"><i class="fab fa-twitter"></i></a></li>
            <?php } ?>
            <?php  if($setting->linked_in){ ?>
                <li><a href="<?php echo $setting->linked_in; ?>" target="_blank"><i class="fab fa-linkedin-in"></i></a></li>
            <?php } ?>
            <?php  if($setting->pinterest){ ?>
                <li><a href="<?php echo $setting->pinterest; ?>" target="_blank"><i class="fab fa-pinterest-p"></i></a></li>
            <?php } ?>
            <?php  if($setting->youtube){ ?>
               <li><a href="<?php echo $setting->youtube; ?>" target="_blank"><i class="fab fa-youtube"></i></a></li>
            <?php } ?>
            <?php  if($setting->instagram){ ?>
               <li><a href="<?php echo $setting->instagram; ?>" target="_blank"><i class="fab fa-instagram"></i></a></li>
            <?php } ?>
        </ul>
    </div>
    <div class="floating-whatsapp">
        <a href="https://web.whatsapp.com/send?phone=<?php echo $setting->mobile; ?>&text=" target="_blank" class="link"><i class="fab fa-whatsapp"></i></a>
    </div>
    
    <!-- Scripts -->
    <script src="<?php echo base_url(JS_URL); ?>/front/jquery-3.2.0.min.js"></script>
    <script src="<?php echo base_url(JS_URL); ?>/front/jquery-ui.js"></script>
    <script src="<?php echo base_url(JS_URL); ?>/front/owl.carousel.min.js"></script>
    <script src="<?php echo base_url(JS_URL); ?>/front/jquery.fancybox.min.js"></script>
    <script src="<?php echo base_url(JS_URL); ?>/front/jquery.meanmenu.js"></script>
    <script src="<?php echo base_url(JS_URL); ?>/front/jquery.scrollUp.js"></script>
    <script src="<?php echo base_url(JS_URL); ?>/front/jquery.waypoints.min.js"></script>
    <script src="<?php echo base_url(JS_URL); ?>/front/popper.min.js"></script>
    <script src="<?php echo base_url(JS_URL); ?>/front/bootstrap.min.js"></script>
    <script src="<?php echo base_url(JS_URL); ?>/front/theme.js"></script>
    
    
</body>
</html>
