<?php echo $this->extend("front/master"); ?>
<?php echo $this->section("content"); ?>  

<!-- slider-start -->
<div class="slider-area owl-carousel">
    
    <?php if(isset($sliders) && !empty($sliders)){ ?>
        <?php foreach($sliders as $obj){ ?>
            <div class="single-slider bg-with-black">
                <div class="img">
                    <?php if($obj->image){ ?>
                        <img src="<?php echo base_url(UPLOAD_PATH); ?>/slider/<?php echo $obj->image; ?>" alt="<?php echo $obj->title; ?>" />
                    <?php }else{ ?>
                        <img src="<?php echo base_url(IMG_URL); ?>/slider-default.jpg" alt="<?php echo $obj->title; ?>">
                    <?php } ?>
                </div>
                <div class="content">
                    <div class="container">
                        <div class="row">
                            <div class="col-12">
                                <!--<h3 class="intro">The Best</h3>-->
                                <h2 class="title"><?php echo $obj->title; ?></h2>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        <?php } ?>
    <?php }else{ ?>
        <div class="single-slider bg-with-black">
            <div class="img">
                <img src="<?php echo base_url(IMG_URL); ?>/slider-default.jpg" alt="">
            </div>
            <div class="content">
                <div class="container">
                    <div class="row">
                        <div class="col-12">
                            <!--<h3 class="intro">The Best</h3>-->
                            <h2 class="title">The Best Find Your Home</h2>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    <?php } ?>
   
</div>
<!-- slider-end -->


<!-- project-start -->
<?php if(isset($projects) && !empty($projects)){ ?>
<div class="project-area">
    <div class="container">
        <div class="row">
            <div class="col-lg-8 offset-lg-2 col-md-10 offset-md-1 col-sm-12 col-12">
                <div class="section-title">
                    <h2 class="title"><?php echo $heading->project_title; ?></h2>
                    <p class="text"><?php echo $heading->project_note; ?></p>
                </div>
            </div>
        </div>
        <div class="row justify-content-center">
             <?php foreach($projects as $obj){ ?>
            <div class="col-lg-4 col-md-6 col-sm-6 col-12">
                <div class="single-project">
                    <div class="img bg-with-black">
                        <?php if($obj->image){ ?>
                            <img src="<?php echo base_url(UPLOAD_PATH); ?>/project/<?php echo $obj->image; ?>" alt=""/>
                        <?php }else{ ?>
                            <img src="<?php echo base_url(IMG_URL); ?>/project-default.jpg" alt="">
                        <?php } ?>
                    </div>
                    <div class="content">
                        <h2 class="title" style="text-align: center;"><a href="<?php echo site_url($obj->project_status.'/'.$obj->id); ?>"><?php echo $obj->name; ?></a></h2>
                        <!--
                        <ul class="info">
                            <li class="address"><span class="icon"><i class="fas fa-map-marker-alt"></i></span> 10 Philadelphia Avenue, PA, United States</li>
                            <li><span class="icon"><i class="fas fa-expand"></i></span> 130 SqFt ±</li>
                            <li><span class="icon"><i class="fas fa-bed"></i></span> 3</li>
                            <li><span class="icon"><i class="fas fa-building"></i></span> 1</li>
                            <li><span class="icon"><i class="fas fa-table"></i></span> 1</li>
                            <li><span class="icon"><i class="fas fa-bath"></i></span> 2</li>
                        </ul>
                        <h3 class="sale">SqFt For Sale <span class="price">$15000 ±</span></h3>
                        -->
                    </div>
                </div>
            </div>
           <?php } ?>
        </div>
    </div>
</div>
<!-- project-end -->
<?php } ?>

<!-- purchase-start -->
<div class="purchase-area bg-with-black">
    <div class="container">
        <div class="row">
            <div class="col-12">
                <div class="purchase-buttons">
                    <a class="link" href="<?php echo base_url('ongoing'); ?>">Purchase Now</a>
                    <a class="link" href="<?php echo base_url('ongoing'); ?>">View More Info</a>
                </div>
            </div>
        </div>
    </div>
</div>
<!-- purchase-end -->

<!-- news-start -->
<?php if(isset($news) && !empty($news)){ ?>
<div class="news-area">
    <div class="container">
        <div class="row">
            <div class="col-lg-8 offset-lg-2 col-md-10 offset-md-1 col-sm-12 col-12">
                <div class="section-title">
                    <h2 class="title"><?php echo $heading->news_title; ?></h2>
                    <p class="text"><?php echo $heading->news_note; ?></p>
                </div>
            </div>
        </div>
        <div class="row justify-content-center">
            <?php foreach($news as $obj){ ?>
                <div class="col-lg-4 col-md-6 col-sm-6 col-12">
                    <div class="single-news">
                        <div class="img">
                            <?php if($obj->image){ ?>
                                <img src="<?php echo base_url(UPLOAD_PATH); ?>/news/<?php echo $obj->image; ?>" alt=""  />
                            <?php }else{ ?>
                                <img src="<?php echo base_url(IMG_URL); ?>/news-default.jpg" alt="">
                            <?php } ?>
                        </div>
                        <div class="content">
                            <ul class="meta">
                                <li><span class="icon"><i class="far fa-calendar-alt"></i></span> <?php echo date('d/m/Y', strtotime($obj->created_at)); ?></li>
                                <li><span class="icon"><i class="fas fa-user"></i></span> Admin</li>
                            </ul>
                            <h2 class="title"><a href="<?php echo site_url('news-detail/'.$obj->id); ?>"><?php echo $obj->title; ?></a></h2>
                            <p class="text">
                                <?php echo substr(strip_tags($obj->initial_part), 0, 150); ?>...
                            </p>
                            <div class="more"><a class="link" href="<?php echo site_url('news-detail/'.$obj->id); ?>">Read More</a></div>
                        </div>
                    </div>
                </div>
            <?php } ?>
        </div>
    </div>
</div>
<!-- news-end -->
<?php } ?>

<!-- testimonial-start -->
<?php if(isset($testimonials) && !empty($testimonials)){ ?>
<div class="testimonial-area bg-with-black">
    <div class="container">
        <div class="row">
            <div class="col-lg-8 offset-lg-2 col-md-10 offset-md-1 col-sm-12 col-12">
                <div class="section-title color-white">
                    <h2 class="title">Client Reviews</h2>
                </div>
            </div>
        </div>
        <div class="row">
            <div class="col-lg-6 offset-lg-3 col-md-8 offset-md-2 col-sm-10 offset-sm-1 col-12">
                <div class="testimonial-carousel owl-carousel">
                 <?php foreach($testimonials as $obj){ ?>   
                    <div class="single-testimonial">
                        <div class="img">
                            <?php if($obj->image){ ?>
                                <img src="<?php echo base_url(UPLOAD_PATH); ?>/testimonial/<?php echo $obj->image; ?>" alt="" width="100" />
                            <?php }else{ ?>
                                <img src="<?php echo base_url(IMG_URL); ?>/testimonial-author.jpg" alt="">
                            <?php } ?>
                        </div>
                        <h2 class="name"><?php echo $obj->name; ?> (<?php echo $obj->designation; ?>)</h2>
                        <div class="rating clearfix">
                            <div class="star star-on"></div>
                            <div class="star star-on"></div>
                            <div class="star star-on"></div>
                            <div class="star star-on"></div>
                            <div class="star star-on"></div>
                        </div>
                        <p class="text">
                           <?php echo $obj->testimonial; ?>
                        </p>
                    </div>
                   <?php } ?>
                </div>
            </div>
        </div>
    </div>
</div>
<?php } ?>
<!-- testimonial-end -->

<!-- facilities-start -->
<?php if(isset($facilities) && !empty($facilities)){ ?>
<div class="facilities-area">
    <div class="container">
        <div class="row">
            <div class="col-lg-8 offset-lg-2 col-md-10 offset-md-1 col-sm-12 col-12">
                <div class="section-title">
                    <h2 class="title"><?php echo $heading->facility_title; ?></h2>
                    <p class="text">
                        <?php echo $heading->facility_note; ?>
                    </p>
                </div>
            </div>
        </div>
        <div class="row justify-content-center">
            <?php foreach($facilities as $obj){ ?>
            <div class="col-lg-4 col-md-6 col-sm-6 col-12">
                <div class="single-facilities">
                    <div class="img">
                        <?php if($obj->image){ ?>
                            <img src="<?php echo base_url(UPLOAD_PATH); ?>/facility/<?php echo $obj->image; ?>" alt="<?php echo $obj->title; ?>" />
                        <?php }else{ ?>
                            <img src="<?php echo base_url(IMG_URL); ?>/facilities-default.jpg" alt="<?php echo $obj->title; ?>">
                        <?php } ?>
                    </div>
                    <div class="content">
                        <h4 class="name"><?php echo $obj->title; ?></h4>
                    </div>
                </div>
            </div>
            <?php } ?>
       
        </div>
    </div>
</div>
<!-- facilities-end -->
 <?php } ?>

<?php echo $this->endSection(); ?>