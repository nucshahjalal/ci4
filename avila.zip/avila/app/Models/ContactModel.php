<?php 

namespace Models;
use CodeIgniter\Model;
  
class ContactModel extends Model{

    protected $table = 'contacts';
    protected $primaryKey = 'id';
    
    protected $allowedFields = [
        'name',
        'email',
        'phone',
        'subject',
        'message',
        'status',
        'created_at',
        'created_by',
        'modified_at',
        'modified_by'        
    ];      
}