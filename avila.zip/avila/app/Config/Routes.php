<?php

namespace Config;

// Create a new instance of our RouteCollection class.
$routes = Services::routes();

// Load the system's routing file first, so that the app and ENVIRONMENT
// can override as needed.
if (file_exists(SYSTEMPATH . 'Config/Routes.php')) {
    require SYSTEMPATH . 'Config/Routes.php';
}

/*
 * --------------------------------------------------------------------
 * Router Setup
 * --------------------------------------------------------------------
 */
$routes->setDefaultNamespace('App\Controllers');
$routes->setDefaultController('Home');
$routes->setDefaultMethod('index');
$routes->setTranslateURIDashes(false);
$routes->set404Override();
$routes->setAutoRoute(true);

/*
 * --------------------------------------------------------------------
 * Route Definitions
 * --------------------------------------------------------------------
 */

// We get a performance increase by specifying the default
// route since we don't have to scan directories.
//$routes->get('/', 'Home::index');
$routes->get('/', 'Home::index');
$routes->get('/about', 'Home::about');
$routes->get('/news', 'Home::news');
$routes->get('/news-detail/(:any)', 'Home::news_detail/$1');
$routes->get('/gallery', 'Home::gallery');
$routes->get('/contact', 'Home::contact');
$routes->post('/contactstore', 'Home::contactstore');

$routes->match(['get', 'post'], '/completed/(:any)', 'Home::completed/$1');
$routes->match(['get', 'post'], '/completed', 'Home::completed');

$routes->match(['get', 'post'], '/ongoing/(:any)', 'Home::ongoing/$1');
$routes->match(['get', 'post'], '/ongoing', 'Home::ongoing');

$routes->match(['get', 'post'], '/upcoming/(:any)', 'Home::upcoming/$1');
$routes->match(['get', 'post'], '/upcoming', 'Home::upcoming');


/*
 * --------------------------------------------------------------------
 * Additional Routing
 * --------------------------------------------------------------------
 *
 * There will often be times that you need additional routing and you
 * need it to be able to override any defaults in this file. Environment
 * based routes is one such time. require() additional route files here
 * to make that happen.
 *
 * You will have access to the $routes object within that file without
 * needing to reload it.
 */
if (file_exists(APPPATH . 'Config/' . ENVIRONMENT . '/Routes.php')) {
    require APPPATH . 'Config/' . ENVIRONMENT . '/Routes.php';
}


// CUSTOM ROUTE...  

$modules = glob(APPPATH . 'Modules/*', GLOB_ONLYDIR);
foreach($modules as $item_dir)
{
    if (file_exists($item_dir . '/Config/Routes.php'))
    {
            require_once($item_dir . '/Config/Routes.php');
    }	
}